# =====================================================================================
# 00_自检.R —— 30 秒内确认「环境 + 数据 + 列口径」是否就绪
# -------------------------------------------------------------------------------------
# 用途：换数据、换机器、升级 R 包之后，先跑这一个文件。
#       它不拟合任何模型，只做检查，因此必定在 1 分钟内出结果。
#
# 运行：Rscript 00_自检.R            （或在 RStudio 里 source）
#       Rscript 00_自检.R "D:/mimic"  （指定数据目录）
# =====================================================================================

cat("\n================ Meta 分析前置自检 ================\n")
cat("R 版本：", R.version.string, "\n")
cat("平台  ：", R.version$platform, "\n")
cat("时间  ：", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n")

## -------------------------------------------------------------------------------------
## 1. 依赖包
## -------------------------------------------------------------------------------------
NEED_PKG <- c("lcmm", "survival", "cmprsk", "ggplot2", "dplyr", "tidyr",
              "tableone", "patchwork", "broom", "readr")
OPT_PKG  <- c("survminer", "officer", "flextable", "openxlsx", "forestplot", "gt")

cat("\n[1] 依赖包\n")
miss <- character(0)
for (p in NEED_PKG) {
  ok <- requireNamespace(p, quietly = TRUE)
  cat(sprintf("  %-12s %s%s\n", p, if (ok) "✓" else "✗ 缺失",
              if (ok) paste0("  ", as.character(utils::packageVersion(p))) else ""))
  if (!ok) miss <- c(miss, p)
}
if (length(miss)) {
  cat("\n  安装命令（国内镜像）：\n")
  cat(sprintf('  install.packages(c(%s), repos = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/")\n',
              paste0('"', miss, '"', collapse = ", ")))
} else {
  cat("  必需包齐全。\n")
}
opt_miss <- OPT_PKG[!vapply(OPT_PKG, requireNamespace, logical(1), quietly = TRUE)]
if (length(opt_miss)) cat("  可选包缺失（不影响主分析）：", paste(opt_miss, collapse = ", "), "\n")

## -------------------------------------------------------------------------------------
## 2. 数据装载
## -------------------------------------------------------------------------------------
cat("\n[2] 数据装载\n")
ARGS <- commandArgs(trailingOnly = TRUE)
DATA_DIR <- if (length(ARGS)) ARGS[1] else getwd()

LOADER <- c("01_load_data.R", file.path(DATA_DIR, "01_load_data.R"))
LOADER <- LOADER[file.exists(LOADER)]
if (!length(LOADER)) {
  stop("找不到 01_load_data.R。请把它与本脚本放在同一目录。", call. = FALSE)
}

.SA_NO_AUTOLOAD <- TRUE
source(LOADER[1], encoding = "UTF-8")
D <- sa_load_all(DATA_DIR)
traj <- D$traj; wide <- D$wide; crrt <- D$crrt; suscept <- D$suscept

## -------------------------------------------------------------------------------------
## 3. 列口径核对（脚本 10 / 20 实际要用的列）
## -------------------------------------------------------------------------------------
cat("\n[3] 列口径核对\n")
CHK <- list(
  "10 轨迹建模" = list(obj = traj, cols = c("hadm_id","time_h","variable","value","time_s")),
  "10 联合表型" = list(obj = wide, cols = c("hadm_id","mrsa_status","in_traj_set")),
  "10 Cox 分析" = list(obj = wide, cols = c("age","gender","charlson","sofa_24h","death_28d",
                                            "followup_days_28d","mech_vent","any_vasopressor")),
  "20 表 1"     = list(obj = wide, cols = c("is_bsi","chf","hypertension","diabetes","ckd",
                                            "copd","malignancy","hosp_los_days","icu_los_hours")),
  "20 RRT"      = list(obj = crrt, cols = c("hadm_id","rrt_any","rrt_strong","rrt_type","rrt_source"))
)
for (nm in names(CHK)) {
  o <- CHK[[nm]]$obj
  if (is.null(o)) { cat(sprintf("  %-14s ✗ 数据对象不存在\n", nm)); next }
  lack <- setdiff(CHK[[nm]]$cols, names(o))
  cat(sprintf("  %-14s %s%s\n", nm,
              if (!length(lack)) "✓" else "✗ 缺列：",
              if (length(lack)) paste(lack, collapse = ", ") else ""))
}

## 缺失率最高的 10 个协变量（提醒完整病例分析会损失多少样本）
KEY <- c("age","gender","charlson","sofa_24h","mech_vent","any_vasopressor",
         "death_28d","followup_days_28d","is_bsi","lactate_max","cr_max","albumin_min")
KEY <- intersect(KEY, names(wide))
MISS <- data.frame(
  variable = KEY,
  n_miss   = vapply(KEY, function(v) sum(is.na(wide[[v]])), integer(1)),
  stringsAsFactors = FALSE)
MISS$pct <- round(100 * MISS$n_miss / nrow(wide), 1)
MISS <- MISS[order(-MISS$pct), ]
cat("\n  关键协变量缺失率（完整病例分析会按最高的那个丢样本）：\n")
print(MISS, row.names = FALSE)

## -------------------------------------------------------------------------------------
## 4. 结论
## -------------------------------------------------------------------------------------
cat("\n[4] 判定\n")
if (length(miss)) {
  cat("  ✗ 还差必需包，先按上面命令安装。\n")
} else if (length(setdiff(c("hadm_id","time_h","variable","value","time_s"), names(traj)))) {
  cat("  ✗ 轨迹表列不全，检查导出 SQL。\n")
} else {
  cat("  ✓ 环境与数据就绪，可以运行 10_R_分析全流程.R。\n")
  cat("    注意：GBTM 的 gridsearch(rep = 30) 在这一体量下约需 15 分钟/K，\n")
  cat("          全流程 K=1–4 两个指标预计 2–3 小时。先用 rep = 10 验证链路。\n")
}

## 版本锁定记录
try(writeLines(capture.output(sessionInfo()), "sessionInfo_自检.txt"), silent = TRUE)
cat("\n  sessionInfo 已写入 sessionInfo_自检.txt\n")
cat("==================================================\n\n")
