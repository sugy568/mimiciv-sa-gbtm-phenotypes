## 图（ggplot2 版）：ROC 对比 + 增量 ΔC 情景图
suppressPackageStartupMessages({library(pROC); library(ggplot2); library(gridExtra)})
set.seed(20261111)
d  <- read.csv("/root/uploads/1792063918821056536-SA_MASTER.csv", fileEncoding = "UTF-8-BOM")
ph <- read.csv("/workspace/phenotype_assignment.csv", fileEncoding = "UTF-8-BOM")
m  <- merge(d, ph[, c("hadm_id", "pheno")], by = "hadm_id")
fa <- function(df, cols) apply(df[, cols, drop = FALSE], 1,
      function(x) { x <- x[!is.na(x)]; if (length(x)) x[1] else NA })
m$lac_first <- fa(m, c("lac_0h","lac_6h","lac_12h","lac_24h"))
m$cr_first  <- fa(m, c("cr_0h","cr_6h","cr_12h","cr_24h"))
m$y <- as.integer(m$death_28d); m$male <- as.integer(m$gender == "M")
m$mr <- factor(m$mrsa_status, levels = c("MSSA","MRSA","unknown"))
m$ph <- factor(m$pheno, levels = 1:3)
m$log_lac <- log(pmax(m$lac_first, .1)); m$log_cr <- log(pmax(m$cr_first, .1))
vars <- c("y","age","male","charlson","sofa_24h","mr","is_bsi","log_lac","log_cr","ph")
cc <- m[complete.cases(m[, vars]), ]
b <- "y ~ age + male + charlson + sofa_24h + mr + is_bsi"
M1 <- glm(as.formula(b), cc, family = binomial)
M2 <- glm(as.formula(paste(b, "+ log_lac + log_cr")), cc, family = binomial)
M3 <- glm(as.formula(paste(b, "+ log_lac + log_cr + ph")), cc, family = binomial)
r1 <- roc(cc$y, fitted(M1), quiet = TRUE); r2 <- roc(cc$y, fitted(M2), quiet = TRUE); r3 <- roc(cc$y, fitted(M3), quiet = TRUE)

df1 <- data.frame(fpr = 1 - r1$specificities, tpr = r1$sensitivities, Model = sprintf("M1 clinical baseline (AUC %.3f)", auc(r1)))
df2 <- data.frame(fpr = 1 - r2$specificities, tpr = r2$sensitivities, Model = sprintf("M2 + single-point lactate/Cr (AUC %.3f)", auc(r2)))
df3 <- data.frame(fpr = 1 - r3$specificities, tpr = r3$sensitivities, Model = sprintf("M3 + trajectory phenotype (AUC %.3f)", auc(r3)))
rocdf <- rbind(df1, df2, df3)

p1 <- ggplot(rocdf, aes(fpr, tpr, colour = Model)) +
  geom_line(linewidth = 0.75) + geom_abline(slope = 1, intercept = 0, linetype = 3, colour = "grey60") +
  scale_colour_manual(values = c("#7f8c8d", "#2E86C1", "#C0392B")) +
  scale_x_continuous("1 - Specificity", limits = c(0, 1)) +
  scale_y_continuous("Sensitivity", limits = c(0, 1)) +
  ggtitle("A  ROC curves (n = 2,251; 693 deaths)") +
  theme_classic(base_size = 12) + theme(legend.position = c(.62, .28),
    legend.background = element_rect(fill = "white", colour = "grey80", linewidth = .3),
    legend.title = element_blank(), legend.text = element_text(size = 9),
    plot.title = element_text(face = "plain", size = 12))

sens <- read.csv("/workspace/incremental_C_sensitivity.csv")
bar <- data.frame(
  comparator = factor(c("Clinical baseline\n(no labs)",
                        "+ single-point\nlactate only",
                        "+ single-point lactate\n+ Cr (peak)",
                        "+ single-point lactate\n+ Cr (first)"),
                      levels = c("Clinical baseline\n(no labs)",
                                 "+ single-point\nlactate only",
                                 "+ single-point lactate\n+ Cr (peak)",
                                 "+ single-point lactate\n+ Cr (first)")),
  dC = c(sens$dC_M3_M1[4], sens$dC_M3_M2[3], sens$dC_M3_M2[2], sens$dC_M3_M2[1]),
  P  = c(sens$P[4], sens$P[3], sens$P[2], sens$P[1]),
  grp = c("baseline", "single-point", "single-point", "single-point"))
p2 <- ggplot(bar, aes(comparator, dC, fill = grp)) +
  geom_col(width = .62) +
  geom_text(aes(label = sprintf("+%.3f\nP = %.2g", dC, P)), vjust = -0.35, size = 3.1) +
  scale_fill_manual(values = c(baseline = "#95a5a6", `single-point` = "#5DADE2"), guide = "none") +
  scale_y_continuous(expression(Delta*"C-statistic added by the phenotype"), limits = c(0, 0.028)) +
  ggtitle("B  Incremental discrimination by comparator") +
  theme_classic(base_size = 12) +
  theme(axis.text.x = element_text(size = 8.6, lineheight = .95), axis.title.x = element_blank(),
        plot.title = element_text(face = "plain", size = 12))

g <- arrangeGrob(p1, p2, nrow = 1)
ggsave("/workspace/Fig_incremental_C.png", g, width = 11, height = 5.2, dpi = 220)
cat("figure written\n")
