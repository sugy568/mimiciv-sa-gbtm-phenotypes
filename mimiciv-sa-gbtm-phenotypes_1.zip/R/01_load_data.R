# =====================================================================================
# 01_load_data.R —— 统一数据装载模块（脚本 10 / 20 / 21 共用）
# -------------------------------------------------------------------------------------
# 解决的问题：
#   ① 文件改名后 read.csv("sa_final.csv") 找不到文件 —— 改为「按语义关键词智能定位」
#   ② 表头带 UTF-8 BOM（﻿"hadm_id"）—— Windows 中文 locale 下会变成 ï..hadm_id，
#      导致 hadm_id 取不到、后续 merge 全空 —— 统一清洗
#   ③ 文本 "NULL" 被读成字符型，使 rrt_first_time 等时间列无法转 POSIXct
#   ④ 列名/类型与脚本预期不符时，在建模前就拦下，而不是跑到一半崩
#
# 用法：
#   source("01_load_data.R")            # 自动在当前目录及常见子目录里找四张表
#   source("01_load_data.R"); D <- sa_load_all("D:/mimic")
#
# 产出（全局对象）：
#   traj     轨迹长表   hadm_id / mrsa_status / time_h / variable / value (+ time_s, time_d)
#   wide     病例宽表   ≥13,773 行
#   crrt     RRT 表     （找不到则为 NULL，不中断）
#   suscept  药敏长表   （找不到则为 NULL，不中断）
#   QC       质量门汇总 data.frame
# =====================================================================================

## -------------------------------------------------------------------------------------
## [1] 基础工具
## -------------------------------------------------------------------------------------

# 文件名规范化：小写 + 去掉所有非字母数字，用于模糊匹配
sa_norm_name <- function(x) gsub("[^a-z0-9]", "", tolower(basename(x)))

# 列名清洗：去 BOM、去首尾空白、去 read.csv 给非法字符加的前缀
sa_clean_names <- function(nm) {
  nm <- gsub("^\ufeff", "", nm)                 # 真 BOM 字符
  nm <- gsub("^X\\.U\\.FEFF\\.", "", nm)        # check.names 转义后的 BOM
  nm <- gsub("^\u00ef\u00bb\u00bf", "", nm)     # BOM 被按 latin1 读成三个字符
  nm <- gsub("^\u00ef\\.\\.", "", nm)           # 同上，read.csv 加点
  nm <- gsub("^X\\.", "", nm)                   # check.names 给数字/符号开头加的 X.
  nm <- trimws(nm)
  nm
}

# 检测文件是否带 UTF-8 BOM
sa_has_bom <- function(path) {
  ok <- tryCatch({
    con <- file(path, "rb"); on.exit(close(con), add = TRUE)
    b <- readBin(con, "raw", n = 3)
    length(b) == 3 && identical(b, as.raw(c(0xEF, 0xBB, 0xBF)))
  }, error = function(e) FALSE)
  isTRUE(ok)
}

# 稳健读 CSV：BOM 感知 + 编码回退 + "NULL"/""/"NA" 统一为 NA + 列名清洗
sa_read_csv <- function(path, verbose = TRUE) {
  enc <- if (sa_has_bom(path)) "UTF-8-BOM" else "UTF-8"
  d <- tryCatch(
    utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE,
                    fileEncoding = enc,
                    na.strings = c("", "NA", "NULL", "NaN", "N/A", ".")),
    error = function(e) NULL
  )
  # 回退 1：不带编码声明（部分 Windows R 不认 UTF-8-BOM）
  if (is.null(d)) {
    d <- tryCatch(
      utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE,
                      na.strings = c("", "NA", "NULL", "NaN", "N/A", ".")),
      error = function(e) NULL)
  }
  # 回退 2：GBK（中文 Windows 默认导出编码）
  if (is.null(d)) {
    d <- tryCatch(
      utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE,
                      fileEncoding = "GBK",
                      na.strings = c("", "NA", "NULL", "NaN", "N/A", ".")),
      error = function(e) NULL)
  }
  if (is.null(d)) stop(sprintf("无法读取：%s\n  文件可能被 Excel 占用，或编码不是 UTF-8/GBK。", path),
                       call. = FALSE)
  names(d) <- sa_clean_names(names(d))
  if (verbose) cat(sprintf("  ✓ %-22s %6d 行 × %3d 列  ← %s\n",
                           basename(path), nrow(d), ncol(d), basename(path)))
  d
}

## -------------------------------------------------------------------------------------
## [2] 智能定位：按「语义关键词 + 必需列」双重校验，不依赖具体文件名
## -------------------------------------------------------------------------------------
# 每类文件的候选关键词（按优先级排列，先命中先用）
#   keys：文件名规范化后需包含的片段；任一候选命中即可
#   must：必须存在的列（缺列则跳过该文件，继续找下一个候选）
SA_SPEC <- list(
  traj = list(
    keys = c("satrajlong", "trajlong", "satraj", "traj"),
    must = c("hadm_id", "time_h", "variable", "value"),
    label = "轨迹长表（lactate / creatinine 时序）"),
  wide = list(
    keys = c("samerged", "merged", "samaster", "master", "safinal", "final"),
    must = c("hadm_id", "mrsa_status", "death_28d"),
    label = "病例宽表"),
  crrt = list(
    keys = c("sacrrtsci", "crrtsci", "crrt", "sarrt", "rrt"),
    must = c("hadm_id", "rrt_flag"),
    label = "RRT 判定表（可选）"),
  suscept = list(
    keys = c("sasusceptlong", "susceptlong", "suscept"),
    must = c("hadm_id", "antibiotic"),
    label = "药敏长表（可选）")
)

# 在 dir 及其常见子目录中列出全部 csv
sa_csv_pool <- function(dir) {
  sub_dirs <- c("", "data", "merged", "merged_out", "data/merged",
                "data/merged/total", "data/merged/total/merged_out", "out_manuscript")
  pool <- character(0)
  for (s in sub_dirs) {
    p <- if (nzchar(s)) file.path(dir, s) else dir
    if (dir.exists(p)) {
      pool <- c(pool, list.files(p, pattern = "\\.csv$", full.names = TRUE,
                                 ignore.case = TRUE))
    }
  }
  unique(pool)
}

# 主定位函数
sa_locate <- function(kind, dir, verbose = TRUE) {
  spec  <- SA_SPEC[[kind]]
  pool  <- sa_csv_pool(dir)
  if (!length(pool)) return(NULL)

  nm <- sa_norm_name(pool)
  # 排除明显不是目标的文件（中间产物 / 输出表）
  drop <- grepl("^(gbtm|table|fig|cox|km|cif|phenotype|package|missing)", nm)
  pool <- pool[!drop]; nm <- nm[!drop]

  hit <- character(0)
  for (k in spec$keys) {
    idx <- which(grepl(k, nm, fixed = TRUE))
    if (length(idx)) hit <- c(hit, pool[idx])
  }
  hit <- unique(hit)
  if (!length(hit)) return(NULL)

  # 按必需列校验，取第一个合格者
  for (f in hit) {
    hdr <- tryCatch({
      nms <- names(sa_read_csv(f, verbose = FALSE))
      nms
    }, error = function(e) character(0))
    if (all(spec$must %in% hdr)) return(f)
  }
  if (verbose) {
    warning(sprintf("找到疑似 %s 的文件但缺少必需列（需 %s）：\n  %s",
                    spec$label, paste(spec$must, collapse = ", "),
                    paste(hit, collapse = "\n  ")), call. = FALSE)
  }
  NULL
}

## -------------------------------------------------------------------------------------
## [3] 装载 + 校验
## -------------------------------------------------------------------------------------
sa_load_all <- function(dir = getwd(), need = c("traj", "wide"), verbose = TRUE) {

  if (verbose) cat("\n[数据装载] 目录：", normalizePath(dir, mustWork = FALSE), "\n", sep = "")

  # ---- 3.1 定位 ----
  paths <- list()
  for (k in c("traj", "wide", "crrt", "suscept")) {
    paths[[k]] <- sa_locate(k, dir, verbose = FALSE)
  }

  missing_need <- need[vapply(need, function(k) is.null(paths[[k]]), logical(1))]
  if (length(missing_need)) {
    pool <- sa_csv_pool(dir)
    stop(sprintf(paste0(
      "\n找不到必需的输入文件：%s\n",
      "  %s\n\n",
      "在该目录及子目录下找到的 csv（%d 个）：\n  %s\n\n",
      "处理办法（三选一）：\n",
      "  ① 把文件放到 %s 目录下，文件名含关键词即可（如 SA_MASTER.csv / sa_final.csv 都认）；\n",
      "  ② 显式指定目录：source(\"01_load_data.R\"); D <- sa_load_all(\"D:/你的数据目录\")\n",
      "  ③ 直接改 01_load_data.R 里 SA_SPEC 的 keys，加入你的实际文件名。\n",
      "  注：宽表必需列 = hadm_id / mrsa_status / death_28d；轨迹表必需列 = hadm_id / time_h / variable / value"),
      paste(missing_need, collapse = ", "),
      paste(vapply(missing_need, function(k) SA_SPEC[[k]]$label, character(1)), collapse = "；"),
      length(pool), if (length(pool)) paste(basename(pool), collapse = "\n  ") else "（无）",
      normalizePath(dir, mustWork = FALSE)), call. = FALSE)
  }

  if (verbose) cat("  ↓ 已定位\n")

  # ---- 3.2 读取 ----
  traj <- sa_read_csv(paths$traj)
  wide <- sa_read_csv(paths$wide)
  crrt <- if (!is.null(paths$crrt))    sa_read_csv(paths$crrt)    else NULL
  susc <- if (!is.null(paths$suscept)) sa_read_csv(paths$suscept) else NULL
  if (is.null(crrt)   && verbose) message("  提示：未找到 RRT 表，21_rrt_sensitivity.R 将不可用。")
  if (is.null(susc)   && verbose) message("  提示：未找到药敏长表，MRSA 派生将回退到 wide$mrsa_status。")

  # ---- 3.3 类型强制 ----
  traj$hadm_id <- as.integer(traj$hadm_id)
  traj$time_h  <- as.numeric(traj$time_h)
  traj$value   <- as.numeric(traj$value)
  traj$variable <- tolower(trimws(as.character(traj$variable)))
  if (!is.null(traj$mrsa_status)) traj$mrsa_status <- toupper(trimws(traj$mrsa_status))
  wide$hadm_id <- as.integer(wide$hadm_id)

  # 时间轴：缩放到 [0,1]（Methods 2.4 口径：t = 小时数 / 72）
  traj$time_s <- traj$time_h / 72
  traj$time_d <- traj$time_h / 24

  ## ---- 3.4 质量门 ----
  QC <- list()

  # (a) 时间轴
  if (!(min(traj$time_h, na.rm = TRUE) >= 0 && max(traj$time_h, na.rm = TRUE) <= 72)) {
    stop(sprintf("time_h 超出 0–72 小时范围：实测 %.1f – %.1f。请回查 SQL 的时间窗设定。",
                 min(traj$time_h, na.rm = TRUE), max(traj$time_h, na.rm = TRUE)), call. = FALSE)
  }

  # (b) 非正值 / 缺失
  bad <- traj[is.na(traj$value) | traj$value <= 0, ]
  if (nrow(bad)) {
    warning(sprintf("检出 %d 条 value 缺失或 ≤0 的记录，已剔除。", nrow(bad)), call. = FALSE)
    traj <- traj[!is.na(traj$value) & traj$value > 0, ]
  }

  # (c) 重复时间点（同一 hadm + 指标 + 时刻多条）
  dup <- traj[duplicated(traj[, c("hadm_id", "variable", "time_h")]) |
              duplicated(traj[, c("hadm_id", "variable", "time_h")], fromLast = TRUE), ]
  QC$n_dup_timepoint <- nrow(dup)
  if (nrow(dup)) {
    warning(sprintf("检出 %d 条同一时点重复记录（保留首条）。GBTM 不要求等间隔，但重复时点会使残差方差被低估。",
                    nrow(dup)), call. = FALSE)
    traj <- traj[!duplicated(traj[, c("hadm_id", "variable", "time_h")]), ]
  }

  # (d) 逐指标汇总
  qc_tab <- do.call(rbind, lapply(split(traj, traj$variable), function(d) {
    n_per <- table(d$hadm_id)
    data.frame(
      variable   = d$variable[1],
      n_obs      = nrow(d),
      n_hadm     = length(unique(d$hadm_id)),
      min_val    = round(min(d$value), 2),
      p01        = round(quantile(d$value, .01, names = FALSE), 2),
      median     = round(median(d$value), 2),
      p99        = round(quantile(d$value, .99, names = FALSE), 2),
      max_val    = round(max(d$value), 2),
      obs_med    = as.integer(median(n_per)),
      obs_min    = as.integer(min(n_per)),
      obs_max    = as.integer(max(n_per)),
      n_ge3      = sum(n_per >= 3),
      n_ge4      = sum(n_per >= 4),
      stringsAsFactors = FALSE)
  }))
  rownames(qc_tab) <- NULL
  QC$by_variable <- qc_tab

  # (e) 两表一致性
  QC$hadm_in_traj_not_wide <- sum(!unique(traj$hadm_id) %in% wide$hadm_id)
  QC$n_traj <- length(unique(traj$hadm_id))
  QC$n_wide <- nrow(wide)

  QC$n_dup_timepoint <- if (is.null(QC$n_dup_timepoint)) 0L else QC$n_dup_timepoint

  # ---- 3.5 打印 ----
  if (verbose) {
    cat("\n[质量门]\n")
    cat(sprintf("  轨迹表：%d 条观测 / %d 例；宽表：%d 例\n",
                nrow(traj), QC$n_traj, QC$n_wide))
    cat(sprintf("  轨迹表有、宽表无的 hadm：%d 例 %s\n", QC$hadm_in_traj_not_wide,
                if (QC$hadm_in_traj_not_wide == 0) "（正常）" else "⚠ 需回查 SQL 导出"))
    cat(sprintf("  同人同时点重复记录：%d 条\n", QC$n_dup_timepoint))
    cat("\n  逐指标：\n")
    print(qc_tab, row.names = FALSE)

    # 观测次数不足的提示（GBTM 对稀疏个体的信息量有限）
    for (i in seq_len(nrow(qc_tab))) {
      r <- qc_tab[i, ]
      if (r$n_ge3 < r$n_hadm) {
        cat(sprintf("\n  注：%s 有 %d 例（%.1f%%）观测 <3 次；" ,
                    r$variable, r$n_hadm - r$n_ge3,
                    100 * (r$n_hadm - r$n_ge3) / r$n_hadm))
        cat("lcmm 仍会纳入这些个体（对其固定效应有贡献），\n")
        cat("      但其后验分类主要靠先验，建议在敏感性分析中剔除 <3 次者复核。\n")
      }
    }
  }

  # ---- 3.6 写出质控表（便于贴回/归档）----
  qc_path <- file.path(dir, "QC_data_load.csv")
  try(write.csv(qc_tab, qc_path, row.names = FALSE, fileEncoding = "UTF-8"), silent = TRUE)

  invisible(list(traj = traj, wide = wide, crrt = crrt, suscept = susc, QC = QC,
                 paths = paths))
}

## -------------------------------------------------------------------------------------
## [4] source 即生效（脚本 10 / 20 直接 source 本文件即可拿到 traj / wide）
## -------------------------------------------------------------------------------------
if (!exists(".SA_NO_AUTOLOAD", envir = .GlobalEnv)) {
  .sa_dir <- if (exists("DIR", envir = .GlobalEnv)) get("DIR", envir = .GlobalEnv) else getwd()
  .D <- sa_load_all(.sa_dir)
  traj    <- .D$traj
  wide    <- .D$wide
  crrt    <- .D$crrt
  suscept <- .D$suscept
  QC      <- .D$QC
  SA_PATHS <- .D$paths
  rm(.D, .sa_dir)
}
