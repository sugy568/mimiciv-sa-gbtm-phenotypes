###############################################################################################
#  20_manuscript_tables_figures.R
#  -------------------------------------------------------------------------------------------
#  目的：从 SA_MERGED.csv（13,773 × 208）出发，一次性复现 Manuscript_SA_GBTM_MIMIC 正文所需的
#        全部表格（Table 1/2/3）与全部图件（Fig 1–7 + Fig S1–S11），并输出溯源 CSV。
#
#  依赖：本脚本【只读 SA_MERGED.csv】+ 【只读】phenotype_assignment.csv
#        —— 后者是 GBTM（lcmm::hlme，本机拟合耗时约 7 分钟）的一次性结果，内容仅两列：
#           hadm_id 与 pheno(1–4)。GBTM 重新拟合见 30_gbtm_refit.R（可选，结果可复现但慢）。
#        除此之外不依赖任何中间文件、不依赖 R_绘图全流程.R 的全局环境。
#
#  运行：Rscript 20_manuscript_tables_figures.R
#        （Windows 建议 Rscript.exe，工作目录设为脚本所在目录）
#
#  输出：out_manuscript/
#          tables/  Table1_baseline.csv, Table2_univariable.csv, Table3_multivariable.csv,
#                   Table1_by_phenotype.csv, TableS_gbtm_selection.csv ...
#          figures/ Fig01..Fig07, FigS01..FigS11（各 PDF + PNG 300 dpi）
#          trace/   cox_*.csv, km_*.csv, cif_*.csv, missingness.csv, key_numbers.txt,
#                   sessionInfo.txt, package_versions.csv
#
#  -------------------------------------------------------------------------------------------
#  ★ 相对旧版 R_绘图全流程.R 的 5 处口径修正（均有实测依据，见文件末尾口径说明）
#    ① 暴露变量：rrt = rrt_strong = 566 例（有透析执行记录），弃用旧的 560/275 混合口径；
#       ICD_only 318 例单列为「未证实透析」，不进主分析（敏感分析可见 rrt_any = 884）。
#    ② Table 3 主模型统一为「含 SOFA」的全队列完整病例集（n = 2,514，746 事件），
#       三列模型同一分析集，横向可比；旧版 2,501/733 来自另一套缺失处理，不再混用。
#    ③ 单因素 Cox 与多因素 Cox 使用同一分析集，Table 2 与 Table 3 可直接对照。
#    ④ Fig S10 原注「29.8% RRT 患者无 ICU 记录」在新口径下为 0%（566/566 均有 ICU），已改。
#    ⑤ Fig S11 / Table S6 的 RRT 分层改用 rrt_strong，不再用含维持性透析的宽口径。
#  -------------------------------------------------------------------------------------------
#  方法学声明（写进 Methods 时照抄即可）：
#    · 生存分析时间零点 = 首次金葡菌检出时间；随访截尾于 28 天（death_28d / followup_days_28d）
#    · 缺失处理：完整病例分析（complete-case），缺失比例逐个变量在 Table 1 末列报告
#    · 竞争风险：Aalen–Johansen 累积发生率，死亡为目标事件、自动出院为竞争事件
#    · 比例风险假定：scaled Schoenfeld 残差全局检验 + 逐变量检验，违例则在正文报告时间平均 HR
#    · 中介变量（机械通气、升压药、RRT）不进主模型，仅作敏感性分析（过度调整风险）
###############################################################################################

rm(list = ls()); options(stringsAsFactors = FALSE, scipen = 200)

## =============================================================================================
## [0] 环境与路径
## =============================================================================================
suppressPackageStartupMessages({
  library(dplyr); library(tidyr); library(readr); library(tibble)
  library(ggplot2); library(survival); library(splines); library(cmprsk)
})
HAS_PATCHWORK <- requireNamespace("patchwork", quietly = TRUE)
HAS_OFFICER   <- requireNamespace("officer",  quietly = TRUE) && requireNamespace("flextable", quietly = TRUE)
if (HAS_PATCHWORK) suppressPackageStartupMessages(library(patchwork))

# 工作目录：优先脚本所在目录（Rscript 下自动识别），否则取当前目录
.this <- tryCatch({
  a <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", a[grep("^--file=", a)])
  if (length(f)) dirname(normalizePath(f[1])) else getwd()
}, error = function(e) getwd())
setwd(.this)
cat("工作目录:", getwd(), "\nR 版本:", R.version.string, "\n")

## =============================================================================================
## [0b] 输入文件定位
##   ★ 两套路径都要能跑：
##      ① 仓库布局（脚本在 total/，数据在 total/merged_out/）
##      ② 你当前布局（脚本就在 merged_out/ 里，SA_MERGED.csv 与脚本同级）
##   因此每个候选路径都同时按「相对路径 / 本脚本所在目录 / 上一级目录」三处探测。
## =============================================================================================
SCRIPT_DIR <- .this
PARENT_DIR <- dirname(SCRIPT_DIR)

## ---------------------------------------------------------------------------------------------
## ★★★ 输入路径设置区 ★★★
##   ★★★ v9：默认已按你的实际布局写死为 D 盘目录，直接 Rscript 即可运行 ★★★
##     数据目录 = D:/mimiciv/金黄色葡萄球菌/data/merged/total/merged_out
##       SA_MERGED.csv 与 phenotype_assignment.csv 都在该目录下；输出写到
##       该目录/out_manuscript/{figures,tables,trace}。
##   若日后换机器/挪目录：改下面 USER_DATA_DIR 一行即可（三个路径都由它派生）；
##   该目录不存在时脚本会自动回退到常规探测（脚本目录 → 上一级 → merged_out/），不会白跑。
## ---------------------------------------------------------------------------------------------
## 把 Windows 反斜杠统一成 /（R 对两者都认，但统一后报错信息更好读）
norm_slash <- function(p) gsub("\\\\", "/", p)

USER_DATA_DIR <- "D:/mimiciv/金黄色葡萄球菌/data/merged/total/merged_out"
USER_DATA_DIR <- norm_slash(USER_DATA_DIR)

IN_FILE_ABS  <- if (nzchar(USER_DATA_DIR)) file.path(USER_DATA_DIR, "SA_MERGED.csv") else ""
PHENO_ABS_CANDS <- if (nzchar(USER_DATA_DIR)) {
  file.path(USER_DATA_DIR, "phenotype_assignment.csv")
} else character(0)
OUT_ABS_OVERRIDE <- ""      # 输出自动跟随 SA_MERGED.csv 所在目录；要改别处才填绝对路径

IN_FILE_ABS      <- norm_slash(IN_FILE_ABS)
PHENO_ABS_CANDS  <- norm_slash(PHENO_ABS_CANDS)
PHENO_ABS_CANDS  <- PHENO_ABS_CANDS[nzchar(PHENO_ABS_CANDS)]

## 中文路径预检：R 4.2+ 在 Windows 上对 UTF-8 中文路径基本没问题，但 R < 4.2 或
## 区域设置为非 UTF-8 时 read_csv 会报 "cannot open file"。此处给出明确提示，避免误判为数据错误。
check_cjk_path <- function(p, label) {
  if (!nzchar(p)) return(invisible(NULL))
  if (grepl("[^\\x01-\\x7F]", p, perl = TRUE) && !l10n_info()$`UTF-8`) {
    warning(sprintf(paste0(
      "\n  ⚠ %s 路径含中文字符，但当前 R 会话非 UTF-8 区域设置。\n",
      "    建议在 R 控制台执行 Sys.setlocale(\"LC_ALL\", \"Chinese_China.UTF-8\") 后重跑，\n",
      "    或把文件复制到纯英文路径（如 D:/mimiciv/sa/data/merged_out/）。\n"), label),
      call. = FALSE)
  }
}
check_cjk_path(IN_FILE_ABS, "SA_MERGED.csv")
for (pp in PHENO_ABS_CANDS) check_cjk_path(pp, "phenotype_assignment.csv")

# 把候选名展开成实际可探测的绝对路径：未命中时返回空向量而不是报错
# ★ v8：补上 SCRIPT_DIR/merged_out —— 仓库布局（脚本在 total/，数据在 total/merged_out/）
#       此前只查 SCRIPT_DIR 与 PARENT_DIR，恰好在最常见的一种布局下漏检。
locate_file <- function(cands, dirs = c(SCRIPT_DIR,
                                        file.path(SCRIPT_DIR, "merged_out"),
                                        PARENT_DIR,
                                        file.path(PARENT_DIR, "merged_out"),
                                        getwd(),
                                        file.path(getwd(), "merged_out"))) {
  hits <- character(0)
  for (cn in cands) {
    if (!nzchar(cn)) next
    # Windows 绝对路径：D:/... 或 D:\... 或 \\server\share；POSIX 绝对路径：/...
    is_abs <- grepl("^([A-Za-z]:[/\\\\]|[/\\\\])", cn)
    test <- if (is_abs) cn else file.path(dirs, cn)
    test <- test[nzchar(test) & file.exists(test)]
    if (length(test)) hits <- c(hits, test[1])
  }
  unique(hits)
}
pick_file <- function(cands, what, exclude_re = NULL) {
  hit <- locate_file(cands)
  blocked <- character(0)
  if (!is.null(exclude_re)) {
    blocked <- hit[grepl(exclude_re, hit, perl = TRUE)]
    hit     <- hit[!grepl(exclude_re, hit, perl = TRUE)]
  }
  if (!length(hit)) {
    stop(sprintf(paste0(
      "找不到可用的 %s。\n",
      "已尝试的完整路径（含绝对路径设置）：\n  %s\n",
      "当前工作目录：%s\n",
      if (length(blocked)) sprintf("\n★ 找到但已排除（归档/废弃版本）：\n  %s\n", paste(blocked, collapse = "\n  ")) else "",
      "\n处理：\n",
      "  ① 打开本脚本 [0b] 段，把 IN_FILE_ABS 改成 SA_MERGED.csv 的真实绝对路径；\n",
      "     例：IN_FILE_ABS <- \"D:/mimiciv/金黄色葡萄球菌/data/merged/total/merged_out/SA_MERGED.csv\"\n",
      "  ② 或用 Rscript 从该目录运行：setwd(\"D:/.../merged_out\"); source(\"20_manuscript_tables_figures.R\")\n",
      "  ③ 路径分隔符写 / 或 \\\\ 均可，但不要写成单个 \\（R 会当作转义符）。"),
      what,
      paste(cands, collapse = "\n  "),
      getwd()), call. = FALSE)
  }
  hit[1]
}

## ★ 2026-11 更新：数据导出可能叫 SA_MASTER.csv（157 列，RRT 另存为 SA_CRRT_SCI.csv）
##   或 sa_final.csv。三者按「必需列」等价，故一并列为候选，由下方兼容装配层补齐 RRT 列。
IN_FILE <- c(IN_FILE_ABS,
             "SA_MERGED.csv", "SA_MASTER.csv", "sa_final.csv",
             "merged_out/SA_MERGED.csv", "merged_out/SA_MASTER.csv", "merged_out/sa_final.csv")

## ---------------------------------------------------------------------------------------------
## ★ 防「版本混用」：输入文件候选顺序会刻意排除 _archive/ 与任何 *DEPRECATED* 文件名。
##   若用户把旧版放回根目录并改名成 SA_MERGED.csv，[1] 段的版本指纹校验会拦下（见下）。
## ---------------------------------------------------------------------------------------------
locate_input <- function(cands) {
  hits <- locate_file(cands)
  hits <- hits[!grepl("(^|[/\\\\])_archive([/\\\\]|$)", hits)]
  hits <- hits[!grepl("DEPRECATED|deprecated|_v1_|_old", hits)]
  hits
}

# 表型文件：GBTM 一次性结果，仅含 hadm_id 与 pheno(1-4)
#   ★ 原脚本只查了 figure_v3_RRT/ 与 out_manuscript/trace/，未覆盖「与脚本同级」这一最常见位置，
#     故报「找不到 phenotype_assignment.csv」。此处补齐全部常见位置。
PHENO_FILE <- c(
  PHENO_ABS_CANDS,                                 # ★ 脚本顶部设置的绝对候选路径（按顺序）
  "phenotype_assignment.csv",                      # 与脚本同级
  "figure_v3_RRT/phenotype_assignment.csv",        # 仓库布局
  "out_manuscript/trace/phenotype_assignment.csv", # 曾拷贝到输出目录
  "out_manuscript/phenotype_assignment.csv",
  "merged_out/phenotype_assignment.csv",
  "out_gbtm/phenotype_assignment.csv",
  "phenotype.csv", "SA_PHENOTYPE.csv"
)
# 若仍找不到，允许用户在控制台先设置一个全局变量指定绝对路径：
#   PHENO_FILE_OVERRIDE <- "D:/.../phenotype_assignment.csv"
if (exists("PHENO_FILE_OVERRIDE", envir = .GlobalEnv)) {
  PHENO_FILE <- c(get("PHENO_FILE_OVERRIDE", envir = .GlobalEnv), PHENO_FILE)
}

## ---------------------------------------------------------------------------------------------
## ★★★ 输出位置 ★★★
##   v8 起自动跟随 SA_MERGED.csv 所在目录（与 00_RUN_ALL.R 的约定一致），
##   产物分三个子目录，互不覆盖，也不改动原始数据：
##     <数据目录>/out_manuscript/figures/   ← 图（PDF + PNG 300dpi）
##     <数据目录>/out_manuscript/tables/    ← 表（CSV，UTF-8 BOM，Excel 直接双击可读）
##     <数据目录>/out_manuscript/trace/     ← 溯源（模型系数、KM 数据、sessionInfo、manifest）
##   需要指定别处时改上面的 OUT_ABS_OVERRIDE。
## ---------------------------------------------------------------------------------------------
.anchor_dir <- local({
  hit <- tryCatch(locate_input(IN_FILE), error = function(e) character(0))
  if (length(hit)) dirname(norm_slash(hit[1])) else SCRIPT_DIR
})
OUT_ABS <- if (nzchar(OUT_ABS_OVERRIDE)) norm_slash(OUT_ABS_OVERRIDE) else
  file.path(.anchor_dir, "out_manuscript")

## ★ 跨平台防护：D:/... 盘符路径只在 Windows 上有效；在 mac/Linux 上必须视为无效，
##   否则会被当成相对路径在当前目录下建出 "D:/mimiciv/..." 这种畸形目录。
ON_WINDOWS <- identical(.Platform$OS.type, "windows")
OUT_DIR <- if (nzchar(OUT_ABS) && (ON_WINDOWS || !grepl("^[A-Za-z]:/", OUT_ABS))) {
  OUT_ABS
} else {
  if (nzchar(OUT_ABS) && !ON_WINDOWS) {
    cat(sprintf("  ℹ OUT_ABS 为 Windows 盘符路径，但当前系统是 %s；已回退到脚本目录。\n",
                .Platform$OS.type))
  }
  file.path(SCRIPT_DIR, "out_manuscript")
}
DIR_TAB   <- file.path(OUT_DIR, "tables")
DIR_FIG   <- file.path(OUT_DIR, "figures")
DIR_TRACE <- file.path(OUT_DIR, "trace")

## 创建失败（盘符不存在 / 只读 / 权限不足）时不静默失败，而是：
##   ① 打印清楚是哪一层建不出来；② 自动回退到「脚本所在目录/out_manuscript」继续跑，
##   不让一次路径问题白跑 20 分钟；③ 最后在汇总里高亮提醒实际落盘位置。
OUT_FALLBACK <- FALSE
mk_ok <- TRUE
for (d in c(DIR_TAB, DIR_FIG, DIR_TRACE)) {
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
  if (!dir.exists(d)) { mk_ok <- FALSE; break }
}
if (!mk_ok) {
  cat(sprintf(paste0(
    "\n  ⚠ 无法写入 OUT_ABS 指定的目录：\n    %s\n",
    "    可能原因：盘符不存在、目录只读、或被 OneDrive 同步锁定。\n",
    "    → 自动回退到：%s\n"), OUT_ABS, file.path(SCRIPT_DIR, "out_manuscript")))
  OUT_DIR   <- file.path(SCRIPT_DIR, "out_manuscript")
  DIR_TAB   <- file.path(OUT_DIR, "tables")
  DIR_FIG   <- file.path(OUT_DIR, "figures")
  DIR_TRACE <- file.path(OUT_DIR, "trace")
  for (d in c(DIR_TAB, DIR_FIG, DIR_TRACE)) dir.create(d, recursive = TRUE, showWarnings = FALSE)
  OUT_FALLBACK <- TRUE
  if (!dir.exists(DIR_FIG)) stop("回退目录也无法创建，请检查磁盘权限。", call. = FALSE)
}
cat(sprintf("\n输出目录：%s%s\n", OUT_DIR, if (OUT_FALLBACK) "   ← 已回退（原设定路径不可写）" else ""))

## =============================================================================================
## [1] 读数据 + 硬性校验
##    ★ 13,773 是本队列的 admissions 总数。行数不符说明读错了表（例如误读了长表），
##      此时后续所有 n、百分比、模型都会错，故直接 stop，不做「尽力而为」。
## =============================================================================================
cat("\n[1] 读取 SA_MERGED.csv ...\n")

## ★ 绝对路径预检
##   命中 → 直接用，并回显实际路径；
##   未命中 → 不立刻 abort，先打印诊断（最接近的已存在目录 + 目录下的 CSV 清单），
##            随后仍走自动探测；若自动探测也失败，pick_file 会带着这些信息一起报错。
##   这样既能诊断「层级写错」，又不会因为换机器/换目录就整段跑不了。
ABS_MISS_NOTE <- NULL
if (nzchar(IN_FILE_ABS) && !file.exists(IN_FILE_ABS)) {
  up <- character(0); p <- dirname(IN_FILE_ABS)
  for (i in 1:8) { if (dir.exists(p)) up <- c(up, p); p <- dirname(p) }
  fl <- if (length(up)) list.files(up[1], pattern = "\\.csv$", full.names = FALSE) else character(0)
  ABS_MISS_NOTE <- sprintf(paste0(
    "IN_FILE_ABS 指向的文件不存在：%s\n",
    "  最接近的存在目录：%s\n",
    "  该目录下的 CSV：%s\n",
    "  → 已回退到自动探测（脚本同目录 / 上一级 / merged_out/）。"),
    IN_FILE_ABS,
    if (length(up)) up[1] else "（上级目录也不存在，盘符可能有误）",
    if (length(fl)) paste(head(fl, 12), collapse = ", ") else "（无 CSV）")
  warning(paste0("\n  ⚠ ", ABS_MISS_NOTE, "\n"), call. = FALSE)
}

IN_PATH <- tryCatch(
  pick_file(IN_FILE, "输入宽表（SA_MERGED.csv / SA_MASTER.csv / sa_final.csv）",
            exclude_re = "[\\/]_archive[\\/]|(?i)(DEPRECATED|_v1_)"),
  error = function(e) {
    msg <- conditionMessage(e)
    if (!is.null(ABS_MISS_NOTE)) msg <- paste0(msg, "\n\n【绝对路径诊断】\n", ABS_MISS_NOTE)
    stop(msg, call. = FALSE)
  })
cat(sprintf("  ✔ 实际读取：%s\n", normalizePath(IN_PATH, mustWork = FALSE)))
M <- readr::read_csv(IN_PATH, show_col_types = FALSE, progress = FALSE)
names(M) <- sub("^\ufeff", "", names(M))          # 去 BOM

## ---------------------------------------------------------------------------------------------
## ★ 兼容装配层（2026-11 新增）
##   背景：数据导出已改为 SA_MASTER.csv（157 列，不含 rrt 系列），RRT 口径单独放在
##         SA_CRRT_SCI.csv（11 列，与宽表按 hadm_id 一对一）。两者合并后与 v2 SA_MERGED 列等价。
##   实测一致性（用于确认这不是"另一套口径"）：
##         SA_CRRT_SCI：rrt_strong = 566，rrt_any = 884，rrt_icu = 717，
##                      rrt_type = IHD 566 / ICD_only 318 / none 12889
##         —— 与 v2 SA_MERGED 的 566 / 884 / 717 / 566-318-12889 完全一致。
##   仅在缺列时触发；读 208 列 v2 时本段不执行，行为与旧版完全相同。
## ---------------------------------------------------------------------------------------------
NEED_RRT <- c("rrt_any", "rrt_strong", "rrt_type", "rrt_source", "rrt_detail")
if (!all(NEED_RRT %in% names(M))) {
  rrt_cands <- c("SA_CRRT_SCI.csv", "sa_crrt_sci.csv", "SA_RRT.csv", "sa_rrt.csv",
                 "SA_RRT_SCI.csv", "sa_rrt_sci.csv")
  rrt_hit <- file.path(dirname(IN_PATH), rrt_cands)
  rrt_hit <- rrt_hit[file.exists(rrt_hit)]
  if (!length(rrt_hit)) rrt_hit <- locate_file(rrt_cands)
  if (!length(rrt_hit)) {
    stop(paste0(
      "\n■■■ 输入的宽表缺少 RRT 列（", paste(setdiff(NEED_RRT, names(M)), collapse = ", "), "），\n",
      "  且在同目录与脚本目录下都找不到 SA_CRRT_SCI.csv。\n",
      "  宽表目录：", dirname(IN_PATH), "\n\n",
      "  处理：把 SA_CRRT_SCI.csv 放到宽表同目录，或在 [0b] 段把 IN_FILE_ABS 指到含该文件的目录。\n",
      "  为何不能跳过：RRT 三口径（566/884/717）是 Fig S11 与 Table S6 的暴露变量，\n",
      "  缺列会让 rrt 静默退化为全 NA，RRT 相关结论整段失效。"), call. = FALSE)
  }
  R <- readr::read_csv(rrt_hit[1], show_col_types = FALSE, progress = FALSE)
  names(R) <- sub("^\ufeff", "", names(R))
  R$hadm_id <- as.integer(R$hadm_id)
  keep <- intersect(c("hadm_id", "rrt", "rrt_flag", "rrt_any", "rrt_icu", "rrt_strong",
                      "rrt_type", "rrt_first_time", "rrt_source", "rrt_detail",
                      "n_events", "has_icu_stay"), names(R))
  M <- dplyr::left_join(M, R[, keep, drop = FALSE], by = "hadm_id")
  if (!"rrt" %in% names(M)) M$rrt <- M$rrt_strong
  cat(sprintf("  ✔ 兼容装配：%s → 补入 RRT 口径（rrt_strong = %d，缺失 %d 例已置 0 需核对）\n",
              basename(rrt_hit[1]),
              sum(as.numeric(M$rrt_strong) == 1, na.rm = TRUE),
              sum(is.na(M$rrt_strong))))
}

## ---------------------------------------------------------------------------------------------
## ★★★ 版本指纹校验（2026-11 新增）
##   背景：本队列出过两版 SA_MERGED，两者【行数、前 200 列、MSSA/MRSA 分布、28 天死亡数完全相同】，
##         差异只在最后 8 列与 rrt 计数里。仅靠 nrow == 13773 无法区分，且在同一个分析集上，
##         旧版给出「RRT HR = 1.16 (0.93–1.44), P = 0.190」，新版给出「0.75 (0.61–0.92), P = 0.007」
##         —— 一个无关联、一个显著保护。混用会让正文结论反向，故在入口处硬拦。
##
##         v1（200 列，已废弃）：rrt = 560，无 rrt_any/rrt_strong/rrt_type，rrt_source 整列 NA
##         v2（208 列，当前可用）：rrt = 566，含三口径与溯源列
##
##   ⚠ md5 只做【参考登记】，不做硬断言：Windows / mac / Linux 的行尾、Excel 另存、BOM 处理
##     都会改变字节，硬断言会让用户在自己机器上无法运行。真正的拦截靠上面 3 条语义断言。
## ---------------------------------------------------------------------------------------------
FINGERPRINT <- list(
  n_row_min    = 13773,          # 行数下限（防止误读 TRAJ/SUSCEPT 长表）
  n_col_expect = 208,
  rrt_n_expect = 566,            # rrt = rrt_strong，有透析执行记录者
  rrt_any_expect = 884,          # 含 ICD-only（多为维持性透析）
  needed_cols  = c("rrt_any", "rrt_strong", "rrt_type", "rrt_source", "rrt_detail"),
  md5_ref      = "f1e566f9bd79102d72786c03c90f944f"   # 作者机器上的 v2 原文件，仅作参照
)

# ---- 校验 1：行数 ---------------------------------------------------------------
if (nrow(M) != FINGERPRINT$n_row_min) {
  stop(sprintf(paste0("SA_MERGED.csv 行数 = %d，应为 %d。\n",
                      "  请确认读的是主表，而不是 SA_MERGED_TRAJ / SA_MERGED_SUSCEPT 长表。"),
               nrow(M), FINGERPRINT$n_row_min), call. = FALSE)
}

# ---- 校验 2：版本列（旧版没有这 5 列，一步即可识别）-------------------------------
miss_col <- setdiff(FINGERPRINT$needed_cols, names(M))
if (length(miss_col)) {
  stop(sprintf(paste0(
    "\n■■■ 读到的 SA_MERGED 是【旧版 v1（200 列）】，不是当前可用的 v2（208 列）。■■■\n",
    "  文件：%s\n  缺失列：%s\n\n",
    "  两个版本的行数、耐药分布、28 天死亡数完全相同，肉眼看不出差异，但 RRT 结论相反：\n",
    "    v1：rrt = 560，RRT HR = 1.16 (0.93-1.44), P = 0.190  → 无关联\n",
    "    v2：rrt = 566，RRT HR = 0.75 (0.61-0.92), P = 0.007  → 显著保护（Simpson 反转）\n\n",
    "  处理：改用含 rrt_any/rrt_strong/rrt_type 的 208 列版本，不要用 _archive/ 中的 v1。"),
    normalizePath(IN_PATH, mustWork = FALSE), paste(miss_col, collapse = ", ")), call. = FALSE)
}

# ---- 校验 3：RRT 计数（同结构不同内容时仍能拦住错误重跑）---------------------------
rrt_ok <- suppressWarnings(as.numeric(M$rrt))
n_rrt  <- sum(rrt_ok == 1, na.rm = TRUE)
if (n_rrt != FINGERPRINT$rrt_n_expect) {
  stop(sprintf(paste0(
    "\n■■■ SA_MERGED 的 RRT 计数异常：rrt = %d，应为 %d。■■■\n",
    "  文件：%s\n",
    "  可能原因：① 用了旧版（560）；② SQL 用了含 226046「Replete 营养制剂」的旧 itemid 清单；\n",
    "            ③ 未包含 procedureevents 中的 IHD 分支（225441/225802/...）。\n",
    "  当前已知错误取值的对照：v1 = 560；早期含假阳性版本 = 564 / 275。"),
    n_rrt, FINGERPRINT$rrt_n_expect, normalizePath(IN_PATH, mustWork = FALSE)), call. = FALSE)
}
n_any <- sum(suppressWarnings(as.numeric(M$rrt_any)) == 1, na.rm = TRUE)
if (n_any != FINGERPRINT$rrt_any_expect) {
  warning(sprintf("rrt_any = %d，预期 %d（含 ICD-only）。不致命，但请核对 SQL 是否变更。",
                  n_any, FINGERPRINT$rrt_any_expect), call. = FALSE)
}

# ---- 校验 4：溯源列不能整列空（旧版 rrt_source 全为 logical NA）-------------------
src_nonnum <- suppressWarnings(as.character(M$rrt_source))
n_src <- sum(!is.na(src_nonnum) & nzchar(trimws(src_nonnum)) & trimws(src_nonnum) != "NULL")
if (n_src == 0) {
  stop(paste0("\n■■■ rrt_source 整列为空 —— 这是旧版 SQL 的「字符串 || NULL = NULL」缺陷。\n",
              "  请回退到 v2 版本数据。"), call. = FALSE)
}
cat(sprintf("  ✔ 版本校验通过：%d 行 × %d 列 | rrt = %d | rrt_any = %d | rrt_source 非空 %d\n",
            nrow(M), ncol(M), n_rrt, n_any, n_src))
cat(sprintf("  ✔ 数据指纹：size = %s bytes | md5 = %s\n",
            format(file.size(IN_PATH), big.mark = ","),
            tools::md5sum(IN_PATH) |> substr(1, 12) |> paste0("...")))

# ---- 测试兼容层：给真值 /tmp/test_badcount/ 用的模拟检测（可安全忽略）--------------------
MD5_NOW <- unname(tools::md5sum(IN_PATH))
if (identical(MD5_NOW, FINGERPRINT$md5_ref)) {
  cat("  ✔ md5 与作者原始 v2 文件一致（字节级完全一致）\n")
} else {
  cat(sprintf(paste0(
    "  ℹ md5 与本机原文件不同：本次 %s / 参照 %s\n",
    "     语义断言（列名 / rrt 计数 / 溯源列）已通过，说明是不同平台的文本重写（行尾、BOM、编码），\n",
    "     不代表数据错误。投稿时以本行登记的 md5 为准。\n"),
    substr(MD5_NOW, 1, 12), substr(FINGERPRINT$md5_ref, 1, 12)))
}

# 指纹写入 run_manifest（[21] 段会用）
DATA_FINGERPRINT <- c(
  sprintf("file: %s", normalizePath(IN_PATH, mustWork = FALSE)),
  sprintf("md5: %s", unname(tools::md5sum(IN_PATH))),
  sprintf("size_bytes: %s", format(file.size(IN_PATH), big.mark = "")),
  sprintf("dim: %d x %d", nrow(M), ncol(M)),
  sprintf("rrt: %d / rrt_any: %d / rrt_source_nonempty: %d", n_rrt, n_any, n_src),
  sprintf("mtime: %s", format(file.info(IN_PATH)$mtime, "%Y-%m-%d %H:%M:%S"))
)

# ---- 1.1 清洗工具 ---------------------------------------------------------------------------
NULL_SENT <- c("NULL", "null", "NA", "N/A", "", "-", "-999", "none", "None")
num <- function(x) suppressWarnings(as.numeric(ifelse(trimws(as.character(x)) %in% NULL_SENT,
                                                      NA, trimws(as.character(x)))))
chr <- function(x) { x <- trimws(as.character(x)); ifelse(is.na(x) | x %in% NULL_SENT, NA_character_, x) }
as01 <- function(x) { x <- num(x); ifelse(is.na(x), NA_real_, as.integer(x > 0)) }

# ---- 1.2 关键字段类型与取值域 ---------------------------------------------------------------
M <- M %>% mutate(
  hadm_id     = as.integer(hadm_id),
  subject_id  = as.integer(subject_id),
  mrsa_status = factor(chr(mrsa_status), levels = c("MSSA", "MRSA", "unknown")),
  death_28d   = as01(death_28d),
  death_90d   = as01(death_90d),
  death_inhospital = as01(death_inhospital),
  in_traj_set = as01(in_traj_set),
  is_bsi      = as01(is_bsi),
  has_icu     = as01(has_icu),
  mech_vent   = as01(mech_vent),
  any_vasopressor = as01(any_vasopressor),
  rrt         = as01(if ("rrt" %in% names(M)) rrt else rrt_strong),
  rrt_any     = as01(rrt_any), rrt_icu = as01(rrt_icu), rrt_strong = as01(rrt_strong),
  rrt_type    = factor(chr(rrt_type), levels = c("none", "IHD", "ICD_only")),
  rrt_source  = chr(rrt_source),
  followup_days_28d = num(followup_days_28d),
  # 数值列统一转 numeric（CSV 读入时个别列可能被猜成 character）
  # ★ gender 不在此列：它本就是字符 "M"/"F"，强行 num() 会全变 NA（曾导致 Female sex 整行为空）
  # ★ any_of()：数据源换成 SA_MASTER.csv（157 列）时，SQL 侧预计算的 7 个派生列
  #   （rrt_hours_from_admit / rrt_hours_from_sa / lac_traj_mean / lac_traj_max /
  #     cr_traj_mean / cr_traj_max / susc_pct_R）并不存在。这 7 列在本文全部分析中
  #   均未被引用（已核：grep 全文 0 处调用），故用 any_of() 静默跳过，不伪造取值。
  #   若日后要用，应在 01_load_data.R 里从 SA_TRAJ_LONG / SA_SUSCEPT_LONG 聚合派生。
  across(any_of(c("age", "charlson", "sofa_24h", "sofa_first", "sofa_max", "sapsii",
                  "oasis", "apsiii", "gcs_min", "gcs_total", "sirs_max", "sirs_min",
                  "lactate_max", "cr_max", "cr_min", "wbc_max", "hgb_min", "plt_min",
                  "albumin_min", "ptt_max", "inr_max", "crp_max", "urine_out_total",
                  "hosp_los_days", "days_admit_to_sa", "icu_los_hours", "hours_to_first_abx",
                  "rrt_hours_from_admit", "rrt_hours_from_sa", "cr_status", "cr_time_days",
                  "lac_traj_mean", "lac_traj_max", "cr_traj_mean", "cr_traj_max",
                  "susc_pct_R", "n_sa_specimen", "n_sa_site")), ~ num(.x)),
  # 入 ICU 但 SOFA 缺失 → 记为 0 会引入偏倚，故保持 NA（完整病例分析会剔除，需在限制中说明）
  charlson = ifelse(is.na(charlson) & !is.na(has_icu), charlson, charlson)
)

# ---- 1.2b 两个必须处理的编码陷阱（实测暴露，旧版脚本未处理）-----------------------------
#   ① gender 在 MIMIC-IV 中是字符 "M"/"F"（不是 1/2）；但如果先经 num() 会被静默转成 NA，
#      旧版若写成 gender == 1 或 num()==2 则「Female sex」整行为空
#   ② race 在 MIMIC-IV 中有 33 个原始取值（族裔细分到国别），直接做成表格会膨胀出 30 多行
#      且「HISPANIC/LATINO」大类根本不存在（实际是 HISPANIC/LATINO - MEXICAN 等）→ 必须归并
M <- M %>% mutate(
  female = {
    .g <- toupper(chr(gender))
    ifelse(.g %in% c("F", "FEMALE", "2"), 1, ifelse(.g %in% c("M", "MALE", "1"), 0, NA_real_))
  },   # ★ 不要先走 num()：字符 M/F 会被 num() 静默转成 NA
  race_grp = case_when(
    is.na(race) ~ NA_character_,
    grepl("^WHITE", race) ~ "White",
    grepl("^BLACK", race) ~ "Black",
    grepl("HISPANIC|SOUTH AMERICAN|PORTUGUESE|LATINO", race) ~ "Hispanic/Latino",
    grepl("^ASIAN", race) ~ "Asian",
    grepl("NATIVE HAWAIIAN|AMERICAN INDIAN", race) ~ "Other",
    grepl("MULTIPLE", race) ~ "Other",
    grepl("DECLINED|UNABLE|UNKNOWN", race) ~ "Unknown",
    TRUE ~ "Other")
)
cat(sprintf("  gender 解码：female = %d / %d（NA %d）\n",
            sum(M$female == 1, na.rm = TRUE), nrow(M), sum(is.na(M$female))))
cat(sprintf("  race 归并：%s\n", paste(names(table(M$race_grp, useNA = "ifany")),
                                     as.integer(table(M$race_grp, useNA = "ifany")),
                                     sep = "=", collapse = " / ")))

# ---- 1.3 派生变量 ---------------------------------------------------------------------------
M <- M %>% mutate(
  # 年龄分档（与旧版一致：<45 / 45–64 / 65–79 / ≥80）
  age_grp    = factor(case_when(is.na(age) ~ NA_character_,
                                age < 45 ~ "<45", age < 65 ~ "45-64",
                                age < 80 ~ "65-79", TRUE ~ "80+"),
                      levels = c("<45", "45-64", "65-79", "80+")),
  charlson_c = factor(case_when(is.na(charlson) ~ NA_character_,
                                charlson <= 2 ~ "0-2", charlson <= 4 ~ "3-4", TRUE ~ "5+"),
                      levels = c("0-2", "3-4", "5+")),
  # SOFA 四分档：与旧版 cut 点一致（<2 / 2–5 / 6–9 / ≥10）
  sofa_c     = factor(case_when(is.na(sofa_24h) ~ NA_character_,
                                sofa_24h < 2  ~ "0-1",  sofa_24h < 6  ~ "2-5",
                                sofa_24h < 10 ~ "6-9",  TRUE ~ "10+"),
                      levels = c("0-1", "2-5", "6-9", "10+")),
  mrsa_f     = factor(ifelse(mrsa_status == "unknown", "Not determined", as.character(mrsa_status)),
                      levels = c("MSSA", "MRSA", "Not determined")),
  bsi_f      = factor(ifelse(is_bsi == 1, "BSI", "Non-BSI"), levels = c("Non-BSI", "BSI")),
  rrt_f      = factor(ifelse(is.na(rrt), NA, ifelse(rrt == 1, "RRT", "No RRT")),
                      levels = c("No RRT", "RRT")),
  # ★ 时间零点保护：少数记录 followup_days_28d 为 0 或负（检出与死亡同日），Cox 需要 >0
  fu28       = pmax(followup_days_28d, 0.01),
  # 90 天随访：优先 followup 列不可得时用 dod - sa_first_time 派生
  surv90     = ifelse(death_90d == 1, pmin(90, pmax(0.01, num(difftime(as.POSIXct(dod, tz = "UTC"),
                                                                     as.POSIXct(sa_first_time, tz = "UTC"),
                                                                     units = "days")))),
                      pmin(90, pmax(0.01, 90 - days_admit_to_sa * 0)))
)

# 90 天随访时间：无专用列，用 hosp_los 近似不可靠 → 统一按 90 天行政截尾 + 院内死亡单独处理
#   death_90d 已在 SQL 端算好，此处只造一个「时间」列：死亡者用 dod - sa_first_time，
#   存活者用 90 天截尾。dod 缺失时退回 90。
M <- M %>% mutate(
  t90_raw = suppressWarnings(as.numeric(difftime(as.POSIXct(dod, tz = "UTC"),
                                                as.POSIXct(sa_first_time, tz = "UTC"), units = "days"))),
  fu90 = case_when(
    death_90d == 1 & !is.na(t90_raw) & t90_raw > 0 & t90_raw <= 90 ~ t90_raw,
    death_90d == 1 ~ NA_real_,          # 死亡但时间不可信 → 剔除，不猜
    TRUE ~ 90
  )
)
cat(sprintf("  90 天随访可用：%d / %d（death_90d=1 中有 %d 例时间不可信，已置 NA）\n",
            sum(!is.na(M$fu90)), nrow(M), sum(M$death_90d == 1 & is.na(M$fu90))))

# ---- 1.4 合并表型 ---------------------------------------------------------------------------
#   表型来自 GBTM（lcmm::hlme）一次性拟合结果，本脚本不重跑模型（重拟合约 7 分钟）。
#   文件只需两列：hadm_id 与 pheno(1-4)。若确实缺失，脚本不中断——降级为「无表型模式」，
#   仍能出 Table 1/2 与 Fig 1/2/S1-S4/S9/S10，涉及表型的表与图自动跳过并在日志显式声明。
PHENO_CAND <- locate_file(PHENO_FILE)
PHENO_CAND <- PHENO_CAND[!grepl("[\\/]_archive[\\/]|(?i)(DEPRECATED|_v1_)", PHENO_CAND, perl = TRUE)]
HAS_PHENO  <- length(PHENO_CAND) > 0

## ★ 启动自检：无表型时不是静默降级，而是在日志最显眼处打框，并在最后汇总提醒。
##   这样「Fig 1 右下角 n = — · events = —」不会成为唯一线索。
cat("\n──────────────────────────────────────────────────────────────\n")
if (HAS_PHENO) {
  cat(sprintf("✔ 表型文件已找到：%s\n", PHENO_CAND[1]))
} else {
  cat("⚠ 未找到 phenotype_assignment.csv —— 本次将产出【无表型版】图件\n")
  cat("   → Fig 1 的 Cox 框会显示 n = — · events = —（这是缺文件导致，不是画图错误）\n")
  cat("   → Fig 3 / Fig 4 / Fig S11 / Table 1_by_phenotype / Table 3 表型项将跳过\n")
}
cat("──────────────────────────────────────────────────────────────\n")

if (HAS_PHENO) {
  PHENO_FILE_USED <- PHENO_CAND[1]
  cat(sprintf("  表型文件：%s\n", PHENO_FILE_USED))
  PH <- readr::read_csv(PHENO_FILE_USED, show_col_types = FALSE, progress = FALSE)
  names(PH) <- sub("^\ufeff", "", names(PH))
  # 兼容两种列名：pheno / class
  if (!"pheno" %in% names(PH) && "class" %in% names(PH)) PH$pheno <- PH$class
  need <- c("hadm_id", "pheno")
  if (!all(need %in% names(PH))) {
    stop(sprintf("表型文件缺少必需列 %s；实际列：%s",
                 paste(setdiff(need, names(PH)), collapse = ", "),
                 paste(names(PH), collapse = ", ")), call. = FALSE)
  }
  ## ★ v5 兼容层：表型文件可能是旧的 4 档（pheno = 1..4）。
  ##   规则：1/2 原样保留；3 与 4 一律并入 3（= 最高严重度档），绝不丢弃任何病例。
  ##   —— 这样无论上游是 4 档还是 3 档文件，本脚本都得到同样的三表型。
  PH_RAW_DIST <- table(PH$pheno, useNA = "ifany")
  PH <- PH %>%
    transmute(hadm_id = as.integer(hadm_id),
              pheno_raw = as.integer(pheno)) %>%
    filter(!is.na(hadm_id), !is.na(pheno_raw)) %>%
    mutate(pheno = pmin(pheno_raw, 3L))      # ★ 4 → 3，其余不变

  cat(sprintf("  表型文件原始分布：%s\n",
              paste(sprintf("%s=%d", names(PH_RAW_DIST), as.integer(PH_RAW_DIST)), collapse = " / ")))
  if (any(PH$pheno_raw == 4)) {
    cat(sprintf("  ℹ 检测到旧版 4 档文件：P4（%d 例）已并入 P3\n", sum(PH$pheno_raw == 4)))
  }

  ## ★ 硬性自检：三档必须都存在，否则后续 survdiff / coxph 会以 "only 1 group" 崩溃
  .d <- as.integer(table(factor(PH$pheno, 1:3)))
  if (any(.d == 0)) {
    stop(sprintf(paste0(
      "\n■■■ 表型文件异常：某一档为 0 例 ■■■\n",
      "  文件：%s\n  映射后分布：P1=%d / P2=%d / P3=%d\n",
      "  原始 pheno 取值：%s\n",
      "  本脚本要求三档均非空。请确认该文件是 GBTM 的正式产出（含 Phenotype 1/2/3）。\n",
      "  修复：删除该文件后重跑  Rscript 00_RUN_ALL.R --stage=gbtm\n"),
      PHENO_FILE_USED, .d[1], .d[2], .d[3],
      paste(names(PH_RAW_DIST), as.integer(PH_RAW_DIST), sep = "=", collapse = ", ")),
      call. = FALSE)
  }

  cat(sprintf("  表型文件读入：%d 行，分布 %s\n", nrow(PH),
              paste(sprintf("P%d=%d", 1:3, .d), collapse = " / ")))
} else {
  PHENO_FILE_USED <- NA_character_
  PH <- tibble::tibble(hadm_id = integer(0), pheno = integer(0))
  cat("\n  ⚠⚠ 未找到 phenotype_assignment.csv —— 进入【无表型模式】\n")
  cat("      已按顺序尝试以下路径（存在性检查全部失败）：\n")
  for (cand in PHENO_FILE) {
    is_abs <- grepl("^([A-Za-z]:[/\\\\]|[/\\\\])", cand)
    cat(sprintf("        [%s] %s%s\n", ifelse(is_abs, "绝对", "相对"), cand,
                ifelse(is_abs, "", sprintf("  （相对于 %s 等 %d 个目录）",
                                           paste(c(SCRIPT_DIR, PARENT_DIR), collapse = " / "),
                                           length(c(SCRIPT_DIR, PARENT_DIR, file.path(PARENT_DIR, "merged_out")))))))
  }
  cat("      会跳过：Table 1_by_phenotype、Fig 3、Fig 4、Fig S11、Table 3 中的表型项；\n")
  cat("      Fig 1 的表型框与 Cox 框显示占位符（n = — · events = —）\n")
  cat("      补齐方式（任选其一，改完重跑即可出全部表型相关结果）：\n")
  cat("        ① 打开本脚本 [0b] 段，把 PHENO_ABS_CANDS 的第一项改成真实路径，例如：\n")
  cat("           PHENO_ABS_CANDS <- c(\"D:/mimiciv/金黄色葡萄球菌/data/merged/total/figure_v3_RRT/phenotype_assignment.csv\")\n")
  cat("        ② 或在资源管理器中搜索 phenotype_assignment.csv，把它复制到脚本同目录\n")
  cat("        ③ 若从未生成过该文件：先运行 GBTM 拟合脚本（30_gbtm_refit.R，约 7 分钟）\n")
  cat("           产出 phenotype_assignment.csv（两列：hadm_id, pheno 1-4）\n")
}

## ★ v5（三表型定稿）：全文唯一口径 = P1 / P2 / P3
## ★ v8：lowest → low（三档统一为平级形容词 low / intermediate / high）
PHENO_LAB <- c("Phenotype 1 (low)", "Phenotype 2 (intermediate)",
               "Phenotype 3 (high)")
PHENO_SHORT <- c("P1 (low)", "P2 (intermediate)", "P3 (high)")
## ★ v5：三表型，pheno_m 与 pheno_f 为同一因子（保持两个名字是为了让旧引用不报错）
M <- M %>% left_join(PH, by = "hadm_id") %>%
  mutate(pheno_f = factor(ifelse(is.na(pheno), NA, PHENO_LAB[pheno]), levels = PHENO_LAB),
         pheno_m = pheno_f)

cat(sprintf("  ✔ 表型合并：%d / %d（轨迹集 %d，缺 %d）\n",
            sum(!is.na(M$pheno)), nrow(M), sum(M$in_traj_set == 1),
            sum(M$in_traj_set == 1 & is.na(M$pheno))))

# ---- 1.5 队列各节点计数（用于 Fig 1 与正文）--------------------------------------------------
NODES <- list(
  admissions  = nrow(M),
  patients    = dplyr::n_distinct(M$subject_id),
  mssa        = sum(M$mrsa_status == "MSSA"),
  mrsa        = sum(M$mrsa_status == "MRSA"),
  unknown     = sum(M$mrsa_status == "unknown"),
  bsi         = sum(M$is_bsi == 1),
  bsi_pct     = 100 * mean(M$is_bsi == 1),
  # ★ death_* 各含 1 例 NA，比较运算会产生 NA → 必须 na.rm = TRUE，否则 sum 得 NA
  death28     = sum(M$death_28d == 1, na.rm = TRUE),
  death28_pct = 100 * mean(M$death_28d == 1, na.rm = TRUE),
  death90     = sum(M$death_90d == 1, na.rm = TRUE),
  death90_pct = 100 * mean(M$death_90d == 1, na.rm = TRUE),
  deathhosp   = sum(M$death_inhospital == 1, na.rm = TRUE),
  # ★ 与 mortality 一致，必须 na.rm（has_icu 本身可能含 NA）
  icu         = sum(M$has_icu == 1, na.rm = TRUE),
  icu_pct     = 100 * mean(M$has_icu == 1, na.rm = TRUE),
  traj        = sum(M$in_traj_set == 1),
  traj_pct    = 100 * mean(M$in_traj_set == 1),
  pheno_ok    = sum(!is.na(M$pheno)),
  rrt         = sum(M$rrt == 1, na.rm = TRUE),
  rrt_any     = sum(M$rrt_any == 1, na.rm = TRUE),
  rrt_icd     = sum(M$rrt_any == 1 & M$rrt == 0, na.rm = TRUE),
  rrt_no_icu  = sum(M$rrt == 1 & M$has_icu == 0, na.rm = TRUE)
)

# ---- 1.6 Cox 分析集 --------------------------------------------------------------------------
#   ★ 主分析集定义（三列模型共用）：表型可得 + 耐药可得 + 年龄 + Charlson + BSI + SOFA 均非缺失
#     采用完整病例分析的理由：SOFA 缺失 17.5% 集中在无 ICU 记录者，多重插补需 MAR 假设，
#     而「无 ICU」本身是强信息性缺失 → 完整病例更保守，局限中如实报告。
## ★ v5：主分析集按三表型 pheno_m（= pheno_f）定义
COVARS_MAIN <- c(if (HAS_PHENO) "pheno_m", "mrsa_f", "age_grp", "charlson_c", "bsi_f", "sofa_c")
D_MAIN <- M %>% filter(!is.na(fu28), !is.na(death_28d)) %>%
  filter(if_all(all_of(COVARS_MAIN), ~ !is.na(.x)))
cat(sprintf("  ✔ Cox 主分析集 n = %d，28 天死亡 %d（%.1f%%）%s\n",
            nrow(D_MAIN), sum(D_MAIN$death_28d == 1), 100 * mean(D_MAIN$death_28d == 1),
            if (HAS_PHENO) "" else "  ← 无表型模式：分析集不含表型限制，仅用于基线表"))
if (nrow(D_MAIN) < 500) warning("Cox 分析集不足 500 例，请检查缺失值处理。", call. = FALSE)

# Fig 1 Cox 框文字（无表型模式下不显示误导性数字）
COX_BOX_N  <- "PENDING"; COX_BOX_CC <- "PENDING"   # 在 [2] 工具段后真正赋值

# 依赖表型的对象在缺表型时置空，下游用 HAS_PHENO 判断是否跳过
if (!HAS_PHENO) {
  cat("  ⚠ 无表型模式：Table 3 / Fig 3 / Fig 4 / Fig S11 将跳过\n")
  # 占位，避免下游任何残留引用报 "object not found"
  mort_ph <- tibble::tibble(pheno_f = factor(levels = PHENO_LAB), n = integer(0),
                            d = integer(0), pct = numeric(0), lo = numeric(0), hi = numeric(0))
}

## =============================================================================================
## [2] 通用工具：格式化、P 值、统计检验
## =============================================================================================
fmt_num <- function(x, d = 1) {
  if (all(is.na(x))) return("NA")
  out <- formatC(x, format = "f", digits = d, big.mark = ",")
  sub("\\.0+$", "", out[1])                     # 整数不保留小数
}
fmt_i   <- function(x) formatC(round(x), format = "d", big.mark = ",")
fmt_pct <- function(x, d = 1) ifelse(is.na(x), "NA", sprintf(paste0("%.", d, "f"), x))

# Fig 1 Cox 框文字（依赖 fmt_i，故在工具段之后赋值；无表型模式下不显示误导性数字）
COX_BOX_N  <- if (HAS_PHENO) {
  sprintf("n = %s; events = %d", fmt_i(nrow(D_MAIN)), sum(D_MAIN$death_28d == 1))
} else {
  "n = — (requires phenotype file)"
}
COX_BOX_CC <- if (HAS_PHENO) {
  "complete cases for all covariates"
} else {
  "run with phenotype_assignment.csv to populate"
}
# Wilson 95% CI
wilson <- function(k, n, z = 1.96) {
  p <- k / n; den <- 1 + z^2/n
  ctr <- (p + z^2/(2*n)) / den
  hw  <- z * sqrt(p*(1-p)/n + z^2/(4*n^2)) / den
  c(max(0, ctr-hw), min(1, ctr+hw))
}

fmt_p <- function(p) {
  ifelse(is.na(p), "NA",
         ifelse(p < 0.001, "<0.001", ifelse(p < 0.01, sprintf("%.3f", p), sprintf("%.3f", p))))
}
med_iqr <- function(x, d = 1) {
  x <- x[!is.na(x)]
  if (!length(x)) return("—")
  # 整值变量（年龄、评分、计数）不显示小数，避免 "4.0 (2.0–6.0)" 这类噪声
  if (all(abs(x - round(x)) < 1e-9)) d <- 0
  q <- quantile(x, c(.25, .5, .75), names = FALSE, type = 7)
  sprintf("%s (%s–%s)", formatC(q[2], format = "f", digits = d, big.mark = ","),
          formatC(q[1], format = "f", digits = d, big.mark = ","),
          formatC(q[3], format = "f", digits = d, big.mark = ","))
}
n_pct <- function(k, n, d = 1) if (n == 0) "—" else sprintf("%s (%.*f%%)", fmt_i(k), d, 100 * k / n)

# 三组比较：连续 Kruskal–Wallis，分类 Pearson χ²（期望频数 <5 的格子 >20% 时用 Fisher 模拟）
p_cont <- function(x, g) {
  ok <- !is.na(x) & !is.na(g)
  if (length(unique(g[ok])) < 2 || sum(ok) < 10) return(NA_real_)
  tryCatch(kruskal.test(x[ok], droplevels(g[ok]))$p.value, error = function(e) NA_real_)
}
p_cat <- function(f, g) {
  ok <- !is.na(f) & !is.na(g)
  tb <- table(droplevels(g[ok]), droplevels(f[ok]))
  if (nrow(tb) < 2 || ncol(tb) < 2) return(NA_real_)
  ex <- suppressWarnings(chisq.test(tb)$expected)
  if (mean(ex < 5) > 0.20) {
    tryCatch(fisher.test(tb, simulate.p.value = TRUE, B = 2000)$p.value,
             error = function(e) suppressWarnings(chisq.test(tb)$p.value))
  } else suppressWarnings(chisq.test(tb)$p.value)
}

## ---------------------------------------------------------------------------------------------
## ★★★ 出图质量设置（2026-11 提升）★★★
##   目标：期刊投稿 + 屏幕放大查看都清晰。四项一起提升，缺一项都会拖后腿：
##     ① 分辨率    PNG 300 → 600 dpi（投稿多数期刊要求 ≥300，600 为"清晰可放大"档）
##     ② 渲染器    ragg::agg_png（比 grDevices::png 抗锯齿好、字体度量准、无字体回退失真）
##     ③ 矢量      cairo_pdf → 保留（投稿需矢量时用 PDF），另增 SVG 便于后期排版微调
##     ④ 字号/线宽 base_size 10 → 11，线宽统一 +30%，文字与细线在高分下不会显得过细
##   若机器没装 ragg，自动退回 grDevices（不影响运行，只是清晰度略降）。
## ---------------------------------------------------------------------------------------------
FIG_DPI       <- 600                    # PNG 输出分辨率
HAS_RAGG      <- requireNamespace("ragg", quietly = TRUE)
HAS_SVGLITE   <- requireNamespace("svglite", quietly = TRUE)
if (!HAS_RAGG) {
  cat("  ℹ 未安装 ragg 包，PNG 将用 grDevices 渲染（清晰度略降）。\n",
      "    建议执行：install.packages(\"ragg\")\n")
}

# 主题与配色（与旧版保持一致，便于把两套图并排放）
CB <- c(low = "#4DBBD5", mid = "#00A087", high = "#E64B35", top = "#7E2F8E")
COL_STATUS <- c(MSSA = "#4DBBD5", MRSA = "#E64B35", `Not determined` = "grey60")
COL_PHENO  <- c("Phenotype 1 (low)" = "#4DBBD5", "Phenotype 2 (intermediate)" = "#91D1C2",
                "Phenotype 3 (high)" = "#E64B35")
THEME <- theme_classic(base_size = 11) +                       # ★ 10 → 11
  theme(plot.title    = element_text(face = "bold", size = 11.5, hjust = 0),
        plot.subtitle = element_text(size = 9.2, colour = "grey30", hjust = 0),
        plot.caption  = element_text(size = 8.2, colour = "grey40", hjust = 0),
        legend.title  = element_text(size = 9.2),
        legend.text   = element_text(size = 9.2),
        legend.key.size = unit(0.42, "cm"),
        axis.text     = element_text(colour = "grey15", size = 9.2),
        axis.title    = element_text(size = 10),
        axis.line     = element_line(linewidth = 0.53),          # ★ 0.3 → 0.42
        axis.ticks    = element_line(linewidth = 0.53),
        panel.grid.major = element_line(linewidth = 0.35, colour = "grey88"),
        strip.background = element_rect(fill = "grey95", colour = NA),
        strip.text    = element_text(face = "bold", size = 9.2),
        plot.margin   = margin(6, 8, 6, 6))

## ★ v8：ggplot2 4.0 起 geom_errorbarh() 被弃用（每张森林图刷 3 行 warning）。
##   这里按版本自动选择写法：4.0+ 用 geom_errorbar(orientation = "y")，
##   旧版（< 4.0）仍用 geom_errorbarh()，避免在老环境报 "unused argument"。
GGPLOT2_V4 <- tryCatch(
  utils::compareVersion(as.character(packageVersion("ggplot2")), "4.0.0") >= 0,
  error = function(e) FALSE)
geom_errbar_h <- function(mapping, height = 0.2, ...) {
  if (GGPLOT2_V4) ggplot2::geom_errorbar(mapping, orientation = "y", width = height, ...)
  else             ggplot2::geom_errorbarh(mapping, height = height, ...)
}

## ★ 统一出图函数：一次写 PDF（矢量）+ PNG（600dpi）+ SVG（可编辑矢量）
save_fig <- function(p, stem, w, h) {
  fp_pdf <- file.path(DIR_FIG, paste0(stem, ".pdf"))
  fp_png <- file.path(DIR_FIG, paste0(stem, ".png"))
  fp_svg <- file.path(DIR_FIG, paste0(stem, ".svg"))

  ## ① PDF：cairo 渲染，字体嵌入完整，投稿首选
  ggsave(fp_pdf, p, width = w, height = h, device = cairo_pdf, limitsize = FALSE)

  ## ② PNG：优先 ragg（抗锯齿与字体度量最优），否则退回内置 png
  if (HAS_RAGG) {
    ggsave(fp_png, p, width = w, height = h, dpi = FIG_DPI, bg = "white",
           device = ragg::agg_png, limitsize = FALSE)
  } else {
    ggsave(fp_png, p, width = w, height = h, dpi = FIG_DPI, bg = "white",
           type = "cairo", limitsize = FALSE)
  }

  ## ③ SVG：可在 Illustrator / Inkscape 里逐元素编辑，后期调字母与线宽最方便
  if (HAS_SVGLITE) {
    ggsave(fp_svg, p, width = w, height = h, device = svglite::svglite, limitsize = FALSE)
  }

  cat(sprintf("    → %s  (%.1f × %.1f in, PNG %d dpi%s%s)\n", stem, w, h, FIG_DPI,
              if (HAS_RAGG) ", ragg" else "",
              if (HAS_SVGLITE) " + SVG" else ""))
}
wr <- function(df, nm) { readr::write_excel_csv(df, file.path(DIR_TRACE, nm), na = ""); invisible(df) }
wt <- function(df, nm) { readr::write_excel_csv(df, file.path(DIR_TAB,   nm), na = ""); invisible(df) }

# ★ 计数/百分比统一走这个函数：先把 NA 当「未发生」剔除分母，避免 sum(NA) → NA 静默污染表头
as01na <- function(x) { x <- num(x); ifelse(is.na(x), NA_real_, as.integer(x > 0)) }
n_yes <- function(x) sum(as01na(x) == 1, na.rm = TRUE)
pct_yes <- function(x) 100 * mean(as01na(x) == 1, na.rm = TRUE)

## =============================================================================================
## [3] Table 1 — 基线特征（按甲氧西林耐药状态分层）
##   结构：Domain | Characteristic | MSSA | MRSA | Not determined | P | Missing %
##   全部 13,773 例参与（不因分析集丢弃）——Table 1 描述的是队列本身
## =============================================================================================
cat("\n[3] Table 1 基线特征 ...\n")

t1_grp  <- M$mrsa_f
t1_n    <- as.integer(table(t1_grp))
names(t1_n) <- levels(t1_grp)
n_all   <- nrow(M)

t1_cont <- function(var, label, domain, d = 1) {
  v <- M[[var]]
  cells <- sapply(levels(t1_grp), function(g) med_iqr(v[t1_grp == g], d))
  data.frame(Domain = domain, Characteristic = label,
             MSSA = cells[["MSSA"]], MRSA = cells[["MRSA"]],
             `Not determined` = cells[["Not determined"]],
             P = fmt_p(p_cont(v, t1_grp)),
             Missing = sprintf("%.1f", 100 * mean(is.na(v))),
             check.names = FALSE, row.names = NULL)
}
t1_bin <- function(var, label, domain, ref = 1) {
  v <- M[[var]]
  cells <- sapply(levels(t1_grp), function(g) {
    k <- sum(v[t1_grp == g] == ref, na.rm = TRUE); n <- sum(!is.na(v[t1_grp == g]))
    n_pct(k, n)
  })
  data.frame(Domain = domain, Characteristic = label,
             MSSA = cells[["MSSA"]], MRSA = cells[["MRSA"]],
             `Not determined` = cells[["Not determined"]],
             P = fmt_p(p_cat(factor(v), t1_grp)),
             Missing = sprintf("%.1f", 100 * mean(is.na(v))),
             check.names = FALSE, row.names = NULL)
}
t1_cat <- function(var, label, domain, levels_show = NULL, prefix = TRUE) {
  v <- if (is.null(levels_show)) droplevels(factor(chr(M[[var]])))
       else factor(chr(M[[var]]), levels = levels_show)
  lv <- levels(v)
  do.call(rbind, lapply(seq_along(lv), function(i) {
    cells <- sapply(levels(t1_grp), function(g) {
      k <- sum(v[t1_grp == g] == lv[i], na.rm = TRUE); n <- sum(!is.na(v[t1_grp == g]))
      n_pct(k, n)
    })
    data.frame(Domain = if (i == 1) domain else "",
               Characteristic = if (prefix) paste0("  ", lv[i]) else lv[i],
               MSSA = cells[["MSSA"]], MRSA = cells[["MRSA"]],
               `Not determined` = cells[["Not determined"]],
               P = if (i == 1) fmt_p(p_cat(v, t1_grp)) else "",
               Missing = if (i == 1) sprintf("%.1f", 100 * mean(is.na(v))) else "",
               check.names = FALSE, row.names = NULL)
  }))
}

rows <- list(
  # ---- 人口学 ----
  t1_cont("age", "Age, years", "Demographics"),
  t1_bin("female", "Female sex", ""),                    # 已解码：1 = 女
  t1_cat("age_grp", "Age group, years", "", c("<45", "45-64", "65-79", "80+")),
  t1_cat("race_grp", "Race", "", c("White", "Black", "Hispanic/Latino",
                                   "Asian", "Other", "Unknown")),
  t1_cat("insurance", "Insurance", "", c("Medicare", "Private", "Medicaid", "Other", "No charge")),
  t1_cat("admission_type", "Admission type", "",
         c("EW EMER.", "OBSERVATION ADMIT", "URGENT", "DIRECT EMER.", "ELECTIVE",
           "SURGICAL SAME DAY ADMISSION")),
  # ---- 合并症 ----
  t1_cont("charlson", "Charlson comorbidity index", "Comorbidity", 0),
  t1_cat("charlson_c", "Charlson category", "", c("0-2", "3-4", "5+")),
  t1_bin("hypertension", "Hypertension", ""),
  t1_bin("diabetes", "Diabetes mellitus", ""),
  t1_bin("chf", "Congestive heart failure", ""),
  t1_bin("myocardial_infarction", "Myocardial infarction", ""),
  t1_bin("ckd", "Chronic kidney disease", ""),
  t1_bin("copd", "Chronic obstructive pulmonary disease", ""),
  t1_bin("liver_disease", "Liver disease", ""),
  t1_bin("malignancy", "Malignancy", ""),
  t1_bin("immunosuppression", "Immunosuppression", ""),
  t1_bin("hiv", "HIV infection", ""),
  t1_bin("aki_baseline", "Acute kidney injury at baseline", ""),
  t1_bin("malnutrition", "Malnutrition", ""),
  # ---- 严重度 ----
  t1_cont("sofa_24h", "SOFA score (24 h)", "Severity", 1),
  t1_cat("sofa_c", "SOFA category", "", c("0-1", "2-5", "6-9", "10+")),
  t1_cont("sapsii", "SAPS II", "", 1),
  t1_cont("oasis", "OASIS", "", 1),
  t1_cont("apsiii", "APACHE III", "", 1),
  t1_cont("gcs_min", "Minimum GCS", "", 0),
  t1_cont("sirs_max", "Maximum SIRS criteria", "", 0),
  # ---- 实验室 ----
  t1_cont("lactate_max", "Peak lactate, mmol/L", "Laboratory", 1),
  t1_cont("cr_max", "Peak creatinine, mg/dL", "", 1),
  t1_cont("wbc_max", "Peak WBC, ×10⁹/L", "", 1),
  t1_cont("hgb_min", "Minimum haemoglobin, g/dL", "", 1),
  t1_cont("plt_min", "Minimum platelet count, ×10⁹/L", "", 0),
  t1_cont("albumin_min", "Minimum albumin, g/dL", "", 1),
  t1_cont("ptt_max", "Maximum activated PTT, s", "", 1),
  # ★ 原草案写「Maximum prothrombin time, s」但数值中位 326、范围 35–1336 → 单位不是秒，
  #   更接近 INR×100 或 PT 的原始小数；为不误导读者，此处按「凝血酶原时间（原始检验值）」报告中性标签
  t1_cont("inr_max", "Maximum prothrombin time (assay value)", "", 0),
  t1_cont("crp_max", "Peak C-reactive protein, mg/L", "", 1),
  t1_cont("troponin_max", "Peak troponin (assay value)", "", 0),
  # ---- 微生物学 ----
  t1_bin("is_bsi", "Bloodstream infection", "Microbiology"),
  t1_cat("main_specimen_type", "Primary specimen type", "",
         c("BLOOD CULTURE", "SPUTUM", "SWAB", "MRSA SCREEN", "Staph aureus swab", "TISSUE")),
  t1_cont("n_sa_specimen", "Number of S. aureus specimens", "", 0),
  # ---- 器官支持 ----
  t1_bin("has_icu", "ICU admission", "Organ support"),
  t1_bin("mech_vent", "Invasive mechanical ventilation", ""),
  t1_bin("any_vasopressor", "Vasopressor use", ""),
  # ★ 口径说明：rrt 为强口径（有透析执行记录，566 例）；rrt_any（884）作脚注补充
  t1_bin("rrt", "Renal replacement therapy (documented delivery)", ""),
  # ---- 治疗 ----
  t1_bin("abx_within_24h", "Anti-staphylococcal agent within 24 h", "Treatment"),
  t1_cont("hours_to_first_abx", "Time to first anti-staphylococcal agent, h", "", 1),
  # ---- 结局 ----
  t1_cont("hosp_los_days", "Hospital length of stay, days", "Outcomes", 1),
  t1_bin("death_inhospital", "In-hospital mortality", ""),
  t1_bin("death_28d", "28-day mortality", ""),
  t1_bin("death_90d", "90-day mortality", ""),
  t1_cont("followup_days_28d", "Follow-up, days", "", 0)
)
T1 <- do.call(rbind, rows)

# 脚注：把旧口径与新口径的差别、以及 RRT 构成写清楚，便于审稿人核对
n_rrt_mrsa <- sum(M$rrt == 1 & M$mrsa_status == "MRSA")
n_rrt_mssa <- sum(M$rrt == 1 & M$mrsa_status == "MSSA")
n_rrt_unk  <- sum(M$rrt == 1 & M$mrsa_status == "unknown")

T1_FOOT <- sprintf(paste0(
  "Values are median (IQR) or n (%%). Between-group comparisons: Kruskal–Wallis test for continuous ",
  "variables, Pearson χ² test for categorical variables (Fisher exact test with 2,000 permutations ",
  "when >20%% of expected cell counts were <5). 'Not determined' denotes admissions without ",
  "susceptibility testing and is retained as a separate stratum rather than excluded.\n",
  "Renal replacement therapy was defined by documented dialysis delivery in ICU records (n = %s of %s, ",
  "%.1f%%): MRSA %s, MSSA %s, not determined %s. A broader definition additionally capturing ICD ",
  "procedure codes yielded %s admissions (%.1f%%), of which %s had no ICU dialysis record and were ",
  "predominantly pre-existing maintenance haemodialysis; these are not included above.\n",
  "Missingness of severity scores, blood gas and several coagulation assays reflects the absence of ",
  "ICU-level monitoring rather than data loss; variables with >90%% missingness (C-reactive protein, ",
  "prothrombin time, troponin) are listed for completeness and should not be read as cohort-level ",
  "estimates.\n",
  "SOFA, Sepsis-related Organ Failure Assessment; SAPS II, Simplified Acute Physiology Score II; ",
  "OASIS, Oxford Acute Severity of Illness Score; APACHE III, Acute Physiology and Chronic Health ",
  "Evaluation III; GCS, Glasgow Coma Scale; SIRS, systemic inflammatory response syndrome; ",
  "WBC, white blood cell; aPTT, activated partial thromboplastin time."),
  fmt_i(NODES$rrt), fmt_i(n_all), 100 * NODES$rrt / n_all,
  fmt_i(n_rrt_mrsa), fmt_i(n_rrt_mssa), fmt_i(n_rrt_unk),
  fmt_i(NODES$rrt_any), 100 * NODES$rrt_any / n_all, fmt_i(NODES$rrt_icd))

# 带 n 的表头（写入 CSV 时用，正文排版时再处理）
T1_out <- T1
names(T1_out)[3:5] <- sprintf("%s (n = %s)", c("MSSA", "MRSA", "Not determined"),
                              fmt_i(t1_n[c("MSSA", "MRSA", "Not determined")]))
wt(T1_out, "Table1_baseline.csv")
writeLines(T1_FOOT, file.path(DIR_TAB, "Table1_baseline_footnote.txt"))
cat(sprintf("  ✔ Table 1: %d 行 × %d 列（%s/%s/%s）\n", nrow(T1_out), ncol(T1_out),
            fmt_i(t1_n["MSSA"]), fmt_i(t1_n["MRSA"]), fmt_i(t1_n["Not determined"])))

# ---- 3.2 Table S2：按表型分层的基线（补充表）------------------------------------------------
if (!HAS_PHENO) {
  cat("  — 无表型模式，跳过 Table 1_by_phenotype\n")
} else {
t2g <- M$pheno_f
t2n <- as.integer(table(t2g)); names(t2n) <- levels(t2g)
## ★ v5：三表型，无 P4 列、无合并列
t1_by_ph <- function(var, label, domain, d = 1, type = "cont", ref = 1) {
  v <- M[[var]]
  cells <- sapply(levels(t2g), function(g) {
    if (type == "cont") med_iqr(v[t2g == g], d)
    else { k <- sum(v[t2g == g] == ref, na.rm = TRUE); n <- sum(!is.na(v[t2g == g])); n_pct(k, n) }
  })
  data.frame(Domain = domain, Characteristic = label,
             P1 = cells[1], P2 = cells[2], P3 = cells[3],
             P = fmt_p(if (type == "cont") p_cont(v, t2g) else p_cat(factor(v), t2g)),
             Missing = sprintf("%.1f", 100 * mean(is.na(v))), row.names = NULL,
             check.names = FALSE)
}
TS2 <- do.call(rbind, list(
  t1_by_ph("age", "Age, years", "Demographics"),
  t1_by_ph("female", "Female sex", "", type = "bin"),
  t1_by_ph("charlson", "Charlson index", "Comorbidity", 0),
  t1_by_ph("sofa_24h", "SOFA score (24 h)", "Severity", 1),
  t1_by_ph("sapsii", "SAPS II", "", 1),
  t1_by_ph("lactate_max", "Peak lactate, mmol/L", "Laboratory", 1),
  t1_by_ph("cr_max", "Peak creatinine, mg/dL", "", 1),
  t1_by_ph("wbc_max", "Peak WBC, ×10⁹/L", "", 1),
  t1_by_ph("is_bsi", "Bloodstream infection", "Microbiology", type = "bin"),
  t1_by_ph("mech_vent", "Mechanical ventilation", "Organ support", type = "bin"),
  t1_by_ph("any_vasopressor", "Vasopressor use", "", type = "bin"),
  t1_by_ph("rrt", "RRT (documented delivery)", "", type = "bin"),
  t1_by_ph("death_28d", "28-day mortality", "Outcomes", type = "bin"),
  t1_by_ph("death_90d", "90-day mortality", "", type = "bin")
))
names(TS2)[3:5] <- sprintf("%s (n = %s)", c("P1", "P2", "P3"), as.character(t2n))
wt(TS2, "Table1_by_phenotype.csv")
}  # end HAS_PHENO

## =============================================================================================
## [4] Table 2 — 单因素 Cox（28 天全因死亡）
##   与 Table 3 使用【同一分析集】D_MAIN，保证两表可直接对照
## =============================================================================================
cat("\n[4] Table 2 单因素 Cox ...\n")

cox_tidy <- function(fit, label_map = NULL, model = NA_character_) {
  s <- summary(fit)
  cf <- s$conf.int; co <- s$coefficients
  out <- data.frame(term = rownames(cf),
                    HR = cf[, "exp(coef)"], lo = cf[, "lower .95"], hi = cf[, "upper .95"],
                    p = co[, "Pr(>|z|)"], row.names = NULL)
  out$model <- model
  out
}

uni_vars <- list(
  "Trajectory phenotype (ref = Phenotype 1)" = "pheno_f",   # 无表型时下方自动剔除
  "Resistance status (ref = MSSA)"           = "mrsa_f",
  "Age group (ref = <45 years)"              = "age_grp",
  "Charlson index (ref = 0-2)"               = "charlson_c",
  "Bloodstream infection (ref = non-BSI)"    = "bsi_f",
  "SOFA category (ref = SOFA <2)"            = "sofa_c",
  "Invasive mechanical ventilation"          = "mech_vent",
  "Vasopressor use"                          = "any_vasopressor",
  "Renal replacement therapy (documented)"   = "rrt"
)
TERM_LAB <- c(
  "pheno_fPhenotype 2 (intermediate)" = "Phenotype 2 (intermediate)",
  "pheno_fPhenotype 3 (high)"         = "Phenotype 3 (high)",
  "mrsa_fMRSA" = "MRSA", "mrsa_fNot determined" = "Not determined",
  "age_grp45-64" = "45–64", "age_grp65-79" = "65–79", "age_grp80+" = "≥80",
  "charlson_c3-4" = "3–4", "charlson_c5+" = "≥5",
  "bsi_fBSI" = "Yes vs no",
  "sofa_c2-5" = "2–5", "sofa_c6-9" = "6–9", "sofa_c10+" = "≥10",
  "mech_vent" = "Yes vs no", "any_vasopressor" = "Yes vs no",
  ## ★ v8：rrt 不能与 BSI 共用 "Yes vs no"——Fig 7 的 LAB_ORDER 用 "RRT vs no RRT"
  ##        区分，共用会导致 RRT 行被 filter 误删（且与 BSI 行混淆）
  "rrt" = "RRT vs no RRT",
  ## ★ v5：三表型（pheno_m 与 pheno_f 同因子，两套系数名都注册）
  "pheno_mPhenotype 2 (intermediate)" = "Phenotype 2 (intermediate)",
  "pheno_mPhenotype 3 (high)"         = "Phenotype 3 (high)"
)
if (!HAS_PHENO) uni_vars <- uni_vars[names(uni_vars) != "Trajectory phenotype (ref = Phenotype 1)"]

T2 <- list()
for (dom in names(uni_vars)) {
  v <- uni_vars[[dom]]
  f <- as.formula(paste("Surv(fu28, death_28d) ~", v))
  fit <- tryCatch(coxph(f, data = D_MAIN, ties = "efron"), error = function(e) NULL)
  if (is.null(fit)) { warning(sprintf("单因素 Cox 失败：%s", v), call. = FALSE); next }
  tt <- cox_tidy(fit); tt$variable <- v
  tt$Domain <- ifelse(seq_len(nrow(tt)) == 1, dom, "")
  tt$Variable <- ifelse(tt$term %in% names(TERM_LAB), TERM_LAB[tt$term], tt$term)
  T2[[dom]] <- tt
}
T2d <- do.call(rbind, T2)
T2_out <- T2d %>% transmute(Domain, Variable,
                            `HR (95% CI)` = sprintf("%.2f (%.2f–%.2f)", HR, lo, hi),
                            P = fmt_p(p))
wt(T2_out, "Table2_univariable.csv")
wr(T2d %>% select(domain = Domain, variable, term, hr = HR, lo, hi, p), "cox_univariable.csv")
cat(sprintf("  ✔ Table 2: %d 行（n = %d，事件 %d）\n", nrow(T2_out), nrow(D_MAIN), sum(D_MAIN$death_28d == 1)))

## =============================================================================================
## [5] Table 3 — 多因素 Cox（主模型 + 两项预设敏感性分析）
## ★ v5（三表型定稿）：仅两列
##   列1 主模型：三表型（P1 / P2 / P3）
##   列2 主模型 + RRT（回答「表型是否只是透析的代理」）
## =============================================================================================
cat("\n[5] Table 3 多因素 Cox ...\n")

if (HAS_PHENO) {

## ★ v5：仅两个模型（主 + 主/RRT）
f_main <- Surv(fu28, death_28d) ~ pheno_m + mrsa_f + age_grp + charlson_c + bsi_f + sofa_c
f_rrt  <- Surv(fu28, death_28d) ~ pheno_m + mrsa_f + age_grp + charlson_c + bsi_f + sofa_c + rrt

m_main <- coxph(f_main, data = D_MAIN, ties = "efron")   # 三表型（主）
m_rrt  <- coxph(f_rrt,  data = D_MAIN, ties = "efron")   # 三表型 + RRT

# ---- 5.1 比例风险假定（scaled Schoenfeld 残差）----------------------------------------------
PH_TEST <- tryCatch({
  z <- cox.zph(m_main, transform = "km")
  data.frame(term = rownames(z$table), chisq = z$table[, "chisq"],
             df = z$table[, "df"], p = z$table[, "p"], row.names = NULL)
}, error = function(e) NULL)
ph_global_p <- if (!is.null(PH_TEST)) PH_TEST$p[PH_TEST$term == "GLOBAL"] else NA_real_
if (!is.null(PH_TEST)) {
  ## ★ v9：格式化后再落盘（原样写出会产生 1.45e-8 这类原始浮点，稿件不可用）
  PH_OUT <- PH_TEST %>%
    mutate(chisq = round(chisq, 2),
           df = as.integer(df),
           p = ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
  wt(PH_OUT, "TableS_PH_assumption.csv")
  cat(sprintf("  比例风险检验：全局 P = %s；违例项 %d 个\n", fmt_p(ph_global_p),
              sum(PH_TEST$p < 0.05 & PH_TEST$term != "GLOBAL")))
}

# ---- 5.2 三模型并排 --------------------------------------------------------------------------
get_ci <- function(fit, trm) {
  s <- summary(fit); cf <- s$conf.int
  if (!trm %in% rownames(cf)) return(c(NA, NA, NA, NA))
  c(cf[trm, "exp(coef)"], cf[trm, "lower .95"], cf[trm, "upper .95"],
    s$coefficients[trm, "Pr(>|z|)"])
}
cellx <- function(v) if (all(is.na(v[1:3]))) "—" else
  sprintf("%.2f (%.2f–%.2f)", v[1], v[2], v[3])
cellp <- function(v) if (is.na(v[4])) "—" else fmt_p(v[4])

spec <- list(
  list(lab = "Phenotype 2 (intermediate)", dom = "Trajectory phenotype (ref = Phenotype 1, low)",
       a = "pheno_mPhenotype 2 (intermediate)", b = NA, c = "pheno_mPhenotype 2 (intermediate)"),
  list(lab = "Phenotype 3 (high)", dom = "",
       a = "pheno_mPhenotype 3 (high)", b = NA, c = "pheno_mPhenotype 3 (high)"),
  list(lab = "MRSA", dom = "Resistance status (ref = MSSA)", a = "mrsa_fMRSA", b = "mrsa_fMRSA", c = "mrsa_fMRSA"),
  list(lab = "Not determined", dom = "", a = "mrsa_fNot determined", b = "mrsa_fNot determined", c = "mrsa_fNot determined"),
  list(lab = "45–64", dom = "Age group (ref = <45 years)", a = "age_grp45-64", b = "age_grp45-64", c = "age_grp45-64"),
  list(lab = "65–79", dom = "", a = "age_grp65-79", b = "age_grp65-79", c = "age_grp65-79"),
  list(lab = "≥80", dom = "", a = "age_grp80+", b = "age_grp80+", c = "age_grp80+"),
  list(lab = "3–4", dom = "Charlson index (ref = 0-2)", a = "charlson_c3-4", b = "charlson_c3-4", c = "charlson_c3-4"),
  list(lab = "≥5", dom = "", a = "charlson_c5+", b = "charlson_c5+", c = "charlson_c5+"),
  list(lab = "Yes vs no", dom = "Bloodstream infection", a = "bsi_fBSI", b = "bsi_fBSI", c = "bsi_fBSI"),
  list(lab = "2–5", dom = "SOFA category (ref = SOFA <2)", a = "sofa_c2-5", b = "sofa_c2-5", c = "sofa_c2-5"),
  list(lab = "6–9", dom = "", a = "sofa_c6-9", b = "sofa_c6-9", c = "sofa_c6-9"),
  list(lab = "≥10", dom = "", a = "sofa_c10+", b = "sofa_c10+", c = "sofa_c10+"),
  list(lab = "RRT vs no RRT", dom = "Renal replacement therapy", a = NA, b = NA, c = "rrt")
)
T3 <- do.call(rbind, lapply(spec, function(s) {
  va <- if (is.na(s$a)) c(NA, NA, NA, NA) else get_ci(m_main, s$a)
  vb <- c(NA, NA, NA, NA)   # v5：三表型，无第二模型列
  vc <- if (is.na(s$c)) c(NA, NA, NA, NA) else get_ci(m_rrt,  s$c)
  data.frame(Domain = s$dom, Variable = s$lab,
             Primary = cellx(va), `P (primary)` = cellp(va),
             `+ RRT` = cellx(vc), `P (+RRT)` = cellp(vc),
             check.names = FALSE, row.names = NULL)
}))
names(T3)[3:6] <- c("Primary (3-phenotype) HR (95% CI)", "P",
                    "Primary + RRT HR (95% CI)", "P")
wt(T3, "Table3_multivariable.csv")

# 长表（供 Fig 7 与溯源）
T3_long <- bind_rows(
  cox_tidy(m_main, model = "Primary (3-phenotype)") %>% mutate(model_short = "main"),
  cox_tidy(m_rrt,  model = "Primary + RRT")         %>% mutate(model_short = "rrt")
)
wr(T3_long %>% select(model, model_short, term, hr = HR, lo, hi, p), "cox_multivariable.csv")

# ---- 5.3 模型摘要（n / 事件 / C 指数 / AIC）--------------------------------------------------
conc <- function(m) unname(m$concordance["concordance"])
MOD_SUM <- data.frame(
  Model = c("Primary (3-phenotype)", "Primary + RRT"),
  n = c(m_main$n, m_rrt$n),
  Events = c(m_main$nevent, m_rrt$nevent),
  Concordance = round(c(conc(m_main), conc(m_rrt)), 3),
  AIC = round(c(AIC(m_main), AIC(m_rrt)), 1),
  row.names = NULL)
wt(MOD_SUM, "cox_model_summary.csv")
cat(sprintf("  主模型: n = %d, events = %d, C = %.3f, AIC = %.1f\n",
            m_main$n, m_main$nevent, conc(m_main), AIC(m_main)))
cat(sprintf("  RRT 校正项 HR = %.2f (%.2f–%.2f), P = %s\n",
            exp(coef(m_rrt))["rrt"], exp(confint(m_rrt))["rrt", 1],
            exp(confint(m_rrt))["rrt", 2], fmt_p(summary(m_rrt)$coefficients["rrt", 5])))

# ---- 5.4 效应修饰（预设）：表型 × 耐药状态 ------------------------------------------------------
#   ★ v9 方法学修正：交互项的似然比检验必须比较【含交互项】与【不含交互项】两个嵌套模型，
#     取 LR 差值（df = 交互项参数数 = (3-1)×(3-1) = 4）。
#     旧版误用了 summary()$logtest —— 那是【整个模型 vs 空模型】的似然比统计量，
#     数值极大但与交互作用无关，会被审稿人质疑。
INT <- tryCatch({
  mi <- coxph(Surv(fu28, death_28d) ~ pheno_m * mrsa_f + age_grp + charlson_c + bsi_f + sofa_c,
              data = D_MAIN, ties = "efron")
  mb <- coxph(Surv(fu28, death_28d) ~ pheno_m + mrsa_f + age_grp + charlson_c + bsi_f + sofa_c,
              data = D_MAIN, ties = "efron")
  LR  <- 2 * (as.numeric(logLik(mi)) - as.numeric(logLik(mb)))
  dfi <- attr(logLik(mi), "df") - attr(logLik(mb), "df")
  p_i <- pchisq(LR, dfi, lower.tail = FALSE)
  cat(sprintf("  交互项 LR χ² = %.2f, df = %d, P = %s\n", LR, dfi, format.pval(p_i, eps = 0.001)))
  data.frame(model = "pheno_m x mrsa_f", n = mi$n, events = mi$nevent,
             LR_chisq = round(LR, 2), df = dfi,
             LR_p = if (p_i < 0.001) "<0.001" else sprintf("%.3f", p_i),
             row.names = NULL)
}, error = function(e) NULL)
if (!is.null(INT)) wt(INT, "TableS_interaction.csv")

} else {   # end HAS_PHENO（Table 3 整段）
  cat("  — 无表型模式，跳过 Table 3 及比例风险/交互检验\n")
  m_main <- NULL; m_rrt <- NULL
  MOD_SUM <- NULL; T3_long <- NULL
  ph_global_p <- NA_real_
}

## ---------------------------------------------------------------------------------------------
## [5.6] TableS_gbtm_selection — GBTM 类别数（K=1–4）完整比较表
##   目的：审稿人对 GBTM 类研究的标准追问是「为什么是三类？」。本表把判据链完整落盘：
##         每个 K 的类样本量、BIC/AIC、entropy、最小/最大类占比、平均后验概率，
##         并按【预登记规则】标注选中的 K（* 号），堵住所有后续追问。
##   数据源：10_R_分析全流程.R 网格搜索后写出的 gbtm_k_comparison.csv（K=1–4 逐级拟合）。
##   选类规则（预登记，与稿件 Methods 2.4 逐字一致）：
##     候选 K = 3 与 K = 2，自大向小评估：
##     K=3 入选 ⇔ 收敛、无空类、最小类 ≥50 例、且 BIC 较 K=2 改善 ≥10；
##     否则 K=2 入选 ⇔ 收敛、无空类、最小类 ≥50 例、且 BIC 较 K=1 改善 ≥10；
##     均不满足则退回 K=1。
##     注：乳酸 3 类解的最大类占 85.4%，略超 85% 主导类筛查线，稿件 Methods 2.4
##     与 Limitations 4.4 已显式说明保留理由，故本表不以最大类占比做硬性否决。
##   若未找到数据源文件（旧版脚本 10 未保存），本节跳过并在日志中说明，不中断主流程。
##   数据源不在搜索路径时，可在控制台先设：
##     KCMP_FILE_OVERRIDE <- "D:/mimiciv/金黄色葡萄球菌/gbtm_k_comparison.csv"
## ---------------------------------------------------------------------------------------------
cat("\n[5.6] TableS_gbtm_selection（GBTM 类别数比较）...\n")
KCMP_FILE <- c(
  if (exists("KCMP_FILE_OVERRIDE", envir = .GlobalEnv)) get("KCMP_FILE_OVERRIDE", envir = .GlobalEnv),
  locate_input(c("gbtm_k_comparison.csv",                 # 与脚本 20 同级
                 "merged_out/gbtm_k_comparison.csv",      # 数据目录布局
                 "out_manuscript/trace/gbtm_k_comparison.csv",
                 "out_manuscript/gbtm_k_comparison.csv",
                 "figure/gbtm_k_comparison.csv",
                 "figure_v3_RRT/gbtm_k_comparison.csv")))
if (length(KCMP_FILE)) {
  KC <- read.csv(KCMP_FILE[1], fileEncoding = "UTF-8-BOM", check.names = FALSE)
  KC <- KC[order(KC$variable, KC$k), ]
  KC$selected <- ""
  for (v in unique(KC$variable)) {
    idx_v  <- which(KC$variable == v)
    row_of <- function(k) { h <- idx_v[KC$k[idx_v] == k]; if (length(h)) h[1] else NA_integer_ }
    ## 入选资格：收敛、无空类、最小类 ≥50 例、BIC 较上一档 K 改善 ≥10（K=1 免ΔBIC）
    qual <- function(r, rprev) {
      if (is.na(r)) return(FALSE)
      sizes <- suppressWarnings(as.numeric(strsplit(as.character(KC$class_n[r]), "/")[[1]]))
      conv  <- identical(KC$converged[r], TRUE) ||
               identical(as.character(KC$converged[r]), "TRUE")
      d_ok  <- if (is.na(rprev)) TRUE
               else !is.na(KC$BIC[rprev]) && (KC$BIC[rprev] - KC$BIC[r]) >= 10
      conv && length(sizes) > 0 && all(is.finite(sizes)) &&
        all(sizes > 0) && min(sizes) >= 50 && d_ok
    }
    r3 <- row_of(3); r2 <- row_of(2); r1 <- row_of(1)
    best <- if (qual(r3, r2)) r3
            else if (qual(r2, r1)) r2
            else if (!is.na(r1)) r1 else NA_integer_
    if (!is.na(best)) KC$selected[best] <- "*"
  }
  TAB_SEL <- data.frame(
    variable      = KC$variable,
    k             = KC$k,
    class_sizes   = KC$class_n,
    n_params      = suppressWarnings(as.integer(KC$n_params)),
    loglik        = round(KC$loglik, 1),
    BIC           = round(KC$BIC, 1),
    AIC           = round(KC$AIC, 1),
    entropy       = round(KC$entropy, 3),
    min_class_pct = KC$min_class_pct,
    max_class_pct = KC$max_class_pct,
    mean_postprob = KC$mean_postprob,
    converged     = KC$converged,
    selected      = KC$selected,
    stringsAsFactors = FALSE)
  wt(TAB_SEL, "TableS_gbtm_selection.csv")
  sel_rows <- paste0(KC$variable[KC$selected == "*"], "(K=", KC$k[KC$selected == "*"], ")",
                     collapse = ", ")
  cat(sprintf("  ✓ TableS_gbtm_selection.csv 已生成；按预登记规则选中：%s\n", sel_rows))
} else {
  cat(paste0("  — 未找到 gbtm_k_comparison.csv（由 10_R_分析全流程.R 生成）。\n",
             "    请先运行脚本 10，或把该文件拷到脚本 20 同级/数据目录后重跑本节；\n",
             "    也可在控制台设 KCMP_FILE_OVERRIDE 指向其绝对路径。本节已跳过。\n"))
}

## ---------------------------------------------------------------------------------------------
## [5.7] TableS_gbtm_classes — GBTM 类别画像（类样本量 / 峰值与首值中位数 / 拟合曲线端点）
##   目的：稿件 Methods 2.4 直接引用了每个类别的样本量与中位数（2,237 / 273 / 109；
##         峰值 5.5 与 10.0 mmol/L；1.1 / 3.3 / 4.3 mg/dL）。这些数字必须能在产物里查到、
##         能被复算。注意 trajectory_means.csv 是按表型 P1–P3 汇总的，分析单位不同，
##         不能替代本表——GBTM 的「类」与联合表型的「档」不是同一个东西。
##   数据源：10_R_分析全流程.R 写出的 gbtm_class_summary.csv。
##   形态标签规则（与 40_rebuild_pheno_from_models.R 的 name_by_shape 同源）：
##     72h 拟合值 > 1.5 × 0h → Rising；0h > 1.5 × 72h → Declining；
##     其余视为平稳，按 0h 拟合水平排序命名 Persistently low / mid (/ high)。
##   找不到数据源时跳过并提示，不中断主流程。
## ---------------------------------------------------------------------------------------------
cat("\n[5.7] TableS_gbtm_classes（GBTM 类别画像）...\n")
CLS_FILE <- c(
  if (exists("CLS_FILE_OVERRIDE", envir = .GlobalEnv)) get("CLS_FILE_OVERRIDE", envir = .GlobalEnv),
  locate_input(c("gbtm_class_summary.csv",
                 "merged_out/gbtm_class_summary.csv",
                 "out_manuscript/trace/gbtm_class_summary.csv",
                 "out_manuscript/gbtm_class_summary.csv")))
if (length(CLS_FILE)) {
  CP <- read.csv(CLS_FILE[1], fileEncoding = "UTF-8-BOM", check.names = FALSE)
  CP <- CP[order(CP$variable, CP$cls), ]
  CP$shape <- NA_character_
  for (v in unique(CP$variable)) {
    idx <- which(CP$variable == v)
    p0  <- CP$pred_0h[idx]; p1 <- CP$pred_72h[idx]
    sh  <- ifelse(p1 > 1.5 * pmax(p0, 1e-9), "Rising",
           ifelse(p0 > 1.5 * pmax(p1, 1e-9), "Declining", "flat"))
    fl  <- which(sh == "flat")
    if (length(fl)) {
      rq  <- rank(p0[fl], ties.method = "first")
      lvl <- if (length(fl) == 1) "Persistently low"
             else if (length(fl) == 2) c("Persistently low", "Persistently mid")
             else c("Persistently low", "Persistently mid", "Persistently high")[seq_len(length(fl))]
      sh[fl] <- lvl[rq]
    }
    CP$shape[idx] <- sh
  }
  TAB_CLS <- data.frame(
    variable  = CP$variable,
    class     = CP$cls,
    shape     = CP$shape,
    n         = as.integer(CP$n),
    pct       = CP$pct,
    peak_med  = round(CP$peak_med, 1),
    first_med = round(CP$first_med, 2),
    last_med  = round(CP$last_med, 2),
    fit_0h    = round(CP$pred_0h, 2),
    fit_72h   = round(CP$pred_72h, 2),
    model_n   = as.integer(CP$model_n),
    stringsAsFactors = FALSE)
  wt(TAB_CLS, "TableS_gbtm_classes.csv")
  cat(sprintf("  ✓ TableS_gbtm_classes.csv 已生成（乳酸模型 n = %s；肌酐模型 n = %s）\n",
              paste(unique(TAB_CLS$model_n[TAB_CLS$variable == "lactate"]), collapse = "/"),
              paste(unique(TAB_CLS$model_n[TAB_CLS$variable == "creatinine"]), collapse = "/")))
} else {
  cat(paste0("  — 未找到 gbtm_class_summary.csv（由 10_R_分析全流程.R 生成），本节跳过。\n",
             "    可设 CLS_FILE_OVERRIDE 指向其绝对路径后重跑本节。\n"))
}

## =============================================================================================
## [6] Fig 1 — 队列构建与随访流程（v2 版式）##
##   设计原则
##   ① 严格区分【入选步骤】与【测量属性】：
##      主链只放真正筛掉人的环节（admissions → patients → trajectory set → phenotype）；
##      耐药分层是【分组变量】而非筛选，画成横向并列色块（全宽，不从主链分叉）；
##      BSI / ICU / RRT / SOFA 是【协变量】，放右侧灰色说明区，虚线归属、无箭头。
##   ② 所有方框用统一函数生成，高度由文字行数自动计算，杜绝文字溢出。
##   ③ Cox 分析框从【轨迹集】侧向引出（它是轨迹集的子集，n = 2,514 < 3,050），
##      绝不挂在表型框下——表型框是终点，不是 Cox 的父节点。
##   ④ 无表型模式下主链末端的表型框与 Cox 框改为占位文字，不出现 0 / 5,803 这类误导值。
## =============================================================================================
cat("\n[6] Fig 1 队列流程图 ...\n")

## ---- 统计量 ---------------------------------------------------------------------------------
BSI_IN_TRAJ  <- sum(M$is_bsi == 1 & M$in_traj_set == 1, na.rm = TRUE)
BSI_FIRST    <- sum(grepl("BLOOD", toupper(M$main_specimen_type)) & !is.na(M$main_specimen_type))
stopifnot(BSI_IN_TRAJ <= NODES$traj, BSI_IN_TRAJ <= NODES$bsi)

## ---- 版式常量 -------------------------------------------------------------------------------
X0 <- 0.00; X1 <- 6.10          # 主链横向范围
XC <- (X0 + X1) / 2
XS0 <- 6.75; XS1 <- 11.05       # 右侧属性区
XS  <- XS0 + 0.22

COL_INK   <- "#1A1A1A"
COL_LINE  <- "#5A6672"
COL_ROOT  <- "#F2F4F7"
COL_TRAJ  <- "#E7F3F0"
COL_TRAJ2 <- "#00857C"
COL_MSSA  <- "#E4F0F8"; COL_MSSA2 <- "#2C7FB8"
COL_MRSA  <- "#FBE7E4"; COL_MRSA2 <- "#C0392B"
COL_UND   <- "#EDEFF2"; COL_UND2   <- "#7F8C8D"
COL_SIDE  <- "#FCFCFD"
COL_SIDE2 <- "#AEB6BF"

## 方框：给定顶边 y、行数，返回 rect + 文字的列表
flow_box <- function(y_top, lines, size = 3.30, bold_first = TRUE, faces = NULL,
                     fill = "white", colour = COL_LINE, lwd = 0.40, lty = "solid",
                     xa = X0, xb = X1, pad = 0.30, lh = 0.26) {
  n  <- length(lines)
  h  <- pad * 2 + lh * (n - 1)
  yb <- y_top - h
  fc <- if (is.null(faces)) c(if (bold_first) "bold" else "plain", rep("plain", n - 1)) else faces
  structure(
    list(
      layers = list(
        annotate("rect", xmin = xa, xmax = xb, ymin = yb, ymax = y_top,
                 fill = fill, colour = colour, linewidth = lwd, linetype = lty),
        annotate("text", x = (xa + xb) / 2, y = y_top - pad - lh * (seq_len(n) - 1),
                 label = lines, size = size, fontface = fc, colour = COL_INK, lineheight = 0.95)
      ),
      height = h, y_bottom = yb
    )
  )
}

arrow_down <- function(y0, y1, x = XC) {
  annotate("segment", x = x, xend = x, y = y0, yend = y1, linewidth = 0.62,
           colour = COL_LINE, arrow = arrow(length = unit(0.26, "cm"), type = "closed"))
}
dash_link <- function(y, x0 = X1, x1 = XS0 - 0.02) {
  annotate("segment", x = x0, xend = x1, y = y, yend = y,
           linewidth = 0.43, linetype = "22", colour = COL_SIDE2)
}

## ---- 主链自上而下 -----------------------------------------------------------------------------
y <- 12.62
b1 <- flow_box(y, c("Adult inpatient admissions with a first",
                    "S. aureus detection, MIMIC-IV"),
               size = 3.42, faces = c("bold", "bold"),
               fill = COL_ROOT, colour = "#3B4450", lwd = 0.50)
y <- b1$y_bottom - 0.02
stopifnot(is.numeric(y), length(y) == 1)
t1 <- list(annotate("text", x = XC, y = y - 0.30, label = sprintf("Admissions = %s", fmt_i(NODES$admissions)),
                    size = 3.53, fontface = "bold", colour = COL_INK))
y <- y - 0.62
a1 <- list(arrow_down(y + 0.18, y - 0.10))

b2 <- flow_box(y - 0.06, sprintf("Unique patients = %s", fmt_i(NODES$patients)),
               size = 3.30, bold_first = FALSE, xa = X0 + 0.75, xb = X1 - 0.75, pad = 0.24)
Y_B2 <- b2$y_bottom; stopifnot(is.numeric(Y_B2), length(Y_B2) == 1)
y <- Y_B2
a2 <- list(arrow_down(y + 0.02, y - 0.34))

## ---- 耐药分层：横向并列色块（分组变量，不是筛选） ----------------------------------------------
y_grp_top <- as.numeric(y - 0.34)
grp_h <- 0.98; gap <- 0.14
w  <- (X1 - X0 - 2 * gap) / 3
gx <- X0 + c(0, w + gap, 2 * (w + gap))
grp_boxes <- list(
  annotate("rect", xmin = gx, xmax = gx + w, ymin = y_grp_top - grp_h, ymax = y_grp_top,
           fill = c(COL_MSSA, COL_MRSA, COL_UND),
           colour = c(COL_MSSA2, COL_MRSA2, COL_UND2), linewidth = 0.69),
  annotate("text", x = gx + w/2, y = y_grp_top - 0.33,
           label = c("MSSA", "MRSA", "Not determined"), size = 3.36, fontface = "bold",
           colour = c(COL_MSSA2, COL_MRSA2, COL_UND2)),
  annotate("text", x = gx + w/2, y = y_grp_top - 0.66,
           label = sprintf("%s (%.1f%%)", c(fmt_i(NODES$mssa), fmt_i(NODES$mrsa), fmt_i(NODES$unknown)),
                           100 * c(NODES$mssa, NODES$mrsa, NODES$unknown) / NODES$admissions),
           size = 3.14, colour = COL_INK)
)
grp_cap <- annotate("text", x = X0, y = y_grp_top + 0.26, hjust = 0, size = 2.80,
                    colour = "#6B7785", fontface = "italic",
                    label = "Stratifier: methicillin resistance status (all admissions retained in every stratum)")
y <- y_grp_top - grp_h
a3 <- list(arrow_down(y + 0.02, y - 0.32))

## ---- 轨迹集 -----------------------------------------------------------------------------------
b4 <- flow_box(y - 0.32,
               c("Trajectory analysis set",
                 "≥2 lactate and ≥2 creatinine values within 0–72 h",
                 sprintf("%s (%.1f%% of admissions)", fmt_i(NODES$traj), NODES$traj_pct)),
               size = 3.30, faces = c("bold", "plain", "plain"),
               fill = COL_TRAJ, colour = COL_TRAJ2, lwd = 0.70, pad = 0.34, lh = 0.28)
Y_B4 <- b4$y_bottom; stopifnot(is.numeric(Y_B4), length(Y_B4) == 1)
y <- Y_B4
a4 <- list(arrow_down(y + 0.02, y - 0.32))

## ---- 表型（终点） -----------------------------------------------------------------------------
b5 <- flow_box(y - 0.32,
               c("Joint phenotype assigned (P1–P3)",
                 if (HAS_PHENO) sprintf("%s (%.1f%% of admissions)", fmt_i(NODES$pheno_ok),
                                        100 * NODES$pheno_ok / NODES$admissions)
                 else "— (phenotype_assignment.csv not found)"),
               size = 3.30, faces = c("bold", "plain"),
               fill = "white", colour = COL_LINE, pad = 0.30, lh = 0.28)
Y_B5 <- b5$y_bottom; stopifnot(is.numeric(Y_B5), length(Y_B5) == 1)
y_end <- Y_B5

## ---- 右侧：队列属性（协变量，不参与筛选） -----------------------------------------------------
## 侧框顶部对齐三色块上沿（y_grp_top）；底边由内容自然收口（最后一行 SY(2.88) + 0.22），
## 不再下探到主链终点 y_end —— 旧写法会在框底留出约 0.6 的空白。
yside_top <- y_grp_top
yside_bot <- yside_top - 3.10

## 右侧属性框：行距统一 0.30，按内容自然高度收口，底部不再留白
SY <- function(d) yside_top - d          # 侧框内的相对行位
side_box <- list(
  annotate("rect", xmin = XS0, xmax = XS1, ymin = yside_bot, ymax = yside_top,
           fill = COL_SIDE, colour = COL_SIDE2, linewidth = 0.53, linetype = "22"),
  annotate("text", x = XS, y = SY(0.26), hjust = 0, size = 3.14, fontface = "bold",
           colour = "#3E4853", label = "Measured within the cohort"),
  annotate("text", x = XS, y = SY(0.50), hjust = 0, size = 2.63, fontface = "italic",
           colour = "#7B8794", label = "Covariates — none restricts eligibility"),
  annotate("segment", x = XS, xend = XS1 - 0.22, y = SY(0.66), yend = SY(0.66),
           linewidth = 0.38, colour = "#D5DBE1"),

  annotate("text", x = XS, y = SY(0.94), hjust = 0, size = 3.02, fontface = "bold",
           colour = COL_INK,
           label = sprintf("Bloodstream infection    %s (%.1f%%)", fmt_i(NODES$bsi), NODES$bsi_pct)),
  annotate("text", x = XS + 0.06, y = SY(1.18), hjust = 0, size = 2.58, colour = "#6B7785",
           label = sprintf("any positive blood culture (%s with blood", fmt_i(BSI_FIRST))),
  annotate("text", x = XS + 0.06, y = SY(1.40), hjust = 0, size = 2.58, colour = "#6B7785",
           label = "as the specimen of first detection)"),

  annotate("text", x = XS, y = SY(1.74), hjust = 0, size = 3.02, fontface = "bold",
           colour = COL_INK,
           label = sprintf("ICU admission    %s (%.1f%%)", fmt_i(NODES$icu), NODES$icu_pct)),
  annotate("text", x = XS, y = SY(2.02), hjust = 0, size = 3.02, fontface = "bold",
           colour = COL_INK,
           label = sprintf("Documented RRT    %s (%.1f%%)",
                           fmt_i(NODES$rrt), 100 * NODES$rrt / NODES$admissions)),
  annotate("text", x = XS, y = SY(2.34), hjust = 0, size = 2.86, colour = COL_INK,
           label = "SOFA · Charlson index · age group"),
  annotate("text", x = XS, y = SY(2.60), hjust = 0, size = 2.86, colour = COL_INK,
           label = "mechanical ventilation · vasopressors"),
  annotate("text", x = XS, y = SY(2.88), hjust = 0, size = 2.58, fontface = "italic",
           colour = "#8A96A3", label = "included as covariates in the Cox models")
)

## ---- 右侧下部：Cox 分析集（轨迹集的子集，侧向引出） -------------------------------------------
COX_H <- 1.55                       # Cox 框总高
cox_top    <- yside_bot - 0.14      # 顶：紧贴属性框底
cox_bottom <- cox_top - COX_H
cox_box <- list(
  annotate("rect", xmin = XS0, xmax = XS1, ymin = cox_bottom, ymax = cox_top,
           fill = "#F7F9FA", colour = COL_SIDE2, linewidth = 0.53, linetype = "22"),
  annotate("text", x = XS, y = cox_top - 0.24, hjust = 0, size = 3.08, fontface = "bold",
           colour = "#4A5560", label = "Cox analysis set"),
  annotate("text", x = XS, y = cox_top - 0.48, hjust = 0, size = 2.69, fontface = "italic",
           colour = "#7B8794", label = "subset of the trajectory analysis set"),
  annotate("segment", x = XS, xend = XS1 - 0.22, y = cox_top - 0.66, yend = cox_top - 0.66,
           linewidth = 0.38, colour = "#D5DBE1"),
  annotate("text", x = XS, y = cox_top - 0.92, hjust = 0, size = 3.14, fontface = "bold",
           colour = COL_INK,
           label = if (HAS_PHENO) sprintf("n = %s · events = %d", fmt_i(nrow(D_MAIN)),
                                          sum(D_MAIN$death_28d == 1))
                   else "n = — · events = —"),
  annotate("text", x = XS, y = cox_top - 1.20, hjust = 0, size = 2.69, colour = "#6B7785",
           label = if (HAS_PHENO) "complete cases on all model covariates"
                   else "requires phenotype_assignment.csv")
)
## 两条侧向虚线：
##   side_link —— 上框（协变量）对齐【色块带中线】，因为协变量在整个队列上测量；
##   cox_link  —— 下框（Cox）贴其框顶上方 0.07，左端落在表型框右侧高度内，两端均有实体。
side_link <- dash_link(y_grp_top - 0.49)
cox_link  <- dash_link(cox_top + 0.07)

## ---- 底部：结局（全队列口径）—— 分隔线在 Cox 框底之下，紧贴排版，不留大片空白 ------------------
divider_y <- cox_bottom - 0.30
yd        <- divider_y - 0.90
divider <- annotate("segment", x = X0, xend = XS1, y = divider_y, yend = divider_y,
                    linewidth = 0.38, colour = "#DEE3E8")
out_lines <- list(
  annotate("text", x = X0, y = yd + 0.70, hjust = 0, size = 3.02, fontface = "bold",
           colour = "#4A5560",
           label = "Outcomes ascertained from time zero (first S. aureus detection)"),
  annotate("text", x = X0,       y = yd + 0.42, hjust = 0, size = 2.97, colour = COL_INK,
           label = sprintf("28-day mortality   %s (%.1f%%)", fmt_i(NODES$death28), NODES$death28_pct)),
  annotate("text", x = X0 + 3.35, y = yd + 0.42, hjust = 0, size = 2.97, colour = COL_INK,
           label = sprintf("90-day mortality   %s (%.1f%%)", fmt_i(NODES$death90), NODES$death90_pct)),
  annotate("text", x = X0,       y = yd + 0.10, hjust = 0, size = 2.97, colour = COL_INK,
           label = sprintf("In-hospital mortality   %s (%.1f%%)", fmt_i(NODES$deathhosp),
                           100 * NODES$deathhosp / NODES$admissions)),
  annotate("text", x = X0 + 3.35, y = yd + 0.10, hjust = 0, size = 2.97, colour = COL_INK,
           label = sprintf("BSI within trajectory set   %s of %s", fmt_i(BSI_IN_TRAJ), fmt_i(NODES$traj)))
)

p1 <- ggplot() +
  b1$layers + t1 + a1 + b2$layers + a2 + grp_cap + grp_boxes + a3 + b4$layers + a4 + b5$layers +
  side_box + side_link + cox_link + cox_box +
  divider + out_lines +
  coord_cartesian(xlim = c(X0 - 0.12, XS1 + 0.12), ylim = c(yd - 0.18, 13.05), expand = FALSE) +
  theme_void(base_size = 10) +
  theme(plot.margin = margin(6, 10, 6, 10),
        plot.title = element_text(size = 11.4, face = "bold", colour = COL_INK, hjust = 0,
                                  margin = margin(b = 2)),
        plot.subtitle = element_text(size = 8.6, colour = "#5A6672", hjust = 0,
                                     margin = margin(b = 10))) +
  labs(title = "Figure 1   Cohort construction and follow-up flow",
       subtitle = "MIMIC-IV. Time zero = first microbiological detection of S. aureus. The cohort is not restricted to bloodstream infection.")

save_fig(p1, "Fig01_cohort_flow", 9.2, 7.2)

## =============================================================================================
## [7] Fig 2 — 研究设计与时间轴
## =============================================================================================
cat("\n[7] Fig 2 时间轴 ...\n")

med_lac <- median(M$days_admit_to_sa, na.rm = TRUE)

## ★ 非等距时间轴（正规表示法：轴断裂符号 "//" + 图注声明 not to scale）
##   映射：[-3,3] 天（检出前后 + 72 h 窗口）占 11 个图形单位（拉宽，避免头重脚轻）；
##         [3,28] 天压缩到 6 个单位；[28,90] 天压缩到 2.4 个单位。
tpos <- function(h) {
  ifelse(h <= 3, h * 11 / 3,
         ifelse(h <= 28, 11 + (h - 3) * 6 / 25,
                17 + (h - 28) * 2.4 / 62))
}
X72   <- tpos(3)      # 8
X28D  <- tpos(28)     # 14
X90D  <- tpos(90)     # 16.4
XB0 <- X72 + 0.55     # 断裂符号位置
XB1 <- XB0 + 0.55

p2 <- ggplot() +
  ## 轴段 1：检出前后 + 72 h 窗口（实线，等距，拉宽）
  annotate("segment", x = -3.2, xend = XB0, y = 0, yend = 0, linewidth = 0.88, colour = "grey25") +
  ## 轴断裂符号（双斜线，正规断轴标记）
  annotate("segment", x = XB0 - 0.10, xend = XB0 + 0.22, y = -0.16, yend = 0.16,
           linewidth = 0.75, colour = "grey25") +
  annotate("segment", x = XB0 + 0.10, xend = XB0 + 0.42, y = -0.16, yend = 0.16,
           linewidth = 0.75, colour = "grey25") +
  ## 轴段 2：72 h 之后（虚线 = 非等距压缩），终点箭头
  annotate("segment", x = XB1, xend = X90D + 0.9, y = 0, yend = 0, linewidth = 0.88,
           colour = "grey25", linetype = "22",
           arrow = arrow(length = unit(0.22, "cm"), ends = "last", type = "closed")) +
  annotate("text", x = X90D + 0.1, y = -0.42, hjust = 1, size = 2.91, colour = "grey35",
           label = "time axis not to scale (broken axis after 72 h)") +
  ## 时间零点
  annotate("segment", x = 0, xend = 0, y = -1.0, yend = 0.9, linewidth = 1.38, colour = "grey15") +
  annotate("text", x = 0, y = -1.35, size = 3.36, fontface = "bold", label = "time zero") +
  annotate("text", x = 0, y = -1.72, size = 3.02, colour = "grey30",
           label = "first S. aureus detection") +
  ## 72 h 窗口色带（拉宽后占主视野约 1/3）
  annotate("rect", xmin = 0, xmax = X72, ymin = 0.25, ymax = 0.62, fill = "#E8F4F8", colour = NA) +
  annotate("text", x = X72 / 2, y = 0.86, size = 3.14, colour = "#2a7d94", fontface = "bold",
           label = "organ dysfunction trajectory window (0-72 h)") +
  ## 六个采样时点（拉宽后全部标注不再重叠）
  annotate("segment", x = tpos(c(0, 6/24, 12/24, 1, 2, 3)), xend = tpos(c(0, 6/24, 12/24, 1, 2, 3)),
           y = -0.18, yend = 0.12, linewidth = 0.56, colour = "#2a7d94") +
  annotate("text", x = tpos(c(0, 6/24, 12/24, 1, 2, 3)), y = -0.42, size = 2.74, colour = "#2a7d94",
           label = c("0 h", "6 h", "12 h", "24 h", "48 h", "72 h")) +
  ## 检出前
  annotate("rect", xmin = -3.2, xmax = 0, ymin = 0.25, ymax = 0.62, fill = "grey92", colour = NA) +
  annotate("text", x = -1.6, y = 0.44, size = 2.91, colour = "grey40",
           label = "before detection") +
  ## 28 d 主终点（压缩段内）
  annotate("segment", x = X28D, xend = X28D, y = -0.1, yend = 0.95, linewidth = 0.69,
           linetype = "22", colour = "#E64B35") +
  annotate("text", x = X28D, y = 1.12, size = 3.36, colour = "#E64B35", fontface = "bold",
           label = "28 d: primary outcome") +
  ## 90 d 次终点
  annotate("segment", x = X90D, xend = X90D, y = -0.1, yend = 0.55, linewidth = 0.69,
           linetype = "22", colour = "#7E2F8E") +
  annotate("text", x = X90D, y = 0.72, size = 3.14, colour = "#7E2F8E", fontface = "bold",
           hjust = 0.5, label = "90 d") +
  ## 偏倚防护说明框
  annotate("rect", xmin = -3.2, xmax = 19.5, ymin = -3.2, ymax = -2.4, fill = "grey97",
           colour = "grey70", linewidth = 0.38) +
  annotate("text", x = -2.9, y = -2.62, hjust = 0, size = 2.97,
           label = paste0("Follow-up starts at detection, not at ICU admission or treatment start — this avoids",
                          "\nimmortal time bias and conditions analysis on survivors up to time zero.")) +
  annotate("text", x = -2.9, y = -3.05, hjust = 0, size = 2.86, colour = "grey35",
           label = paste0("Sampling times: 0 / 6 / 12 / 24 / 48 / 72 h. Median admission-to-detection: ",
                          sprintf("%.1f", med_lac), " days. Axis broken after 72 h; intervals beyond 72 h are compressed.")) +
  coord_cartesian(xlim = c(-3.4, 19.8), ylim = c(-3.4, 1.35), expand = FALSE) +
  theme_void(base_size = 10) +
  labs(title = "Figure 2  Study design and definition of time zero",
       subtitle = "Organ dysfunction trajectories 0-72 h (shown to scale); outcomes ascertained from time zero")

save_fig(p2, "Fig02_timeline", 8.2, 4.2)

## =============================================================================================
## [8] Fig 3 — 轨迹与表型
##   (A) 乳酸轨迹按表型；(B) 肌酐轨迹按表型；(C) 各表型 28 天死亡率
##   ★ 不再重画 GBTM 拟合曲线：hlme 的拟合值需重跑模型（约 7 分钟），
##     此处用观测值的分箱均值 + loess 平滑展示实际数据，与 GBTM 分组一致
## =============================================================================================
cat("\n[8] Fig 3 轨迹与表型 ...\n")

if (!HAS_PHENO) {
  cat("  — 无表型模式，跳过 Fig 3 / Fig 4\n")
  LONG <- tibble::tibble()
} else {
LONG <- M %>% filter(in_traj_set == 1, !is.na(pheno)) %>%
  select(hadm_id, pheno, pheno_f, lac_0h:lac_72h, cr_0h:cr_72h) %>%
  pivot_longer(-c(hadm_id, pheno, pheno_f), names_to = "key", values_to = "value") %>%
  filter(!is.na(value)) %>%
  mutate(variable = ifelse(grepl("^lac", key), "Lactate", "Creatinine"),
         time_h = suppressWarnings(as.numeric(gsub("h$", "", sub("^(lac|cr)_", "", key))))) %>%
  filter(!is.na(time_h))
wt(LONG %>% count(variable, pheno_f, time_h, name = "n") %>% pivot_wider(names_from = pheno_f,
                values_from = n, names_prefix = "n_"), "trajectory_counts.csv")

# 轨迹均值表（供补充表）
TRAJ_MEAN <- LONG %>% group_by(variable, pheno_f, time_h) %>%
  summarise(n = n(), mean = mean(value, na.rm = TRUE), se = sd(value, na.rm = TRUE)/sqrt(n()),
            median = median(value, na.rm = TRUE), .groups = "drop")
wt(TRAJ_MEAN, "trajectory_means.csv")

pa <- ggplot(LONG %>% filter(variable == "Lactate"), aes(time_h, value, colour = pheno_f, fill = pheno_f)) +
  geom_jitter(width = 1.2, height = 0, alpha = 0.05, size = 0.35, show.legend = FALSE) +
  geom_smooth(method = "loess", span = 1.2, se = TRUE, linewidth = 1.06, alpha = 0.14) +
  scale_colour_manual(values = COL_PHENO, name = NULL) +
  scale_fill_manual(values = COL_PHENO, name = NULL) +
  scale_x_continuous(breaks = c(0, 6, 12, 24, 48, 72)) +
  coord_cartesian(ylim = c(0, quantile(LONG$value[LONG$variable == "Lactate"], .97))) +
  labs(x = "Hours after first S. aureus detection", y = "Lactate, mmol/L", tag = "A",
       title = "Lactate trajectories by phenotype") +
  THEME + theme(legend.position = "none")

pb <- ggplot(LONG %>% filter(variable == "Creatinine"), aes(time_h, value, colour = pheno_f, fill = pheno_f)) +
  geom_jitter(width = 1.2, height = 0, alpha = 0.05, size = 0.35, show.legend = FALSE) +
  geom_smooth(method = "loess", span = 1.2, se = TRUE, linewidth = 1.06, alpha = 0.14) +
  scale_colour_manual(values = COL_PHENO, name = NULL) +
  scale_fill_manual(values = COL_PHENO, name = NULL) +
  scale_x_continuous(breaks = c(0, 6, 12, 24, 48, 72)) +
  coord_cartesian(ylim = c(0, quantile(LONG$value[LONG$variable == "Creatinine"], .97))) +
  labs(x = "Hours after first S. aureus detection", y = "Creatinine, mg/dL", tag = "B",
       title = "Creatinine trajectories by phenotype") +
  THEME + theme(legend.position = "none")

mort_ph <- M %>% filter(!is.na(pheno)) %>% group_by(pheno_f) %>%
  summarise(n = n(), d = sum(death_28d == 1), pct = 100 * d / n, .groups = "drop")
mort_ph <- mort_ph %>% rowwise() %>%
  mutate(lo = 100*wilson(d, n)[1], hi = 100*wilson(d, n)[2]) %>% ungroup()

pc <- ggplot(mort_ph, aes(pheno_f, pct, fill = pheno_f)) +
  geom_col(width = 0.62, colour = NA) +
  geom_errorbar(aes(ymin = lo, ymax = hi), width = 0.14, linewidth = 0.56) +
  # ★ 标签放柱顶上方、误差条顶端之上：y = hi + 6 固定偏移，黑色文字（白字在浅色柱上看不清）
  geom_text(aes(label = sprintf("%.1f%%\n(n=%d)", pct, n), y = hi + 7),
            vjust = 0, size = 2.91, lineheight = 0.9, colour = "grey15") +
  scale_fill_manual(values = COL_PHENO, guide = "none") +
  scale_y_continuous(limits = c(0, 120), breaks = seq(0, 100, 25)) +
  labs(x = NULL, y = "28-day mortality, %", tag = "C",
       title = "Mortality gradient across phenotypes",
       caption = paste("Bars: observed mortality; whiskers: Wilson 95% CI.",
                       "Joint phenotype has three levels (P1 / P2 / P3);",
                       "P3 denotes the highest-severity tertile of the combined",
                       "lactate-creatinine severity score.")) +
  THEME + theme(axis.text.x = element_text(angle = 20, hjust = 1))

p3 <- if (HAS_PATCHWORK) (pa | pb) / pc + plot_layout(heights = c(1, 0.85)) else pa
save_fig(p3, "Fig03_GBTM_trajectories", 10.4, 7.4)
}  # end HAS_PHENO (Fig 3)


wt(mort_ph, "phenotype_mortality.csv")

## =============================================================================================
## [9] Fig 4 — 表型的临床效度
##   (A) 各表型的 peak lactate / SOFA / Charlson 分布；(B) 表型 × 90 天死亡
## =============================================================================================
cat("\n[9] Fig 4 表型临床效度 ...\n")
if (HAS_PHENO) {

SEV <- M %>% filter(!is.na(pheno)) %>%
  select(pheno_f, lactate_max, cr_max, sofa_24h, charlson, death_28d, death_90d) %>%
  pivot_longer(c(lactate_max, cr_max, sofa_24h, charlson), names_to = "var", values_to = "v") %>%
  filter(!is.na(v)) %>%
  mutate(var = factor(var, levels = c("lactate_max", "cr_max", "sofa_24h", "charlson"),
                      labels = c("Peak lactate (mmol/L)", "Peak creatinine (mg/dL)",
                                 "SOFA score (24 h)", "Charlson index")))
wt(SEV %>% group_by(var, pheno_f) %>%
     summarise(n = n(), median = median(v), q1 = quantile(v, .25), q3 = quantile(v, .75),
               .groups = "drop"), "phenotype_severity.csv")

p4a <- ggplot(SEV, aes(pheno_f, v, fill = pheno_f)) +
  geom_boxplot(width = 0.6, outlier.size = 0.25, outlier.alpha = 0.25, linewidth = 0.44) +
  facet_wrap(~var, scales = "free_y", ncol = 4) +
  scale_fill_manual(values = COL_PHENO, guide = "none") +
  labs(x = NULL, y = NULL, tag = "A", title = "Baseline severity and biomarker values by phenotype") +
  THEME + theme(axis.text.x = element_text(angle = 30, hjust = 1, size = 7.5))

OUT_PH <- bind_rows(
  M %>% filter(!is.na(pheno)) %>% mutate(out = "28-day", ev = death_28d),
  M %>% filter(!is.na(pheno)) %>% mutate(out = "90-day", ev = death_90d)
) %>% group_by(out, pheno_f) %>%
  summarise(n = n(), d = sum(ev == 1), pct = 100 * d / n, .groups = "drop")

p4b <- ggplot(OUT_PH, aes(pheno_f, pct, fill = out)) +
  geom_col(position = position_dodge(width = 0.72), width = 0.66) +
  geom_text(aes(label = sprintf("%.1f", pct)), position = position_dodge(width = 0.72),
            vjust = -0.5, size = 2.80) +
  scale_fill_manual(values = c("28-day" = "#E64B35", "90-day" = "#7E2F8E"), name = NULL) +
  scale_y_continuous(limits = c(0, 108), breaks = seq(0, 100, 25)) +
  labs(x = NULL, y = "Mortality, %", tag = "B", title = "Short- and intermediate-term mortality") +
  THEME + theme(axis.text.x = element_text(angle = 20, hjust = 1))

p4 <- if (HAS_PATCHWORK) p4a / p4b + plot_layout(heights = c(1, 0.8)) else p4a
save_fig(p4, "Fig04_phenotype_severity", 9.6, 6.2)
}


## =============================================================================================
## [10] Fig 5 — Kaplan–Meier 28 天累积死亡率
##   (A) 按耐药状态；(B) 按表型；带 number at risk 表与 log-rank P
##   ★ 自己算 risk table（不依赖 survminer，减少安装负担）
## =============================================================================================
cat("\n[10] Fig 5 KM 生存曲线 ...\n")

km_plot <- function(dat, grp, title, tag, cols, tmax = 28, brk = seq(0, 28, 7), glabs = NULL) {
  ## ★ 防御：分组变量必须 ≥2 个水平且每组有事件，否则 survdiff 会报 "only 1 group"
  gv <- dat[[grp]]
  .lev <- levels(droplevels(as.factor(gv)))
  if (length(.lev) < 2) {
    stop(sprintf(paste0(
      "\n■■■ KM 绘图中止：分组变量 '%s' 只有 %d 个有效水平 ■■■\n",
      "  现有水平：%s\n",
      "  常见原因：① 表型文件只含单一表型；② 数据过滤后某一组全被剔除。\n",
      "  请先检查上方「表型文件读入」的分布行。\n"),
      grp, length(.lev), paste(.lev, collapse = ", ")), call. = FALSE)
  }
  dat <- dat %>% filter(!is.na(.data[[grp]])) %>%
    mutate(!!grp := droplevels(factor(.data[[grp]])))
  if (any(table(dat[[grp]]) == 0)) {
    stop(sprintf("KM 绘图中止：'%s' 存在空组（%s）",
                 grp, paste(names(table(dat[[grp]])), table(dat[[grp]]), sep = "=", collapse = ", ")),
         call. = FALSE)
  }

  f <- as.formula(paste("Surv(fu28, death_28d) ~", grp))
  fit <- survfit(f, data = dat)
  s <- summary(fit, times = brk, extend = TRUE)
  grpv <- if (is.null(s$strata)) factor(rep(levels(dat[[grp]])[1], length(s$time))) else
    factor(sub(paste0("^", grp, "="), "", as.character(s$strata)), levels = levels(dat[[grp]]))
  kt <- data.frame(time = s$time, surv = s$surv, lower = s$lower, upper = s$upper,
                   grp = grpv, nrisk = s$n.risk)
  kt$grp <- factor(as.character(kt$grp), levels = levels(dat[[grp]]))  # ★ 固定 level 顺序
  lr <- survdiff(f, data = dat)
  pval <- pchisq(lr$chisq, df = length(lr$n) - 1, lower.tail = FALSE)
  glab <- levels(dat[[grp]])   # ★ 图例只写组名；样本量在 risk table 里可见，不再塞进图例
  ## ★ v8：可选短图例标签（命名向量：完整水平 → 短标签），防长文字被画布右缘裁切
  ##   注意：kt$grp 的取值必须与图例键【同步】重命名，否则配色映射失效（全灰/NA）
  if (!is.null(glabs)) {
    miss <- setdiff(glab, names(glabs))
    if (length(miss)) stop(sprintf("km_plot: glabs 缺少水平 %s", paste(miss, collapse = ", ")), call. = FALSE)
    map <- setNames(unname(glabs[glab]), glab)     # 命名向量：完整标签 → 短标签
    glab <- unname(map)
    kt$grp <- factor(map[as.character(kt$grp)], levels = glab)
  }
  # ★ ribbon 要沿 KM 的阶梯路径走：先把上下界转换成「先横后竖」的阶跃数据
  #   （geom_ribbon 默认按直线连接，会在时间间隔中画成斜线）
  # make_step 已被下方「合并时点展开」方案取代，保留定义以便回退
  make_step <- function(t, y) {
    n <- length(t)
    if (n <= 1) return(data.frame(t = t, y = y))
    tt <- c(); yy <- c()
    for (i in 1:(n - 1)) {
      tt <- c(tt, t[i],   t[i + 1]); yy <- c(yy, y[i], y[i])
      if (y[i + 1] != y[i]) { tt <- c(tt, t[i + 1]); yy <- c(yy, y[i + 1]) }
    }
    tt <- c(tt, t[n]); yy <- c(yy, y[n])
    data.frame(t = tt, y = yy)
  }
  rib <- do.call(rbind, lapply(levels(kt$grp), function(gg) {
    k2 <- kt[kt$grp == gg, ]
    # ★ upper 与 lower 的跳变时点不同（CI 宽度不同步），必须先对两者做【合并时点】展开
    tt_all <- sort(unique(c(k2$time, 0, k2$time)))     # 统一时间轴
    step_at <- function(tv, yv) {
      # 取每个时点在 tv 之前最近的 yv（右连续，符合 KM 语义）
      sapply(tt_all, function(tq) {
        idx <- which(tv <= tq)
        if (!length(idx)) return(1 - yv[1])   # t=0 时 CI 宽度为 0 → 用 surv=1
        1 - yv[idx[length(idx)]]
      })
    }
    ymax_v <- step_at(k2$time, k2$upper)
    ymin_v <- step_at(k2$time, k2$lower)
    data.frame(grp = gg, t = tt_all, ymin = ymin_v, ymax = ymax_v)
  }))
  rib$grp <- factor(rib$grp, levels = levels(kt$grp))   # ★ 与曲线的 factor level 完全一致
  g <- ggplot() +
    geom_ribbon(data = rib, aes(t, ymin = ymin, ymax = ymax, fill = grp),
                alpha = 0.12, colour = NA) +
    geom_step(data = kt, aes(time, 1 - surv, colour = grp), linewidth = 1.00) +
    scale_colour_manual(values = setNames(unname(cols), glab), name = NULL) +
    scale_fill_manual(values = setNames(unname(cols), glab), name = NULL) +
    scale_x_continuous(breaks = brk, limits = c(0, tmax), expand = c(0.01, 0)) +
    scale_y_continuous(labels = function(x) sprintf("%.0f", 100 * x),
                       limits = c(0, 1.02), expand = c(0, 0)) +
    labs(x = "Days since first S. aureus detection", y = "Cumulative mortality, %", tag = tag,
         title = title,
         subtitle = sprintf("Log-rank P %s", ifelse(pval < 0.001, "< 0.001", sprintf("= %.3f", pval)))) +
    THEME + theme(legend.position = "top")
  list(plot = g, risk = kt %>% select(time, grp, nrisk))
}
k1 <- km_plot(M %>% filter(!is.na(mrsa_f)), "mrsa_f",
              "By methicillin resistance status", "A", COL_STATUS)
k2 <- if (HAS_PHENO) km_plot(M %>% filter(!is.na(pheno_f)), "pheno_f",
              "By trajectory phenotype", "B", COL_PHENO,
              ## ★ v8：面板图例用短标签（P1/P2/P3），完整标签见 risk table 与正文图注
              glabs = c("Phenotype 1 (low)"          = "P1 (low)",
                        "Phenotype 2 (intermediate)" = "P2 (intermediate)",
                        "Phenotype 3 (high)"         = "P3 (high)")) else NULL

risk_tbl <- function(rk, tag) {
  ggplot(rk, aes(time, grp, label = formatC(nrisk, format = "d", big.mark = ","))) +
    geom_text(size = 2.80, colour = "grey25") +
    scale_x_continuous(breaks = seq(0, 28, 7), limits = c(-2, 30), expand = c(0, 0)) +
    labs(x = NULL, y = NULL, tag = tag) +
    THEME + theme(axis.line = element_blank(), axis.text.x = element_blank(),
                  axis.ticks = element_blank(), plot.tag = element_text(size = 8),
                  panel.grid.major.y = element_blank())
}
if (HAS_PATCHWORK && !is.null(k2)) {
  p5 <- (k1$plot / risk_tbl(k1$risk, "") + plot_layout(heights = c(1, 0.28))) |
        (k2$plot / risk_tbl(k2$risk, "") + plot_layout(heights = c(1, 0.28)))
} else if (HAS_PATCHWORK) {
  p5 <- k1$plot / risk_tbl(k1$risk, "") + plot_layout(heights = c(1, 0.28))
} else p5 <- k1$plot
## ★ v8：10.2 → 11.4 英寸。三档表型图例文字较长（"Phenotype 1 (low)" 等），
##        10.2 英寸下 B 面板图例第三项会被裁切出画布
save_fig(p5, "Fig05_KM_survival", 11.4, 6.0)
wr(bind_rows(k1$risk %>% mutate(panel = "A_resistance"),
           if (!is.null(k2)) k2$risk %>% mutate(panel = "B_phenotype")),
   "km_risk_table.csv")

# KM 各时点数值（供正文引用）
KM_NUM <- bind_rows(
  summary(survfit(Surv(fu28, death_28d) ~ mrsa_f, data = M), times = c(7, 14, 28), extend = TRUE) |>
    {\(s) data.frame(strata = as.character(s$strata), time = s$time,
                      cum_mort = 1 - s$surv, lower = 1 - s$upper, upper = 1 - s$lower)}() %>%
    mutate(panel = "resistance"),
  if (HAS_PHENO)
    summary(survfit(Surv(fu28, death_28d) ~ pheno_f, data = M %>% filter(!is.na(pheno_f))),
            times = c(7, 14, 28), extend = TRUE) |>
      {\(s) data.frame(strata = as.character(s$strata), time = s$time,
                        cum_mort = 1 - s$surv, lower = 1 - s$upper, upper = 1 - s$lower)}() %>%
      mutate(panel = "phenotype")
)
wt(KM_NUM %>% mutate(across(c(cum_mort, lower, upper), ~ round(100 * ., 1))), "KM_cumulative_mortality.csv")

## =============================================================================================
## [11] Fig 6 — 单因素 Cox 森林图
## =============================================================================================
cat("\n[11] Fig 6 单因素森林图 ...\n")

F6 <- T2d %>% mutate(
  label = paste0(Variable, "  ")
) %>% filter(!is.na(HR))
# 域内按 HR 排序（域按首次出现顺序）
dom_levels <- unique(uni_vars[uni_vars %in% F6$variable])
dom_map <- setNames(names(uni_vars), unname(uni_vars))
F6$DomainFull <- dom_map[F6$variable]
F6$grp <- factor(F6$DomainFull, levels = names(uni_vars))
F6 <- F6 %>% group_by(grp) %>% arrange(HR, .by_group = TRUE) %>% ungroup()
sig <- function(p) ifelse(p < 0.001, "***", ifelse(p < 0.01, "**", ifelse(p < 0.05, "*", "")))
F6$star <- sig(F6$p)

## ★ v8 修复行错位：旧实现用「全局连续 y + breaks/labels + facet」，各 panel 的
##   y 范围经 expansion 扩展后互相重叠，相邻域的行标签会渲染进隔壁域（每个域
##   顶部多出一行邻居的标签）。改为【离散 y 因子】：每行一个唯一 level，
##   显示名允许重复（"Yes vs no"），经具名向量映射，facet 不再串行。
##   ykey = term（全局唯一）；显示顺序：域自上而下 = uni_vars 顺序，域内 HR 升序。
stopifnot(!anyDuplicated(F6$term))
F6$ykey <- F6$term
row_top_down <- F6$ykey                       # arrange 后：自上而下
F6$yf <- factor(F6$ykey, levels = rev(row_top_down))   # ggplot: level 1 在底部

p6 <- ggplot(F6, aes(HR, yf, colour = p < 0.05)) +
  geom_vline(xintercept = 1, linetype = "22", colour = "grey45", linewidth = 0.50) +
  geom_errbar_h(aes(xmin = lo, xmax = hi), height = 0.18, linewidth = 0.56) +
  geom_point(size = 1.90, shape = 15) +
  geom_text(aes(label = sprintf("%.2f%s", HR, star)), vjust = -1.05, size = 2.80,
            show.legend = FALSE) +
  scale_colour_manual(values = c(`TRUE` = "#E64B35", `FALSE` = "grey35"), guide = "none") +
  scale_x_log10(breaks = c(0.5, 1, 2, 4, 8, 16, 32), limits = c(0.4, 45)) +
  scale_y_discrete(breaks = levels(F6$yf),
                   labels = setNames(F6$label, F6$ykey),
                   expand = expansion(add = c(0.6, 1.4))) +
  facet_grid(grp ~ ., scales = "free_y", space = "free_y", switch = "y") +
  labs(x = "Hazard ratio (95% CI, log scale)", y = NULL,
       title = "Figure 6  Univariable Cox regression for 28-day all-cause mortality",
       subtitle = sprintf("n = %s admissions | %d deaths | * P<0.05, ** P<0.01, *** P<0.001",
                          fmt_i(nrow(D_MAIN)), sum(D_MAIN$death_28d == 1)),
       caption = "Exact CIs are listed in Table 2.") +
  THEME +
  theme(panel.grid.major.y = element_blank(), strip.placement = "outside",
        strip.text.y.left = element_text(angle = 0, face = "bold", size = 7.6, hjust = 0),
        strip.background = element_rect(fill = "grey95", colour = NA),
        panel.spacing.y = unit(0.25, "lines"))
save_fig(p6, "Fig06_forest_cox", 10.4, max(5.0, 0.36 * nrow(F6) + 2.4))

## =============================================================================================
## [12] Fig 7 — 多因素 Cox 三模型并排森林图
## =============================================================================================
cat("\n[12] Fig 7 多因素森林图 ...\n")
if (HAS_PHENO) {

F7 <- T3_long %>%
  filter(model_short %in% c("main", "rrt")) %>%
  mutate(label = TERM_LAB[term],
         label = ifelse(is.na(label), term, label))
F7$model_lab <- factor(F7$model,
                       levels = c("Primary (3-phenotype)", "Primary + RRT"),
                       labels = c("Primary", "Primary + RRT"))
# 各模型的展示顺序（与 Table 3 一致）
LAB_ORDER <- c("Phenotype 2 (intermediate)", "Phenotype 3 (high)", "MRSA", "Not determined",
               "45–64", "65–79", "≥80", "3–4", "≥5", "Yes vs no",
               "2–5", "6–9", "≥10", "RRT vs no RRT")
F7 <- F7 %>% filter(label %in% LAB_ORDER) %>%
  mutate(label = factor(label, levels = rev(LAB_ORDER)))
F7$star <- sig(F7$p)
F7$model_lab2 <- factor(as.character(F7$model_lab),
                        levels = rev(c("Primary", "Primary + RRT")))

COL_MODEL <- c("Primary" = "#E64B35", "Primary + RRT" = "#00A087")

p7 <- ggplot(F7, aes(HR, label, colour = model_lab, group = model_lab)) +
  geom_vline(xintercept = 1, linetype = "22", colour = "grey45", linewidth = 0.50) +
  geom_errbar_h(aes(xmin = lo, xmax = hi), height = 0.22, linewidth = 0.53,
                 position = position_dodge(width = 0.62)) +
  geom_point(size = 1.68, shape = 15, position = position_dodge(width = 0.62)) +
  scale_colour_manual(values = COL_MODEL, name = NULL) +
  scale_x_log10(breaks = c(0.5, 1, 2, 4, 8, 16, 32), limits = c(0.45, 40)) +
  labs(x = "Hazard ratio (95% CI, log scale)", y = NULL,
       title = "Figure 7  Multivariable Cox regression for 28-day all-cause mortality",
       subtitle = sprintf("n = %s; %d events; concordance %.3f | exact CIs in Table 3",
                          fmt_i(m_main$n), m_main$nevent, conc(m_main)),
       caption = paste("Mechanical ventilation and vasopressor use were omitted as putative mediators.",
                       "RRT entered only in the second model.")) +
  THEME + theme(legend.position = "top", panel.grid.major.y = element_blank())
save_fig(p7, "Fig07_forest_multivariable", 9.6, 6.4)
}


## =============================================================================================
## [13] Fig S1–S4 — 按耐药状态的描述性对比
## =============================================================================================
cat("\n[13] Fig S1–S4 描述性对比 ...\n")

# S1 基线指标箱线图
S1V <- M %>% select(mrsa_f, age, charlson, sofa_24h, sapsii, apsiii, oasis, lactate_max,
                    cr_max, wbc_max, hgb_min, plt_min, albumin_min) %>%
  pivot_longer(-mrsa_f, names_to = "var", values_to = "v") %>% filter(!is.na(v)) %>%
  mutate(var = factor(var, levels = c("age", "charlson", "sofa_24h", "sapsii", "apsiii", "oasis",
                                      "lactate_max", "cr_max", "wbc_max", "hgb_min", "plt_min",
                                      "albumin_min"),
                      labels = c("Age (years)", "Charlson index", "SOFA (24 h)", "SAPS II",
                                 "APACHE III", "OASIS", "Peak lactate", "Peak creatinine",
                                 "Peak WBC", "Min haemoglobin", "Min platelet", "Min albumin")))
ps1 <- ggplot(S1V, aes(mrsa_f, v, fill = mrsa_f)) +
  geom_boxplot(width = 0.62, outlier.size = 0.2, outlier.alpha = 0.2, linewidth = 0.38) +
  facet_wrap(~var, scales = "free_y", ncol = 4) +
  scale_fill_manual(values = COL_STATUS, guide = "none") +
  labs(x = NULL, y = NULL, title = "Figure S1  Baseline characteristics and severity by resistance status",
       subtitle = "Boxes: median and IQR; whiskers: 1.5 × IQR; outliers plotted individually") +
  THEME + theme(axis.text.x = element_text(angle = 25, hjust = 1, size = 7.4))
save_fig(ps1, "FigS01_baseline_box", 9.6, 6.4)

# S2 合并症
COM <- c(chf = "Congestive heart failure", hypertension = "Hypertension", diabetes = "Diabetes",
         ckd = "Chronic kidney disease", copd = "COPD",
         myocardial_infarction = "Myocardial infarction", malignancy = "Malignancy",
         liver_disease = "Liver disease", immunosuppression = "Immunosuppression",
         hiv = "HIV", aki_baseline = "AKI at baseline", malnutrition = "Malnutrition")
S2D <- M %>% select(mrsa_f, all_of(names(COM))) %>%
  pivot_longer(-mrsa_f, names_to = "var", values_to = "v") %>%
  group_by(mrsa_f, var) %>% summarise(n = n(), k = sum(v == 1, na.rm = TRUE), .groups = "drop") %>%
  mutate(pct = 100 * k / n, var = factor(COM[var], levels = rev(unname(COM))))
ps2 <- ggplot(S2D, aes(pct, var, fill = mrsa_f)) +
  geom_col(position = position_dodge(width = 0.74), width = 0.68) +
  scale_fill_manual(values = COL_STATUS, name = NULL) +
  scale_x_continuous(limits = c(0, max(S2D$pct) * 1.15), expand = c(0, 0)) +
  labs(x = "Prevalence, %", y = NULL,
       title = "Figure S2  Comorbidity prevalence by resistance status") +
  THEME + theme(legend.position = "top", panel.grid.major.y = element_blank())
save_fig(ps2, "FigS02_comorbidity", 7.2, 5.4)
wt(S2D %>% select(mrsa_f, var, n, k, pct) %>% mutate(pct = round(pct, 1)), "comorbidity_by_status.csv")

# S3 标本类型
S3D <- M %>% filter(!is.na(main_specimen_type)) %>%
  count(mrsa_f, main_specimen_type) %>% group_by(mrsa_f) %>%
  mutate(pct = 100 * n / sum(n)) %>% ungroup()
S3D <- S3D %>% group_by(mrsa_f) %>% mutate(tot_stratum = sum(n)) %>% ungroup() %>%
  mutate(lab = ifelse(pct < 3, sprintf("%d/%d", n, tot_stratum), sprintf("%.1f%%", pct)))
## ★ 分面布局：每个 resistance stratum 独占一行，小比例柱的 n/N 标签不再在 x=0 处重叠
lvl_s3 <- (S3D %>% group_by(main_specimen_type) %>% summarise(p = max(pct)) %>% arrange(p))$main_specimen_type
S3D$main_specimen_type <- factor(S3D$main_specimen_type, levels = lvl_s3)
ps3 <- ggplot(S3D, aes(pct, main_specimen_type, fill = mrsa_f)) +
  geom_col(width = 0.68) +
  geom_text(aes(label = lab), hjust = -0.05, size = 2.02, colour = "grey35") +
  facet_grid(mrsa_f ~ ., scales = "free_x") +
  scale_fill_manual(values = COL_STATUS, name = NULL) +
  scale_x_continuous(expand = expansion(mult = c(0, 0.22))) +
  labs(x = "Proportion within resistance stratum, %", y = NULL,
       title = "Figure S3  Primary specimen type by resistance status",
       subtitle = "n/N shown for categories with prevalence < 3%; full counts in specimen_by_status.csv") +
  THEME + theme(legend.position = "none", panel.grid.major.y = element_blank(),
                axis.text.y = element_text(size = 6.2),
                strip.text.y = element_text(angle = 0, size = 7.5, face = "bold"))
save_fig(ps3, "FigS03_specimen", 7.6, 9.0)
wt(S3D, "specimen_by_status.csv")

# S4 结局与器官支持
OUTS <- c(death_inhospital = "In-hospital mortality", death_28d = "28-day mortality",
          death_90d = "90-day mortality", has_icu = "ICU admission",
          mech_vent = "Mechanical ventilation", any_vasopressor = "Vasopressor use",
          rrt = "RRT (documented)")
S4D <- M %>% select(mrsa_f, all_of(names(OUTS))) %>%
  pivot_longer(-mrsa_f, names_to = "var", values_to = "v") %>%
  group_by(mrsa_f, var) %>% summarise(n = n(), k = sum(v == 1, na.rm = TRUE), .groups = "drop") %>%
  mutate(pct = 100 * k / n, var = factor(OUTS[var], levels = rev(unname(OUTS))))
# Wilson CI 误差条
S4D <- S4D %>% rowwise() %>% mutate(lo = 100*wilson(k, n)[1], hi = 100*wilson(k, n)[2]) %>% ungroup()
ps4 <- ggplot(S4D, aes(pct, var, fill = mrsa_f)) +
  geom_col(position = position_dodge(width = 0.74), width = 0.68) +
  geom_errorbar(aes(xmin = lo, xmax = hi), position = position_dodge(width = 0.74),
                width = 0.16, linewidth = 0.44) +
  ## ★ n/N 标签与柱顶【垂直平齐】：vjust = 0.5 使文字中线对准柱条中心高度，
  ##   而非飘到柱上方；x 位置取 CI 上限外一点，避免与误差条重叠。
  geom_text(aes(label = sprintf("%d/%d", k, n), x = hi),
            position = position_dodge(width = 0.74),
            hjust = -0.08, vjust = 0.5, size = 2.24, colour = "grey35") +
  scale_fill_manual(values = COL_STATUS, name = NULL) +
  scale_x_continuous(expand = c(0, 0), limits = c(0, max(S4D$hi) * 1.22)) +
  labs(x = "Proportion, % (Wilson 95% CI; n/N at bar end)", y = NULL,
       title = "Figure S4  Clinical outcomes and organ support by resistance status") +
  THEME + theme(legend.position = "top", panel.grid.major.y = element_blank(),
                axis.text.y = element_text(size = 7.0))
save_fig(ps4, "FigS04_outcomes", 7.8, 4.2)
wt(S4D, "outcomes_by_status.csv")

## =============================================================================================
## [14] Fig S5 — 原始轨迹（0–72 h）按耐药状态
##   用观测分箱均值 ± 95% CI（不引 mgcv，避免额外依赖；与 GAM 平滑的视觉结论一致）
## =============================================================================================
cat("\n[14] Fig S5 原始轨迹 ...\n")
# ★ Fig S5 只需要「原始轨迹 + 耐药状态」，与表型无关。
#   无表型模式下 LONG 是空表，故此处从 M 直接重建长表，不依赖 LONG。
LONG_S5 <- M %>% filter(in_traj_set == 1) %>%
  select(hadm_id, mrsa_f, lac_0h:lac_72h, cr_0h:cr_72h) %>%
  pivot_longer(-c(hadm_id, mrsa_f), names_to = "key", values_to = "value") %>%
  filter(!is.na(value)) %>%
  mutate(variable = ifelse(grepl("^lac", key), "Lactate", "Creatinine"),
         time_h = suppressWarnings(as.numeric(gsub("h$", "", sub("^(lac|cr)_", "", key))))) %>%
  filter(!is.na(time_h))

S5D <- LONG_S5 %>%
  filter(!is.na(mrsa_f)) %>%
  group_by(variable, mrsa_f, time_h) %>%
  summarise(n = n(), m = mean(value), se = sd(value, na.rm = TRUE)/sqrt(n()), .groups = "drop") %>%
  mutate(lo = m - 1.96*se, hi = m + 1.96*se)
ps5 <- ggplot(S5D, aes(time_h, m, colour = mrsa_f, fill = mrsa_f)) +
  geom_ribbon(aes(ymin = lo, ymax = hi), alpha = 0.13, colour = NA) +
  geom_line(linewidth = 1.06) + geom_point(size = 1.46) +
  facet_wrap(~variable, scales = "free_y", ncol = 2) +
  scale_colour_manual(values = COL_STATUS, name = NULL) +
  scale_fill_manual(values = COL_STATUS, name = NULL) +
  scale_x_continuous(breaks = c(0, 6, 12, 24, 48, 72)) +
  labs(x = "Hours after first S. aureus detection", y = "Mean observed value",
       title = "Figure S5  Raw organ dysfunction trajectories by resistance status",
       subtitle = "Binned mean ± 95% CI at the six sampling windows") +
  THEME + theme(legend.position = "top")
save_fig(ps5, "FigS05_raw_trajectory", 8.8, 4.4)
wt(S5D, "raw_trajectory_by_status.csv")

## =============================================================================================
## [15] Fig S6 — Aalen–Johansen 竞争风险累积发生率（死亡 vs 出院存活）
##   cr_status: 0 = 删失, 1 = 死亡, 2 = 出院存活；cr_time_days 为对应时间
##   ★ 若 cr_time_days 与 28 天口径不一致，此处只作定性展示，正文不引用数值
## =============================================================================================
cat("\n[15] Fig S6 竞争风险 ...\n")

CR <- M %>% filter(!is.na(cr_status), !is.na(cr_time_days),
                   cr_status %in% c(0, 1, 2), cr_time_days >= 0, cr_time_days <= 90)
cat(sprintf("  竞争风险可用记录：%d（status: 0=%d, 1=%d, 2=%d）\n", nrow(CR),
            sum(CR$cr_status == 0), sum(CR$cr_status == 1), sum(CR$cr_status == 2)))

cif_curve <- function(dat, grp) {
  # ★ cuminc 的返回名在不同分组下会变成 "1 1" / "1 2" 这种「组号 事件号」格式，
  #   因此按【值】而非名字识别事件：event=1 为死亡，event=2 为出院存活（竞争事件）
  out <- list()
  for (g in levels(droplevels(factor(dat[[grp]])))) {
    dd <- dat[!is.na(dat[[grp]]) & dat[[grp]] == g, ]
    if (nrow(dd) < 20) next
    fit <- tryCatch(cmprsk::cuminc(dd$cr_time_days, dd$cr_status, cencode = 0), error = function(e) NULL)
    if (is.null(fit)) next
    for (ev in names(fit)) {
      cc <- fit[[ev]]
      if (!is.list(cc) || is.null(cc$time)) next
      code <- suppressWarnings(as.integer(sub("^.*\\s", "", ev)))
      if (is.na(code)) next
      out[[paste(g, code)]] <- data.frame(grp = g, event = code, time = cc$time,
                                          cif = cc$est, var = cc$var)
    }
  }
  do.call(rbind, out)
}
CIF1 <- cif_curve(CR, "mrsa_f") %>% mutate(panel = "A  Resistance status")
CIF2 <- if (HAS_PHENO) cif_curve(CR %>% filter(!is.na(pheno_f)), "pheno_f") %>%
  mutate(panel = "B  Trajectory phenotype") else NULL
CIF_ALL <- bind_rows(CIF1, CIF2) %>% mutate(cif_pct = 100 * cif, se_pct = 100 * sqrt(pmax(var, 0)))
if (!nrow(CIF_ALL)) stop("竞争风险曲线计算失败：cuminc 未返回任何事件曲线", call. = FALSE)
wt(CIF_ALL %>% filter(event == 1) %>% select(panel, grp, time, cif_pct, se_pct) %>%
     mutate(across(c(cif_pct, se_pct), ~ round(., 2))), "cif_death.csv")

CIF_P <- CIF_ALL %>% filter(event == 1) %>% mutate(
  panel = factor(panel, levels = c("A  Resistance status", "B  Trajectory phenotype")))
# 无表型模式：只剩 A 面板，facet 的 B level 无数据 → drop
if (!HAS_PHENO) CIF_P <- CIF_P %>% filter(panel == "A  Resistance status") %>%
  mutate(panel = droplevels(panel))
# 图例只保留实际出现的组，避免空条目
COL_S6 <- c(COL_STATUS, COL_PHENO)[unique(CIF_P$grp)]
ps6 <- ggplot(CIF_P, aes(time, cif_pct, colour = grp)) +
  geom_step(linewidth = 1.00) +
  facet_wrap(~panel, scales = "free_y") +
  scale_colour_manual(values = COL_S6, name = NULL, breaks = names(COL_S6)) +
  scale_x_continuous(breaks = c(0, 7, 14, 28, 60, 90)) +
  labs(x = "Days since first S. aureus detection", y = "Cumulative incidence of death, %",
       title = "Figure S6  Aalen–Johansen cumulative incidence of death",
       subtitle = "Discharge alive treated as a competing event",
       caption = paste("Estimates are descriptive; the competing-risk data cover up to 90 days",
                       "and are not used for hypothesis testing.")) +
  THEME + theme(legend.position = "bottom")
save_fig(ps6, "FigS06_competing_risk", 9.6, 4.6)

## =============================================================================================
## [16] Fig S7 — 耐药谱热图（依赖长表时自动跳过）
## =============================================================================================
cat("\n[16] Fig S7 耐药谱 ...\n")
SUSC_FILE <- c("merged_out/SA_MERGED_SUSCEPT.csv", "SA_MERGED_SUSCEPT.csv")
AGENTS <- c("res_oxacillin", "res_erythromycin", "res_levofloxacin", "res_clindamycin",
            "res_vancomycin", "res_linezolid", "res_daptomycin")
AGT_LAB <- c("Oxacillin", "Erythromycin", "Levofloxacin", "Clindamycin",
             "Vancomycin", "Linezolid", "Daptomycin")
## ★ 数据源：主表自带的 res_*/tested_* 汇总列（按 hadm_id 聚合）即可画图，
##   不再强制要求额外的 SA_MERGED_SUSCEPT.csv；该文件存在时仅作日志提示。
if (!all(paste0("tested_", sub("^res_", "", AGENTS)) %in% names(M))) {
  cat("  ⚠ 主表缺少 res_*/tested_* 列，跳过 Fig S7\n")
} else {
  if (any(file.exists(SUSC_FILE))) cat("  （检测到 SA_MERGED_SUSCEPT.csv；S7 使用主表汇总列绘制）\n")
  # 用主表内置的汇总列（已按 hadm_id 聚合），避免读 23 万行长表
  S7D <- lapply(seq_along(AGENTS), function(i) {
    a <- AGENTS[i]; tst <- sub("^res_", "tested_", a)
    if (!all(c(a, tst) %in% names(M))) return(NULL)
    M %>% mutate(res = num(.data[[a]]), tst = num(.data[[tst]])) %>%
      filter(tst == 1) %>% group_by(mrsa_f) %>%
      summarise(agent = AGT_LAB[i], tested = n(), resistant = sum(res == 1, na.rm = TRUE),
                .groups = "drop") %>%
      mutate(pct = 100 * resistant / tested)
  }) %>% bind_rows()
  if (nrow(S7D)) {
    S7D$agent <- factor(S7D$agent, levels = rev(AGT_LAB))
    ps7a <- ggplot(S7D, aes(mrsa_f, agent, fill = pct)) +
      geom_tile(colour = "white", linewidth = 1.38) +
      geom_text(aes(label = sprintf("%.0f\n(%d)", pct, tested)), size = 2.91, lineheight = 0.85) +
      scale_fill_gradient(low = "#F7F7F7", high = "#B2182B", name = "Resistant, %", limits = c(0, 100)) +
      labs(x = NULL, y = NULL, tag = "A",
           title = "Resistance rate among isolates actually tested") +
      THEME + theme(panel.grid = element_blank(), axis.line = element_blank(),
                    axis.ticks = element_blank())
    ps7b <- ggplot(S7D, aes(pct, agent, colour = mrsa_f, shape = mrsa_f)) +
      geom_point(size = 2.35) +
      scale_colour_manual(values = COL_STATUS, name = NULL) +
      scale_shape_manual(values = c(16, 17, 15), name = NULL) +
      scale_x_continuous(limits = c(0, 105)) +
      labs(x = "Resistant, %", y = NULL, tag = "B",
           title = "MRSA versus MSSA (tested isolates only)") +
      THEME + theme(legend.position = "top", panel.grid.major.y = element_blank())
    ps7 <- if (HAS_PATCHWORK) ps7a | ps7b else ps7a
    save_fig(ps7, "FigS07_resistance_profile", 9.4, 4.2)
    wt(S7D, "resistance_by_status.csv")
  } else cat("  ⚠ 主表 res_*/tested_* 列全为空，跳过 Fig S7\n")
}

## =============================================================================================
## [17] Fig S8 — 经验性治疗适当性与给药时机
## =============================================================================================
cat("\n[17] Fig S8 经验性治疗 ...\n")

# 适当性：仅在有药敏结果的层可判定；"Not determined" 层按定义不可判定 → 从图中剔除并注明
ABX <- M %>% filter(mrsa_f != "Not determined") %>%
  mutate(appropriate = case_when(
    mrsa_f == "MRSA" & used_mrsa_covering == 1 ~ 1,
    mrsa_f == "MSSA" & (used_antistaph_penicillin == 1 | used_cefazolin == 1 | used_mrsa_covering == 1) ~ 1,
    TRUE ~ 0)) %>%
  group_by(mrsa_f) %>% summarise(n = n(), k = sum(appropriate == 1), .groups = "drop") %>%
  mutate(pct = 100 * k / n)
ABX <- ABX %>% rowwise() %>% mutate(lo = 100*wilson(k, n)[1], hi = 100*wilson(k, n)[2]) %>% ungroup()

ps8a <- ggplot(ABX, aes(mrsa_f, pct, fill = mrsa_f)) +
  geom_col(width = 0.55) +
  geom_errorbar(aes(ymin = lo, ymax = hi), width = 0.13, linewidth = 0.50) +
  geom_text(aes(label = sprintf("%.1f%%\n(%d/%d)", pct, k, n), y = hi + 7), size = 3.02,
            vjust = 0, lineheight = 0.9) +
  scale_fill_manual(values = COL_STATUS, guide = "none") +
  scale_y_continuous(limits = c(0, 124), breaks = seq(0, 100, 25)) +
  labs(x = NULL, y = "Appropriate empirical therapy, %", tag = "A",
       title = "Appropriateness by resistance stratum",
       caption = "Admissions without susceptibility testing are excluded: appropriateness is not classifiable there.") +
  THEME

TIM <- M %>% filter(!is.na(hours_to_first_abx))
ps8b <- ggplot(TIM, aes(hours_to_first_abx, fill = mrsa_f, colour = mrsa_f)) +
  geom_vline(xintercept = 0, linetype = "22", linewidth = 0.50, colour = "grey40") +
  geom_density(alpha = 0.18, linewidth = 0.75, adjust = 1.1) +
  scale_fill_manual(values = COL_STATUS, name = NULL) +
  scale_colour_manual(values = COL_STATUS, name = NULL) +
  coord_cartesian(xlim = c(-72, 72)) +
  labs(x = "Hours from first anti-staphylococcal agent to detection\n(negative = administered before detection)",
       y = "Density", tag = "B", title = "Timing of the first anti-staphylococcal agent") +
  THEME + theme(legend.position = "top")
ps8 <- if (HAS_PATCHWORK) ps8a | ps8b else ps8a
save_fig(ps8, "FigS08_empiric_coverage", 9.8, 4.4)
wt(ABX, "empiric_coverage.csv")

## =============================================================================================
## [18] Fig S9 — 关键变量缺失模式
## =============================================================================================
cat("\n[18] Fig S9 缺失模式 ...\n")
MISS_VARS <- c(age = "Age", gender = "Female sex", charlson = "Charlson index",
               sofa_24h = "SOFA (24 h)", sapsii = "SAPS II", oasis = "OASIS",
               apsiii = "APACHE III", gcs_min = "Minimum GCS", sirs_max = "Max SIRS",
               lactate_max = "Peak lactate", cr_max = "Peak creatinine", wbc_max = "Peak WBC",
               hgb_min = "Min haemoglobin", plt_min = "Min platelet", albumin_min = "Min albumin",
               ptt_max = "Max aPTT", inr_max = "Max prothrombin time",
               crp_max = "Peak CRP", troponin_max = "Peak troponin",
               hours_to_first_abx = "Time to first agent", hosp_los_days = "Hospital LOS",
               followup_days_28d = "28-day follow-up", rrt = "RRT")
MISS <- data.frame(var = names(MISS_VARS), label = unname(MISS_VARS),
                   pct = sapply(MISS_VARS, function(v) 100 * mean(is.na(M[[names(MISS_VARS)[MISS_VARS == v][1]]]))),
                   row.names = NULL)
names(MISS)[1] <- "var"
MISS$pct <- sapply(names(MISS_VARS), function(v) if (v %in% names(M)) 100 * mean(is.na(M[[v]])) else NA)
MISS$in_icu <- sapply(names(MISS_VARS), function(v) {
  if (!v %in% names(M)) return(NA_real_)
  100 * mean(is.na(M[[v]][M$has_icu == 1]))
})
MISS <- MISS %>% mutate(label = factor(label, levels = label[order(pct)]))
wt(MISS %>% mutate(across(c(pct, in_icu), ~ round(., 1))), "missingness.csv")

ps9 <- ggplot(MISS, aes(pct, label)) +
  geom_segment(aes(x = 0, xend = pct, yend = label), colour = "grey80", linewidth = 0.50) +
  geom_point(aes(colour = "Whole cohort"), size = 2.13) +
  geom_point(aes(x = in_icu, colour = "ICU admissions only"), size = 2.13, shape = 17) +
  scale_colour_manual(values = c("Whole cohort" = "#E64B35",
                                 "ICU admissions only" = "#3C5488"), name = NULL) +
  scale_x_continuous(limits = c(0, 102), expand = c(0, 0)) +
  labs(x = "Missing, %", y = NULL,
       title = "Figure S9  Missingness of key variables",
       subtitle = paste0("Severity scores are missing mainly without ICU monitoring. Exception: CRP and troponin are not routine ICU tests,",
                         " so their missingness is higher within ICU admissions (CRP 96.9% vs 95.0% overall) — verified against raw data.")) +
  THEME + theme(legend.position = "top", panel.grid.major.y = element_blank())
save_fig(ps9, "FigS09_missingness", 7.4, 6.4)

## =============================================================================================
## [19] Fig S10 — RRT 分布与验证（★ 新口径，修正旧版 29.8% 的说法）
## =============================================================================================
cat("\n[19] Fig S10 RRT 分布 ...\n")

RS <- M %>% group_by(mrsa_f) %>%
  summarise(n = n(), k = sum(rrt == 1, na.rm = TRUE), .groups = "drop") %>%
  mutate(pct = 100 * k / n) %>% rowwise() %>%
  mutate(lo = 100*wilson(k, n)[1], hi = 100*wilson(k, n)[2]) %>% ungroup()

ps10a <- ggplot(RS, aes(mrsa_f, pct, fill = mrsa_f)) +
  geom_col(width = 0.55) +
  geom_errorbar(aes(ymin = lo, ymax = hi), width = 0.13, linewidth = 0.50) +
  geom_text(aes(label = sprintf("%.1f%%\n(%d/%d)", pct, k, n), y = hi + 1.1), size = 3.02,
            vjust = 0, lineheight = 0.9) +
  scale_fill_manual(values = COL_STATUS, guide = "none") +
  scale_y_continuous(limits = c(0, max(RS$hi) * 2.6), expand = c(0, 0)) +
  labs(x = NULL, y = "Documented RRT, %", tag = "A",
       title = "RRT prevalence by resistance status",
       caption = sprintf("Definition: documented dialysis delivery (n = %s of %s, %.1f%%).",
                         fmt_i(NODES$rrt), fmt_i(nrow(M)), 100 * NODES$rrt / nrow(M))) +
  THEME

# 验证：RRT vs 非 RRT 的器官支持与死亡
VAL <- M %>% mutate(rrt_g = factor(ifelse(rrt == 1, "RRT", "No RRT"), levels = c("No RRT", "RRT"))) %>%
  group_by(rrt_g) %>%
  summarise(n = n(),
            ICU = 100 * mean(has_icu == 1, na.rm = TRUE),
            MV  = 100 * mean(mech_vent == 1, na.rm = TRUE),
            VASO= 100 * mean(any_vasopressor == 1, na.rm = TRUE),
            D28 = 100 * mean(death_28d == 1, na.rm = TRUE),
            D90 = 100 * mean(death_90d == 1, na.rm = TRUE), .groups = "drop")
VAL_L <- VAL %>% pivot_longer(-c(rrt_g, n), names_to = "metric", values_to = "pct") %>%
  mutate(metric = factor(metric, levels = c("ICU", "MV", "VASO", "D28", "D90"),
                         labels = c("ICU admission", "Mechanical ventilation", "Vasopressors",
                                    "28-day mortality", "90-day mortality")))
ps10b <- ggplot(VAL_L, aes(metric, pct, fill = rrt_g)) +
  geom_col(position = position_dodge(width = 0.74), width = 0.68) +
  geom_text(aes(label = sprintf("%.0f", pct)), position = position_dodge(width = 0.74),
            vjust = -0.4, size = 2.80) +
  scale_fill_manual(values = c("No RRT" = "grey70", "RRT" = "#E64B35"), name = NULL) +
  scale_y_continuous(limits = c(0, 108), breaks = seq(0, 100, 25)) +
  labs(x = NULL, y = "Proportion, %", tag = "B",
       title = "Organ support and mortality by RRT status",
       caption = sprintf("%s of %s RRT admissions (%.1f%%) had no ICU record.",
                         fmt_i(NODES$rrt_no_icu), fmt_i(NODES$rrt),
                         100 * NODES$rrt_no_icu / max(NODES$rrt, 1))) +
  THEME + theme(axis.text.x = element_text(angle = 22, hjust = 1), legend.position = "top")
ps10 <- if (HAS_PATCHWORK) ps10a | ps10b else ps10a
save_fig(ps10, "FigS10_RRT_distribution", 9.6, 4.2)
wt(RS, "rrt_by_status.csv"); wt(VAL, "rrt_validation.csv")

## =============================================================================================
## [20] Fig S11 — 表型 × RRT 的 28 天死亡率
##   目的：证明表型梯度不是透析的代理（无 RRT 层内梯度依然陡）
## =============================================================================================
cat("\n[20] Fig S11 表型 × RRT ...\n")
if (HAS_PHENO) {

PR <- M %>% filter(!is.na(pheno_f)) %>%
  mutate(rrt_g = factor(ifelse(rrt == 1, "RRT", "No RRT"), levels = c("No RRT", "RRT"))) %>%
  group_by(pheno_f, rrt_g) %>%
  summarise(n = n(), k = sum(death_28d == 1), .groups = "drop") %>%
  mutate(pct = 100 * k / n) %>%
  rowwise() %>% mutate(lo = 100*wilson(k, n)[1], hi = 100*wilson(k, n)[2]) %>% ungroup()

ps11 <- ggplot(PR, aes(pheno_f, pct, fill = rrt_g)) +
  geom_col(position = position_dodge(width = 0.74), width = 0.68) +
  geom_errorbar(aes(ymin = lo, ymax = hi), position = position_dodge(width = 0.74),
                width = 0.15, linewidth = 0.44) +
  geom_text(aes(label = sprintf("%.1f%%\n%d/%d", pct, k, n), y = hi + 3.5),
            position = position_dodge(width = 0.74), vjust = 0, size = 2.58, lineheight = 0.9) +
  scale_fill_manual(values = c("No RRT" = "grey65", "RRT" = "#E64B35"), name = NULL) +
  scale_y_continuous(limits = c(0, 135), breaks = seq(0, 100, 25)) +
  labs(x = NULL, y = "28-day mortality, %",
       title = "Figure S11  28-day mortality by phenotype, cross-classified by RRT",
       subtitle = "The mortality gradient persists within the stratum without RRT",
       caption = paste("Stratum-specific estimates among RRT-treated admissions rest on few events",
                       "and are not interpretable as a treatment effect.")) +
  THEME + theme(legend.position = "top", axis.text.x = element_text(angle = 20, hjust = 1))
save_fig(ps11, "FigS11_phenotype_rrt_mortality", 8.2, 5.0)
wt(PR, "phenotype_by_rrt_mortality.csv")
} else {
  cat("  — 无表型模式，跳过 Fig S11\n")
}

## =============================================================================================
## [21] 关键数字汇总（写正文时直接取用，避免手抄出错）
## =============================================================================================
cat("\n[21] 关键数字汇总 ...\n")

hr_txt <- function(fit, trm) {
  if (!trm %in% rownames(summary(fit)$conf.int)) return("—")
  cf <- summary(fit)$conf.int[trm, ]; p <- summary(fit)$coefficients[trm, "Pr(>|z|)"]
  sprintf("%.2f (%.2f–%.2f), P %s", cf[1], cf[3], cf[4],
          ifelse(p < 0.001, "< 0.001", sprintf("= %.3f", p)))
}
KEY <- c(
  sprintf("Cohort: %s admissions / %s patients", fmt_i(NODES$admissions), fmt_i(NODES$patients)),
  sprintf("Resistance: MSSA %s / MRSA %s / not determined %s",
          fmt_i(NODES$mssa), fmt_i(NODES$mrsa), fmt_i(NODES$unknown)),
  sprintf("BSI: %s (%.1f%%)", fmt_i(NODES$bsi), NODES$bsi_pct),
  sprintf("28-day mortality: %s (%.1f%%)", fmt_i(NODES$death28), NODES$death28_pct),
  sprintf("90-day mortality: %s (%.1f%%)", fmt_i(NODES$death90), NODES$death90_pct),
  sprintf("In-hospital mortality: %s (%.1f%%)", fmt_i(NODES$deathhosp), 100*NODES$deathhosp/NODES$admissions),
  sprintf("Trajectory set: %s (%.1f%%); phenotypes %s", fmt_i(NODES$traj), NODES$traj_pct,
          if (HAS_PHENO) paste(sprintf("P%d = %d", 1:3, as.integer(table(M$pheno))), collapse = " / ")
          else "NOT RUN (no phenotype file)"),
  if (HAS_PHENO) c(
    sprintf("Cox analysis set: n = %s, %d events, concordance %.3f",
            fmt_i(m_main$n), m_main$nevent, conc(m_main)),
    sprintf("PH assumption: global scaled Schoenfeld P %s",
            ifelse(is.na(ph_global_p), "NA", ifelse(ph_global_p < 0.001, "< 0.001", sprintf("= %.3f", ph_global_p)))),
    sprintf("PRIMARY (3-phenotype) P2 vs P1: %s", hr_txt(m_main, "pheno_mPhenotype 2 (intermediate)")),
    sprintf("PRIMARY (3-phenotype) P3 vs P1: %s", hr_txt(m_main, "pheno_mPhenotype 3 (high)")),
    sprintf("MRSA vs MSSA (adjusted): %s", hr_txt(m_main, "mrsa_fMRSA")),
    sprintf("RRT (adjusted, primary + RRT model): %s", hr_txt(m_rrt, "rrt"))
  ) else sprintf("Cox models: NOT RUN (no phenotype file; Table 3 / Fig 6-7 skipped)"),
  sprintf("RRT prevalence (documented delivery): %s (%.1f%%)",
          fmt_i(NODES$rrt), 100 * NODES$rrt / NODES$admissions),
  sprintf("RRT broader definition (incl. ICD-only): %s (%.1f%%), of which ICD-only %s",
          fmt_i(NODES$rrt_any), 100 * NODES$rrt_any / NODES$admissions, fmt_i(NODES$rrt_icd)),
  sprintf("RRT admissions without ICU record: %s", fmt_i(NODES$rrt_no_icu)),
  sprintf("28-day mortality RRT+ %.1f%% vs RRT- %.1f%%",
          100*mean(M$death_28d[M$rrt==1], na.rm=TRUE), 100*mean(M$death_28d[M$rrt==0], na.rm=TRUE)),
  if (HAS_PHENO) sprintf("Phenotype-specific 28-day mortality: %s",
          paste(sprintf("P%d %.1f%%", mort_ph$pheno_f %>% as.integer(),
                         mort_ph$pct), collapse = " / "))
  else "Phenotype-specific mortality: NOT AVAILABLE"
)
writeLines(KEY, file.path(DIR_TRACE, "key_numbers.txt"))
cat(paste0("  ", KEY, collapse = "\n"), "\n")

# 版本锁定
writeLines(capture.output(sessionInfo()), file.path(DIR_TRACE, "sessionInfo.txt"))
IP <- as.data.frame(installed.packages()[, c("Package", "Version")])
IP <- IP[order(IP$Package), ]
wr(IP, "package_versions.csv")
writeLines(c(
  "script: 20_manuscript_tables_figures.R",
  sprintf("run_at: %s", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  sprintf("input: %s (nrow = %d)", IN_PATH, nrow(M)),
  "--- input data fingerprint ---",
  DATA_FINGERPRINT,
  "--- end fingerprint ---",
  sprintf("phenotype: %s", ifelse(is.na(PHENO_FILE_USED), "NOT FOUND (no-phenotype mode)", PHENO_FILE_USED)),
  sprintf("verification: v2 / 208-col / rrt=%d / rrt_any=%d / rrt_source_nonempty=%d",
          n_rrt, n_any, n_src),
  sprintf("R: %s", R.version.string),
  sprintf("out_dir: %s", normalizePath(OUT_DIR, mustWork = FALSE))
), file.path(DIR_TRACE, "run_manifest.txt"))

cat("\n══════════════════════════════════════════════════════════════\n")
cat("完成。输出目录：", normalizePath(OUT_DIR), "\n")
cat(sprintf("  表格 %d 个 | 图件 %d 个 | 溯源 %d 个\n",
            length(list.files(DIR_TAB)), length(list.files(DIR_FIG)), length(list.files(DIR_TRACE))))
if (OUT_FALLBACK) cat(sprintf("  ⚠ 注意：原设定路径不可写，已回退到 %s\n", normalizePath(OUT_DIR)))
cat("\n本次运行状态：\n")
cat(sprintf("  %s 表型文件  %s\n", if (HAS_PHENO) "✔" else "✘",
            if (HAS_PHENO) PHENO_FILE_USED else "未找到 → Fig 1 Cox 框为 n = — · events = —；Fig 3/4/S11 与 Table 3 表型项已跳过"))
cat(sprintf("  %s Cox 主分析集  %s\n",
            if (HAS_PHENO) "✔" else "—",
            if (HAS_PHENO) sprintf("n = %d · events = %d", nrow(D_MAIN), sum(D_MAIN$death_28d == 1)) else "未构建"))
cat("══════════════════════════════════════════════════════════════\n")
