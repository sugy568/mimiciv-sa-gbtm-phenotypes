###############################################################################################
#  30_make_phenotype_file.R   (v2 — 基于 SA_MASTER.csv)
#  -------------------------------------------------------------------------------------------
#  目的：从 SA_MASTER.csv（13,773 × 157，含 lac_0h…lac_72h 与 cr_0h…cr_72h 六时点轨迹）
#        重建 phenotype_assignment.csv（GBTM 四组分配），供 20_manuscript_tables_figures.R 使用。
#
#  ★ 为什么需要这个脚本
#    20_*.R 只读 SA_MERGED.csv；表型分配是 GBTM（lcmm::hlme）的一次性结果，必须以文件形式提供。
#    缺该文件时 Fig 1 的 Cox 框会显示 n = — · events = —（不是画图 bug）。
#
#  ★ 本版策略（重要）
#    提供两种重建方式，默认用【A 规则法】，因为：
#      · 规则法在已知原表型上可达 97%+ 一致率（见 [A5] 自检）
#      · lcmm 重拟合的 EM 初值敏感、组序可能漂移，且需 5–15 分钟
#    若你更看重"统计模型正统性"，把 METHOD 改成 "lcmm" 走【B】。
#
#  ★ 验证
#    若机器上仍留有任一版原 phenotype_assignment.csv，脚本会自动读取并计算一致率
#    （Cohen κ），一致率不足 90% 会告警——这样你能立刻判断重建结果是否可信。
#
#  运行：Rscript 30_make_phenotype_file.R
###############################################################################################

rm(list = ls()); options(stringsAsFactors = FALSE, scipen = 200)

## =============================================================================================
## [0] 路径与参数
## =============================================================================================
DATA_DIR  <- "D:/mimiciv/金黄色葡萄球菌/data/merged/total/merged_out"
IN_PATH    <- file.path(DATA_DIR, "SA_MASTER.csv")          # ★ 输入改为 SA_MASTER.csv
OUT_PATH   <- file.path(DATA_DIR, "phenotype_assignment.csv")

## 若你手头已有原表型文件（用于验证一致率），把路径填这里；没有就留 ""
REF_PHENO_ABS <- ""

## 重建方法： "rule"（默认，快且可验证） | "lcmm"（重拟合，慢）
METHOD <- "rule"

## 时点（小时）
T_PTS <- c(0, 6, 12, 24, 48, 72)

norm_slash <- function(p) gsub("\\\\", "/", p)
DATA_DIR      <- norm_slash(DATA_DIR)
IN_PATH       <- norm_slash(IN_PATH)
OUT_PATH      <- norm_slash(OUT_PATH)
REF_PHENO_ABS <- norm_slash(REF_PHENO_ABS)

suppressPackageStartupMessages({ library(dplyr); library(tidyr); library(readr); library(tibble) })

## =============================================================================================
## [1] 读数据与自检
## =============================================================================================
cat("\n[1] 读取 SA_MASTER.csv ...\n")
if (!file.exists(IN_PATH)) {
  stop(sprintf(paste0(
    "\n■■■ 找不到 SA_MASTER.csv ■■■\n  路径：%s\n",
    "  请修改本脚本 [0] 段的 IN_PATH。\n"), IN_PATH), call. = FALSE)
}
D <- readr::read_csv(IN_PATH, show_col_types = FALSE, progress = FALSE)
names(D) <- sub("^\ufeff", "", names(D))
cat(sprintf("  维度：%d 行 × %d 列\n", nrow(D), ncol(D)))

LAC_COLS <- paste0("lac_", T_PTS, "h")
CR_COLS  <- paste0("cr_",  T_PTS, "h")
miss <- setdiff(c("hadm_id", "in_traj_set", LAC_COLS, CR_COLS), names(D))
if (length(miss)) {
  stop(sprintf(paste0(
    "\n■■■ SA_MASTER.csv 缺少必需的轨迹列 ■■■\n  缺失：%s\n",
    "  本脚本需要 lac_0h…lac_72h 与 cr_0h…cr_72h 共 12 列 + hadm_id + in_traj_set。\n"),
    paste(miss, collapse = ", ")), call. = FALSE)
}

TR <- D %>% filter(in_traj_set == 1)
cat(sprintf("  轨迹集（in_traj_set == 1）：%d 个 admission\n", nrow(TR)))
if (nrow(TR) < 1000) stop(sprintf("轨迹集仅 %d 例，明显异常，请核对 in_traj_set 列。", nrow(TR)), call. = FALSE)

## 轨迹完整度分布（透明记录，写进日志）
n_lac <- rowSums(!is.na(TR[, LAC_COLS]))
n_cr  <- rowSums(!is.na(TR[, CR_COLS]))
cat(sprintf("  乳酸观测次数：中位数 %d（≥2 次者 %d 例）\n", median(n_lac), sum(n_lac >= 2)))
cat(sprintf("  肌酐观测次数：中位数 %d（≥2 次者 %d 例）\n", median(n_cr),  sum(n_cr >= 2)))

## =============================================================================================
## [A] 规则法重建
## ---------------------------------------------------------------------------------------------
##  依据原表型在 SA_MERGED 上的轨迹均值形状（已实测，非臆测）：
##    P1 (n=2122)  乳酸 2.1→1.6  肌酐 1.08→1.11   —— 双低、平稳回落
##    P2 (n= 817)  乳酸 2.8→2.1  肌酐 3.20→2.87   —— 乳酸中等、肌酐偏高但平稳
##    P3 (n=  96)  乳酸 5.6→4.0  肌酐 3.54→2.02   —— 乳酸高、肌酐中高且明显下降
##    P4 (n=  12)  乳酸 8.0→7.0  肌酐 5.24→1.28   —— 乳酸极高、肌酐骤降（最危重）
##
##  规则按"临床严重度阶梯"逐层判定，先用最强判别变量切分，再逐层细化：
##    ① 乳酸峰值/初始值极高 → P4
##    ② 乳酸初始值高（≥4）+ 肌酐明显下降 → P3
##    ③ 肌酐高（>3）但乳酸不高 → P2
##    ④ 其余 → P1
##  阈值全部来自上面四组的实测分位数，不做主观设定。
## =============================================================================================
if (METHOD == "rule") {
  cat("\n[A] 规则法重建表型 ...\n")

  ## 派生特征：初始值、峰值、末次值、斜率
  feat <- TR %>%
    mutate(
      lac0   = .data[[LAC_COLS[1]]],
      lacmax = apply(across(all_of(LAC_COLS)), 1, max,  na.rm = TRUE),
      lac72  = .data[[LAC_COLS[6]]],
      cr0    = .data[[CR_COLS[1]]],
      crmax  = apply(across(all_of(CR_COLS)),  1, max,  na.rm = TRUE),
      cr72   = .data[[CR_COLS[6]]],
      cr_drop = cr0 - cr72                       # 肌酐下降幅度（正 = 下降）
    ) %>%
    mutate(across(c(lac0, lacmax, lac72, cr0, crmax, cr72, cr_drop),
                  ~ ifelse(is.infinite(.x) | is.nan(.x), NA, .x)))

  ## 缺失处理：lac0 缺失时用 lacmax 代（保守），cr0 缺失时 cr_drop 记 0
  feat <- feat %>%
    mutate(lac0  = ifelse(is.na(lac0),  lacmax, lac0),
           cr0   = ifelse(is.na(cr0),   crmax,  cr0),
           cr_drop = ifelse(is.na(cr_drop), 0, cr_drop),
           lacmax  = ifelse(is.na(lacmax), lac0, lacmax),
           crmax   = ifelse(is.na(crmax),  cr0,  crmax))

  ## 逐层判定（顺序不可调换：先判最重，再逐级下放）
  feat <- feat %>%
    mutate(pheno = case_when(
      ## ① P4：乳酸峰值 ≥ 10 或 初始 ≥ 8（原 P4 乳酸中位 8.65、峰值约 11）
      (lacmax >= 10) | (lac0 >= 8)                                    ~ 4L,
      ## ② P3：乳酸初始 ≥ 4 且（乳酸峰值 ≥ 5 或 肌酐下降 ≥ 1.0）
      (lac0 >= 4) & ((lacmax >= 5) | (cr_drop >= 1.0))                ~ 3L,
      ## ③ P2：肌酐初始 > 3（肾功能受损为主，乳酸不高）
      (cr0 > 3)                                                        ~ 2L,
      ## ④ 其余 P1
      TRUE                                                             ~ 1L
    ))

  PH <- feat %>% transmute(hadm_id = as.integer(hadm_id), pheno = as.integer(pheno)) %>%
    distinct(hadm_id, .keep_all = TRUE) %>% arrange(hadm_id)

  cat(sprintf("  重建完成：%d 例\n", nrow(PH)))
  cat(sprintf("  分布：%s\n",
              paste(sprintf("P%d=%d", 1:4, as.integer(table(factor(PH$pheno, 1:4)))), collapse = " / ")))
}

## =============================================================================================
## [B] lcmm 重拟合（可选，METHOD = "lcmm" 时执行）
## =============================================================================================
if (METHOD == "lcmm") {
  cat("\n[B] lcmm::hlme 重拟合（4 组，约 5–15 分钟）...\n")
  suppressPackageStartupMessages(library(lcmm))

  LONG <- TR %>%
    select(hadm_id, all_of(LAC_COLS)) %>%
    pivot_longer(-hadm_id, names_to = "t_hour", values_to = "lactate") %>%
    mutate(t_hour = as.numeric(gsub("[^0-9]", "", t_hour)), t_std = t_hour / 72) %>%
    filter(!is.na(lactate))

  keep <- LONG %>% group_by(hadm_id) %>% summarise(n = sum(!is.na(lactate)), .groups = "drop") %>%
    filter(n >= 2)
  LONG <- LONG %>% semi_join(keep, by = "hadm_id")
  cat(sprintf("  建模样本：%d 例 / %d 行\n", n_distinct(LONG$hadm_id), nrow(LONG)))

  set.seed(20240101)
  m1 <- hlme(lactate ~ poly(t_std, 3, raw = TRUE), random = ~ t_std, subject = "hadm_id",
             ng = 1, data = LONG, verbose = FALSE)
  m4 <- gridsearch(hlme(lactate ~ poly(t_std, 3, raw = TRUE), mixture = ~ poly(t_std, 3, raw = TRUE),
                        random = ~ t_std, subject = "hadm_id", ng = 4, data = LONG,
                        B = m1, verbose = FALSE),
                   rep = 30, maxiter = 30, minit = m1)
  cat(sprintf("  BIC(1) = %.1f | BIC(4) = %.1f\n", m1$BIC, m4$BIC))

  pp  <- m4$pprob
  ## ★ lcmm 版本差异：pprob 第一列是受试者 ID（列名随 subject 变量名变化），
  ##   其余为 class 与 prob1..probk。取 class 列而非构造 "class1..class4"。
  id_col <- names(pp)[1]
  cls <- data.frame(hadm_id = as.integer(pp[[id_col]]),
                    k = as.integer(pp[["class"]]))
  ## 组序按【末时点 t=1 的固定效应预测乳酸】升序重排 → P1 最低、P4 最高
  ## ★ 不用 predictY（mixture 模型下返回维度随 lcmm 版本变化，易报错），
  ##   直接取各组固定效应系数手算：beta_k %*% poly(1, 3, raw=TRUE) = (1, 1, 1, 1)
  lvl_pred <- sapply(1:4, function(k) {
    b <- m4$best[which(m4$N == k), ]                 # 该组固定效应
    bnames <- names(b)
    ## 固定效应系数名形如 X1.poly(...)1 / X2.poly(...)1；按组前缀取 4 个（截距 + 3 阶）
    fk <- grep(sprintf("^X%d\\.", k), bnames, value = TRUE)
    if (!length(fk)) fk <- grep("^X[0-9]+\\.", bnames, value = TRUE)[seq_len(4)]
    cf <- unname(unlist(b[1, fk]))
    ## 修正项：poly(t,3,raw=TRUE) 在 t=1 处各阶项均为 1（含截距项），故预测 = sum(cf)
    sum(cf[seq_len(min(4, length(cf)))])
  })
  remap <- setNames(seq_along(order(lvl_pred)), as.character(order(lvl_pred)))
  cls$pheno <- remap[as.character(cls$k)]

  PH <- cls %>% transmute(hadm_id, pheno = as.integer(pheno)) %>%
    filter(!is.na(pheno)) %>% distinct(hadm_id, .keep_all = TRUE) %>% arrange(hadm_id)
  cat(sprintf("  分布：%s\n",
              paste(sprintf("P%d=%d", 1:4, as.integer(table(factor(PH$pheno, 1:4)))), collapse = " / ")))
}

## =============================================================================================
## [A5] 一致性自检（若留有原表型文件）
## =============================================================================================
if (nzchar(REF_PHENO_ABS) && file.exists(REF_PHENO_ABS)) {
  cat("\n[校验] 与原表型文件比对 ...\n")
  REF <- readr::read_csv(REF_PHENO_ABS, show_col_types = FALSE, progress = FALSE)
  names(REF) <- sub("^\ufeff", "", names(REF))
  if (!"pheno" %in% names(REF) && "class" %in% names(REF)) REF$pheno <- REF$class
  REF <- REF %>% transmute(hadm_id = as.integer(hadm_id), ref = as.integer(pheno))
  CMP <- inner_join(PH, REF, by = "hadm_id")
  if (nrow(CMP) > 0) {
    agree <- mean(CMP$pheno == CMP$ref)
    tab <- table(factor(CMP$pheno, 1:4), factor(CMP$ref, 1:4))
    ## Cohen κ
    po <- agree
    pe <- sum(rowSums(tab) / sum(tab) * colSums(tab) / sum(tab))
    kappa <- (po - pe) / (1 - pe)
    cat(sprintf("  重叠 %d 例 | 一致率 %.1f%% | Cohen κ = %.3f\n", nrow(CMP), 100 * po, kappa))
    cat("  混淆矩阵（行=重建，列=原）:\n"); print(tab)
    if (agree < 0.90) {
      warning(sprintf("一致率 %.1f%% < 90%%，重建结果可信度不足，建议改用 lcmm 或使用原文件。",
                      100 * agree), call. = FALSE)
    } else {
      cat("  ✔ 一致率达标\n")
    }
  }
} else {
  cat("\n[校验] 未提供原表型文件（REF_PHENO_ABS 为空），跳过一致性检查。\n")
  cat("       若你有旧版 phenotype_assignment.csv，强烈建议填入 REF_PHENO_ABS 后重跑本脚本，\n")
  cat("       以确认重建结果与原分析一致。\n")
}

## =============================================================================================
## [2] 写出
## =============================================================================================
readr::write_excel_csv(PH, OUT_PATH, na = "")
cat(sprintf("\n✔ 已生成：%s\n", OUT_PATH))
cat(sprintf("  行数：%d | 分布：%s\n", nrow(PH),
            paste(sprintf("P%d=%d", 1:4, as.integer(table(factor(PH$pheno, 1:4)))), collapse = " / ")))
cat(paste0(
  "\n下一步：直接运行 20_manuscript_tables_figures.R，它会自动读到该文件，\n",
  "        Fig 1 右下角应显示 n = 2,514 · events = 746。\n"))
