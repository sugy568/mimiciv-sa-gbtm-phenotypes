## =============================================================================================
## 21_rrt_sensitivity.R  —  RRT 口径敏感性分析（独立脚本，依赖 20_ 产出的数据约定）
##
## 目的：回答一个审稿人必问的问题 ——「RRT 调整后表型 HR 不动，是不是口径选择造成的？」
##       20_ 主脚本用的是 566（有透析执行记录）口径。本脚本把 884（含 ICD-only）口径也跑一遍。
##
## 输入： merged_out/SA_MERGED.csv          （v2，208 列）
##        figure_v3_RRT/phenotype_assignment.csv
## 输出： out_manuscript/tables/TableS_RRT_sensitivity.csv
##        out_manuscript/trace/rrt_sensitivity.txt
##
## 运行： Rscript 21_rrt_sensitivity.R
## =============================================================================================

suppressPackageStartupMessages({ library(dplyr); library(survival); library(readr) })

## ---- 路径：全自动探测（v8 起不再依赖 getwd() 与固定子目录）-----------------------------------
##   ★★★ 你的数据目录（v9 默认值，按你的实际布局写死）★★★
##   数据在 D:/mimiciv/金黄色葡萄球菌/data/merged/total/merged_out，脚本可放在任何位置运行。
##   该目录存在时优先使用；不存在（如换机器）则自动回退到下面的常规探测。
USER_DATA_DIR <- "D:/mimiciv/金黄色葡萄球菌/data/merged/total/merged_out"

##   锚点 = 本脚本所在目录。依次尝试：USER_DATA_DIR → 脚本目录 → 脚本目录/merged_out →
##   上一级、上一级/merged_out、当前工作目录、当前工作目录/merged_out。
##   因此无论 ①脚本与数据同目录 ②仓库布局 ③被 00_RUN_ALL.R 从任意目录调用，都能定位。
.script_dir <- local({
  a <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", a[grep("^--file=", a)])
  if (length(f)) return(dirname(normalizePath(f[1], winslash = "/", mustWork = FALSE)))
  of <- tryCatch(sys.frame(1)$ofile, error = function(e) NULL)
  if (!is.null(of) && nzchar(of)) return(dirname(normalizePath(of, winslash = "/", mustWork = FALSE)))
  normalizePath(getwd(), winslash = "/", mustWork = FALSE)
})
BASE_DIRS <- unique(c(if (nzchar(USER_DATA_DIR) && dir.exists(USER_DATA_DIR)) USER_DATA_DIR else character(0),
                      .script_dir,
                      file.path(.script_dir, "merged_out"),
                      dirname(.script_dir),
                      file.path(dirname(.script_dir), "merged_out"),
                      getwd(), file.path(getwd(), "merged_out")))
BASE_DIRS <- gsub("\\\\", "/", BASE_DIRS[nzchar(BASE_DIRS)])

pick_file <- function(names, subdirs = "") {
  ## ★ v8：先拼子目录再去掉多余斜杠，否则 subdirs="" 时会产生 "dir//file.csv"
  rel   <- gsub("/+", "/", file.path(subdirs, names))
  rel   <- sub("^/+", "", rel)
  cands <- as.vector(outer(BASE_DIRS, rel, file.path))
  hit <- cands[nzchar(cands) & file.exists(cands)]
  if (length(hit)) gsub("/+", "/", hit[1]) else NA_character_
}
M_PATH  <- pick_file("SA_MERGED.csv")
PH_PATH <- pick_file("phenotype_assignment.csv",
                     subdirs = c("", "figure_v3_RRT", "out_manuscript", "out_manuscript/trace",
                                 "merged_out", "out_gbtm"))

if (is.na(M_PATH)) {
  stop(sprintf(paste0(
    "\n■■■ 21_rrt_sensitivity.R 找不到 SA_MERGED.csv ■■■\n",
    "  已尝试目录：\n    %s\n",
    "处理：把 SA_MERGED.csv 放到脚本同目录，或在脚本 [路径] 段手工指定 M_PATH。\n"),
    paste(BASE_DIRS, collapse = "\n    ")), call. = FALSE)
}
if (is.na(PH_PATH)) {
  stop(sprintf(paste0(
    "\n■■■ 21_rrt_sensitivity.R 找不到 phenotype_assignment.csv ■■■\n",
    "  已尝试目录：\n    %s\n",
    "  请先运行：Rscript 00_RUN_ALL.R --stage=gbtm（或用 20_ 脚本生成）\n"),
    paste(BASE_DIRS, collapse = "\n    ")), call. = FALSE)
}
cat(sprintf("  输入 SA_MERGED.csv        ：%s\n", M_PATH))
cat(sprintf("  输入 phenotype_assignment ：%s\n", PH_PATH))

ROOT <- dirname(M_PATH)
OUT  <- file.path(ROOT, "out_manuscript")
DIR_T <- file.path(OUT, "tables"); DIR_R <- file.path(OUT, "trace")
dir.create(DIR_T, showWarnings = FALSE, recursive = TRUE)
dir.create(DIR_R, showWarnings = FALSE, recursive = TRUE)

## ---- 读入（与 20_ 同一套校验）---------------------------------------------------------------
M  <- read_csv(M_PATH,  show_col_types = FALSE, progress = FALSE)
PH <- read_csv(PH_PATH, show_col_types = FALSE, progress = FALSE)

## 版本闸门：列数与 RRT 计数是 v2 主表（208 列 / 566 例 documented RRT）的指纹
if (ncol(M) != 208) {
  stop(sprintf(paste0(
    "\n■■■ SA_MERGED.csv 列数不符 ■■■\n  实际 %d 列，应为 208 列（v2 主表）。\n",
    "  若读到 200 列，说明用的是 _archive/ 中的 v1 旧版。\n"), ncol(M)), call. = FALSE)
}
if (sum(M$rrt == 1, na.rm = TRUE) != 566) {
  stop(sprintf(paste0(
    "\n■■■ SA_MERGED.csv 的 RRT 计数不符 ■■■\n",
    "  rrt == 1 实际 %d 例，应为 566 例。\n",
    "  说明这不是本分析所用的 v2 主表，或 rrt 列被改动过。\n"),
    sum(M$rrt == 1, na.rm = TRUE)), call. = FALSE)
}

## ---- 协变量构造（必须与 20_ 的 1.3 段逐字一致，否则数字对不上）-------------------------------
M <- M %>%
  left_join(PH %>% transmute(hadm_id = as.integer(hadm_id), pheno = as.integer(pheno)),
            by = "hadm_id") %>%
  mutate(
    ## ★ v5：三表型（P1 / P2 / P3），与 00/20 号脚本同口径
    pheno_m = factor(ifelse(is.na(pheno), NA, paste0("P", pheno)), levels = paste0("P", 1:3)),
    age_grp = factor(case_when(is.na(age) ~ NA_character_,
                               age < 45 ~ "<45", age < 65 ~ "45-64",
                               age < 80 ~ "65-79", TRUE ~ "80+"),
                     levels = c("<45", "45-64", "65-79", "80+")),
    charlson_c = factor(case_when(is.na(charlson) ~ NA_character_,
                                  charlson <= 2 ~ "0-2", charlson <= 4 ~ "3-4", TRUE ~ "5+"),
                        levels = c("0-2", "3-4", "5+")),
    sofa_c = factor(case_when(is.na(sofa_24h) ~ NA_character_,
                              sofa_24h < 2 ~ "0-1",  sofa_24h < 6 ~ "2-5",
                              sofa_24h < 10 ~ "6-9", TRUE ~ "10+"),
                    levels = c("0-1", "2-5", "6-9", "10+")),
    mrsa_f = factor(ifelse(mrsa_status == "unknown", "Not determined", as.character(mrsa_status)),
                    levels = c("MSSA", "MRSA", "Not determined")),
    bsi_f  = factor(ifelse(is_bsi == 1, "BSI", "Non-BSI"), levels = c("Non-BSI", "BSI")),
    # ★ 与 20_ 完全相同的取零保护：13 例 followup <= 0 被抬到 0.01 天
    fu28   = pmax(followup_days_28d, 0.01),
    death  = as.integer(death_28d),
    # 三个 RRT 口径
    rrt_doc  = as.integer(rrt == 1),                     # 566  主口径：有透析执行记录
    rrt_any3 = as.integer(rrt_any == 1),                 # 884  宽口径：加 ICD-only
    rrt_icd  = as.integer(rrt_any == 1 & rrt == 0)       # 318  仅 ICD 码，单独作为对照
  )

##  ★ v4：主口径改用三级 pheno_m（与 20 号脚本主模型一致）
COVARS <- c("pheno_m", "mrsa_f", "age_grp", "charlson_c", "bsi_f", "sofa_c")
D <- M %>%
  filter(!is.na(fu28), !is.na(death)) %>%
  filter(if_all(all_of(COVARS), ~ !is.na(.x)))
## ★ 不硬编码 n / events（表型文件重建后分析集会变）。改为与 20_ 脚本同口径的自洽校验：
##   只验证分析集非空、事件数合理、且与主脚本 Trace 中的记录一致（若该文件存在）。
stopifnot(nrow(D) > 500, sum(D$death == 1) > 50)
KEYF <- file.path(OUT, "trace", "key_numbers.txt")
if (file.exists(KEYF)) {
  ln <- grep("^Cox analysis set:", readLines(KEYF, warn = FALSE), value = TRUE)
  if (length(ln) && grepl("n = ([0-9,]+), ([0-9]+) events", ln[1])) {
    n_ref <- as.numeric(gsub(",", "", sub(".*n = ([0-9,]+),.*", "\\1", ln[1])))
    e_ref <- as.numeric(sub(".*, ([0-9]+) events.*", "\\1", ln[1]))
    if (nrow(D) != n_ref || sum(D$death == 1) != e_ref) {
      stop(sprintf(paste0(
        "分析集与 20_ 脚本不一致：本脚本 n = %d / events = %d，trace 记录 n = %d / events = %d。\n",
        "  请先重跑 20_manuscript_tables_figures.R 再跑本脚本。"),
        nrow(D), sum(D$death == 1), n_ref, e_ref), call. = FALSE)
    }
    cat(sprintf("  ✔ 分析集与主脚本一致：n = %d，events = %d\n", nrow(D), sum(D$death == 1)))
  }
}

## ---- 拟合三个模型 ----------------------------------------------------------------------------
fit_and_tidy <- function(data, extra = NULL, label) {
  f <- as.formula(paste("Surv(fu28, death) ~", paste(c(COVARS, extra), collapse = " + ")))
  m <- coxph(f, data = data)
  b <- summary(m)$coefficients
  one <- function(k) {
    if (is.null(k) || !(k %in% rownames(b))) return(c(NA, NA, NA, NA))
    c(b[k, 2], exp(b[k, 1] - 1.96 * b[k, 3]), exp(b[k, 1] + 1.96 * b[k, 3]), b[k, 5])
  }
  mk <- function(term, key) {
    v <- one(key)
    data.frame(Model = label, Term = term,
               HR = v[1], LCL = v[2], UCL = v[3], P = v[4],
               stringsAsFactors = FALSE)
  }
  rbind(
    mk("Phenotype 2 (vs P1)", "pheno_mP2"),
    mk("Phenotype 3 (vs P1)", "pheno_mP3"),
    ## ★ v8：RRT 项用可读标签，不再直接输出变量名（rrt_doc / rrt_any3 / rrt_icd）
    mk(if (is.null(extra)) "—" else switch(extra,
         rrt_doc  = "RRT (documented)",
         rrt_any3 = "RRT (any evidence)",
         rrt_icd  = "RRT (ICD only)", extra), extra)
  ) %>%
    mutate(C = sprintf("%.3f", summary(m)$concordance[1]),
           AIC = sprintf("%.1f", AIC(m)))
}

RES <- bind_rows(
  fit_and_tidy(D, NULL,       "M0 Primary 3-level (no RRT)"),
  fit_and_tidy(D, "rrt_doc",  "M1 + RRT documented (566)"),
  fit_and_tidy(D, "rrt_any3", "M2 + RRT any-evidence (884)"),
  fit_and_tidy(D, "rrt_icd",  "M3 + ICD-only subset (318)")
)

## ---- 输出 ------------------------------------------------------------------------------------
RES_OUT <- RES %>% mutate(across(c(HR, LCL, UCL), ~ sprintf("%.3f", .x)),
                          P = ifelse(is.na(P), "",
                                ifelse(P < 0.001, "<0.001", sprintf("%.3f", P))))
write_excel_csv(RES_OUT, file.path(DIR_T, "TableS_RRT_sensitivity.csv"), na = "")

## ★ v8：删除未使用且有 bug 的 fmt()（原实现 sprintf(x, 0, 0) 参数错位）
sink(file.path(DIR_R, "rrt_sensitivity.txt"))
cat("RRT 口径敏感性分析（分析集 n =", nrow(D), "，事件", sum(D$death == 1), "）\n\n")
for (mdl in unique(RES$Model)) {
  sub <- RES[RES$Model == mdl, ]
  cat("=== ", mdl, " ===  C =", sub$C[1], " AIC =", sub$AIC[1], "\n")
  for (i in seq_len(nrow(sub))) {
    ## M0 无 RRT 项，占位行全 NA：跳过，不打印 "HR — P = —"
    if (is.na(sub$HR[i])) next
    p_txt <- if (is.na(sub$P[i])) "—" else
      if (sub$P[i] < 0.001) "<0.001" else sprintf("= %.3f", sub$P[i])
    cat(sprintf("  %-18s HR %.2f (%.2f–%.2f)   P %s\n",
                sub$Term[i], sub$HR[i], sub$LCL[i], sub$UCL[i], p_txt))
  }
  cat("\n")
}
sink()
cat(readLines(file.path(DIR_R, "rrt_sensitivity.txt")), sep = "\n")
