# =====================================================================================
# 金黄色葡萄球菌感染轨迹表型研究 —— R 分析全流程脚本
# -------------------------------------------------------------------------------------
# 输入文件(实际导出的文件名，2026-11 实测):
#   SA_TRAJ_LONG.csv     长表  hadm_id, mrsa_status, time_h, variable, value  (32,113 条 / 3,050 例)
#   SA_MASTER.csv        宽表  13,773 例 × 157 列
#   SA_CRRT_SCI.csv      RRT   13,773 例 × 11 列（rrt_strong = 566 / rrt_any = 884）
#   SA_SUSCEPT_LONG.csv  药敏  232,034 条
#   ★ 文件名已不再写死：由 01_load_data.R 按「语义关键词 + 必需列」自动定位，
#     sa_final.csv / SA_MERGED.csv 等旧名同样可用。
#
# 数据实测值(已确认):
#   creatinine: 16,485 obs / 3,050 hadm / time_h 0-72 / 中位 1.2 mg/dL
#   lactate:    15,628 obs / 3,050 hadm / time_h 0-72 / 中位 1.8 mmol/L
#   ★ 乳酸有 844 例(27.7%)观测 <3 次，采样密度偏低，见 4.2 节说明
#
# ⚠️ 运行前必读:
#   1. 修改下方 DIR 为本机数据目录(勿用中文路径)
#   2. 先跑 00_自检.R（约 30 秒），它会核对包、文件、列名与缺失率
#   3. gridsearch(rep = 30) 在 3,050 例体量下约 15 分钟/K；整套 K=1-4 两个指标
#      预计 2-3 小时。验证链路时先把 rep 降到 10、max_k 降到 3。
#   4. 首次运行请按 0 → 1 → 2 → ... 顺序分段执行,勿一次性全跑
# =====================================================================================


# =====================================================================================
# 0. 环境准备
# =====================================================================================
# 若缺包,先跑这一段(国内镜像加速)
# install.packages(c("lcmm","survival","cmprsk","riskRegression","ggplot2",
#                    "dplyr","tidyr","tableone","forestplot","patchwork",
#                    "survminer","broom","openxlsx","officer","flextable"),
#                  repos = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/")

library(lcmm)          # GBTM 核心
library(survival)      # Cox
library(cmprsk)        # Fine-Gray 竞争风险
library(ggplot2)       # 绘图
library(dplyr)
library(tidyr)
library(tableone)      # Table 1
library(patchwork)
library(broom)

# survminer 仅用于可选的 KM 美化图,若未安装则跳过(不影响主分析)
HAS_SURVMINER <- requireNamespace("survminer", quietly = TRUE)
if (!HAS_SURVMINER) message("提示:survminer 未安装,KM 图将用基础绘图替代。")

# ---- 路径设置(★改成你的实际路径) ----
DIR <- "D:/mimic"
setwd(DIR)

# ---- 版本锁定记录(交付时必须附) ----
sink("sessionInfo.txt"); print(sessionInfo()); sink()
# 同时导出包版本清单
write.csv(
  as.data.frame(installed.packages()[, c("Package","Version")]),
  "package_versions.csv", row.names = FALSE
)


# =====================================================================================
# 1. 读数据 + 数据质量门
# =====================================================================================
# ★ v4 更新(2026-09)：改用统一装载模块 01_load_data.R
#   原写法 traj <- read.csv("sa_traj_long.csv"); wide <- read.csv("sa_final.csv")
#   有两个坑，且都只在真实数据上才暴露：
#     ① 文件名已改为 SA_MASTER.csv / SA_TRAJ_LONG.csv
#        → 报错 "无法打开链结 ... 'sa_final.csv': No such file or directory"
#     ② 三张表表头都带 UTF-8 BOM(﻿"hadm_id")
#        → Windows 中文 locale 下首列变成 ï..hadm_id 或 X.U.FEFF.hadm_id,
#          后续 traj$hadm_id 取到 NULL，merge 静默变空表（比报错更危险）
#   装载模块按「语义关键词 + 必需列」定位文件（SA_MASTER / sa_final / SA_MERGED 都认），
#   自动处理 BOM 与编码，并在建模前完成：时间轴范围、非正值、同人同时点重复 三类校验。
#   详见 01_load_data.R 头部说明。
LOADER_CANDS <- c("01_load_data.R",
                  file.path(DIR, "01_load_data.R"),
                  file.path(DIR, "R", "01_load_data.R"),
                  file.path(getwd(), "01_load_data.R"))
LOADER_CANDS <- unique(LOADER_CANDS[nzchar(LOADER_CANDS)])
LOADER <- LOADER_CANDS[file.exists(LOADER_CANDS)]
if (!length(LOADER)) {
  stop(paste0(
    "\n找不到 01_load_data.R。请把它与 10_R_分析全流程.R 放在同一目录，\n",
    "或直接在该脚本所在目录运行：setwd(\"D:/mimic\"); source(\"10_R_分析全流程.R\")\n",
    "已尝试的路径：\n  ", paste(LOADER_CANDS, collapse = "\n  ")), call. = FALSE)
}
source(LOADER[1], encoding = "UTF-8")
# ↑ source 后自动获得：traj(含 time_s/time_d) / wide / crrt / suscept / QC / SA_PATHS
#   若想跳过自动装载、自行控制：先设 .SA_NO_AUTOLOAD <- TRUE，再 source(LOADER)
#   然后 D <- sa_load_all("D:/你的数据目录")

cat("\n【装载结果】\n")
cat("  轨迹长表 :", nrow(traj), "条观测 /", length(unique(traj$hadm_id)), "例\n")
cat("  病例宽表 :", nrow(wide), "例 /", ncol(wide), "列\n")
cat("  RRT 表   :", if (is.null(crrt)) "未找到（21_rrt_sensitivity.R 不可用）" else paste0(nrow(crrt), " 例"), "\n")
cat("  药敏长表 :", if (is.null(suscept)) "未找到（MRSA 回退用 wide$mrsa_status）" else paste0(nrow(suscept), " 条"), "\n")
if (!is.null(SA_PATHS)) {
  cat("  实际读取的文件：\n")
  for (k in names(SA_PATHS)) if (!is.null(SA_PATHS[[k]])) cat("    ", k, "<-", SA_PATHS[[k]], "\n")
}

# ---- 1.4 极端值清单(供人工复核，SQL 端已按 <=30 过滤，此处仅提示) ----
extreme <- traj[
  (traj$variable == "lactate"    & traj$value > 20) |
  (traj$variable == "creatinine" & traj$value > 15), ]
cat("\n极端值条数:", nrow(extreme), "(默认保留，敏感性分析中做剔除版本)\n")
if (nrow(extreme) > 0) print(utils::head(extreme[order(-extreme$value), ], 20), row.names = FALSE)

# ---- 1.5 GBTM 输入准备(时间单位换算已由装载模块完成) ----
#   time_s = time_h / 72  → [0,1]，Methods 2.4 口径
#   time_d = time_h / 24  → 按天(备用)
stopifnot(all(c("time_s", "time_d") %in% names(traj)))


# =====================================================================================
# 2. GBTM 建模 —— 方案 B:单变量分别建模(主策略)
# =====================================================================================
#   理由:multivariate 联合建模(方案 A)在 3 类以上常不收敛;
#        单变量分别建模稳健、易解释、易发表。
#   方案 A 的可选模块见本文件末尾 §11。

# ---- 通用:对单个指标执行 1-4 类网格搜索 ----
# ★★ 关键实现要点(已实测验证,勿改) ★★
#   1. hlme 在 ng>1 且 nwg=TRUE 时【必须给初值】,否则报
#      "Please specify initial values with argument 'B'"。
#      正解:用 gridsearch() 自动搜索初值(lcmm 官方推荐做法)。
#   2. summary(fit)$entropy 不存在(summary 只打印不返回对象),
#      entropy 必须手工计算,公式见 calc_entropy()。
#   3. m$pprob 第一列名是 id(不是 hadm_id),按位置取。
#   4. lcmm 的输出中【参照类 = 最后一类】,解释系数时要注意。
fit_gbtm_grid <- function(dat, var_name, max_k = 4, rep = 30, maxiter = 30) {

  d <- dat %>% filter(variable == var_name)
  d$id <- d$hadm_id                     # lcmm 需要 id 列
  d <- as.data.frame(d)
  cat("\n==========", var_name, ": n =", nrow(d),
      "obs /", n_distinct(d$id), "hadm ==========\n")

  # ---- 先拟合单类模型(作为初值基准 + BIC 参照) ----
  m1 <- hlme(fixed  = value ~ time_s + I(time_s^2),
             random = ~ time_s, subject = "id", ng = 1, data = d)

  models <- list(k1 = m1)
  out <- data.frame(
    k = 1, class_n = as.character(n_distinct(d$id)),
    n_params = length(m1$best), loglik = m1$loglik,
    BIC = m1$BIC, AIC = m1$AIC, entropy = 1,
    min_class_pct = 100, max_class_pct = 100, mean_postprob = 1,
    converged = TRUE)

  # ---- 逐次增加类别数,用 gridsearch 搜索初值 ----
  for (k in 2:max_k) {
    cat("  拟合 k =", k, "(gridsearch) ...\n")
    set.seed(1234)                       # ★ 固定随机种子,保证可复现

    m <- try(gridsearch(
      hlme(fixed   = value ~ time_s + I(time_s^2),
           mixture = ~ time_s + I(time_s^2),      # 时间项按类别变化 = 轨迹
           random  = ~ time_s,
           subject = "id",
           ng      = k,
           data    = d),
      rep = rep, maxiter = maxiter, minit = m1    # 用单类模型作初值
    ), silent = TRUE)

    if (inherits(m, "try-error")) {
      cat("    ⚠️ k =", k, "不收敛,跳过\n")
      next
    }
    models[[paste0("k", k)]] <- m

    # ---- 提取后验分类与拟合指标 ----
    p <- m$pprob
    P <- as.matrix(p[, grep("^prob", names(p))])   # 后验概率矩阵
    cls <- table(p$class)

    out <- rbind(out, data.frame(
      k             = k,
      class_n       = paste(as.integer(cls), collapse = "/"),  # ★ 各类样本量(降序展示见补充表)
      n_params      = length(m$best),   # ★ 参数个数：length(best)，非 m$N（m$N 是 lcmm 内部计数向量）
      loglik        = m$loglik,
      BIC           = m$BIC,
      AIC           = m$AIC,
      entropy       = calc_entropy(P),             # ★ 手工计算
      min_class_pct = round(100 * min(cls) / sum(cls), 1),
      max_class_pct = round(100 * max(cls) / sum(cls), 1),
      mean_postprob = round(mean(apply(P, 1, max)), 3),
      converged     = TRUE
    ))
  }
  out$variable <- var_name
  list(models = models, comparison = out, m1 = m1)
}

# ---- 熵(分类清晰度)手工计算 ----
#   公式:E = 1 - [-Σ p·ln(p)] / (N·ln(K));E∈[0,1],>0.7 表示分类清晰
calc_entropy <- function(P) {
  P <- P / rowSums(P)                    # 归一化保险
  N <- nrow(P); K <- ncol(P)
  if (K == 1) return(1)
  ent <- -sum(P * log(ifelse(P == 0, 1, P)))
  1 - ent / (N * log(K))
}

# ---- 2.1 乳酸建模 ----
lac_fit  <- fit_gbtm_grid(traj, "lactate",    max_k = 4)
# ---- 2.2 肌酐建模 ----
cr_fit   <- fit_gbtm_grid(traj, "creatinine", max_k = 4)

cat("\n===== 乳酸模型比较 =====\n"); print(lac_fit$comparison)
cat("\n===== 肌酐模型比较 =====\n"); print(cr_fit$comparison)
# 实测结果(测试数据,非真实 MIMIC):见 run.log 输出的 comparison 表

## ---- 2.3b ★ 保存 K=1–4 完整模型比较表（TableS_gbtm_selection.csv 的数据源）----
#   目的：把「为什么选三类」的判据链完整落盘——每个 K 的类样本量、BIC/AIC、
#         entropy、最小类占比、平均后验概率,供脚本 20 生成审稿补充表。
#   该文件与 sa_traj_long.csv 同目录(本脚本 setwd(DIR) 后按相对路径写出)。
kcmp_all <- rbind(lac_fit$comparison, cr_fit$comparison)
kcmp_all <- kcmp_all[, c("variable","k","class_n","n_params","loglik","BIC","AIC",
                         "entropy","min_class_pct","max_class_pct","mean_postprob","converged")]
write.csv(kcmp_all, "gbtm_k_comparison.csv", row.names = FALSE, fileEncoding = "UTF-8")
cat("\n已保存 K=1–4 模型比较 → gbtm_k_comparison.csv\n",
    "(脚本 20 将据此生成 TableS_gbtm_selection.csv;若两者目录不同,\n",
    " 请把本文件拷到脚本 20 的搜索路径中,或在控制台设 KCMP_FILE_OVERRIDE)\n")

# ---- 2.3 最佳类别数选择规则(写入论文 Methods) ----
#   判据优先级:
#     ① 候选仅限 K >= 2
#        ★ 这是 v3 版的一个真实缺陷：K=1 时 min_class_pct 恒为 100、entropy 恒为 1，
#          会无条件满足下面 ②③ 两条阈值，于是 "按规则选类" 退化成 "永远选 1 类"。
#          （实测：乳酸 K=1/2/3 的 BIC 为 56135.8 / 53293.3 / 52263.4，本应选 K=3，
#            旧实现却输出 k = 1，并随即在 name_pheno 的 cut() 处报 breaks 不唯一。）
#     ② 最小类占比 >= 5%（否则该型不具临床意义）
#     ③ entropy >= 0.7（分类清晰度）
#   多者同时满足时，取 BIC 最小者（简约原则）。
K_MIN_CLASS_PCT <- 5
K_MIN_ENTROPY   <- 0.7

# ★ 逃生阀：置为 1/2/3/4 可跳过规则强制指定类数。
#   强制指定的结果必须标 post_hoc_exploratory，不得写入摘要、不得作为核心结论依据。
FORCE_K <- NA_integer_

pick_best <- function(cmp, label) {
  cand <- cmp %>% filter(k >= 2)
  if (!nrow(cand)) {
    return(cmp %>% filter(k == 1) %>% mutate(qualifies = FALSE))
  }
  ok <- cand %>% filter(min_class_pct >= K_MIN_CLASS_PCT, entropy >= K_MIN_ENTROPY)
  if (!nrow(ok)) {
    cat(sprintf("\n⚠ %s：无任何 K>=2 的模型满足「最小类占比 >=%g%% 且 entropy >=%.1f」。\n",
                label, K_MIN_CLASS_PCT, K_MIN_ENTROPY))
    print(as.data.frame(cand[, c("k","class_n","min_class_pct","entropy","BIC")]), row.names = FALSE)
    return(cand %>% arrange(BIC) %>% slice(1) %>% mutate(qualifies = FALSE))
  }
  ok %>% arrange(BIC) %>% slice(1) %>% mutate(qualifies = TRUE)
}

resolve_k <- function(best, force, label, cmp) {
  if (!is.na(force)) {
    cat(sprintf("\n★ %s：按 FORCE_K = %d 强制指定（post_hoc_exploratory，不得写入摘要与主结论）\n",
                label, force))
    return(as.integer(force))
  }
  if (!isTRUE(best$qualifies)) {
    stop(sprintf(paste0(
      "\n■■ %s 未能按预登记规则选出 K>=2 的轨迹表型 ■■\n",
      "  最优 K=%d（%s），但最小类仅占 %.1f%%（阈值 %g%%）。\n",
      "  这意味着：本次数据中该指标的轨迹高度同质，分不出临床上有意义的亚型。\n\n",
      "  按方法学红线，此处不应硬凑类别数。可选处置：\n",
      "    ① 回查数据导出：轨迹长表的采样密度是否与设计一致（乳酸有 %d%% 的个体观测 <3 次，\n",
      "       采样过稀会把个体差异淹没在噪声里，人为压出「单类占优」）；\n",
      "    ② 若确认数据无误，则该指标改用「单一轨迹 + 个体峰值/斜率」描述，不做 GBTM 分型；\n",
      "    ③ 仅供探索：在脚本顶部把 FORCE_K 设为 2 或 3 再跑，但结果只能标 post_hoc_exploratory。"),
      label, best$k, best$class_n, best$min_class_pct, K_MIN_CLASS_PCT,
      as.integer(round(100 * mean(table(
        traj$hadm_id[traj$variable == if (grepl("乳酸", label)) "lactate" else "creatinine"]) < 3)))),
      call. = FALSE)
  }
  as.integer(best$k)
}

best_lac <- pick_best(lac_fit$comparison, "乳酸")
best_cr  <- pick_best(cr_fit$comparison,  "肌酐")
k_lac <- resolve_k(best_lac, FORCE_K, "乳酸", lac_fit$comparison)
k_cr  <- resolve_k(best_cr,  FORCE_K, "肌酐", cr_fit$comparison)
cat("\n选定乳酸类数 k =", k_lac, "\n")
cat("选定肌酐类数 k =", k_cr,  "\n")

# ---- 2.4 ★ 每个类别的人群画像（TableS_gbtm_classes.csv 的数据源）----
#   目的：稿件 Methods 2.4 引用的「类别样本量 + 峰值/首值中位数」必须在产物里可查，
#         而按【类别】汇总的表此前缺失（trajectory_means.csv 是按表型 P1–P3 汇总的，
#         与 GBTM 类不是同一个分析单位）。本函数补齐这一层。
#   输出：每个 指标 × 类别 的 n、占比、峰值/首值/72h 中位数、拟合曲线 0h 与 72h 均值。
#   注意：value 在建模时未做变换（time_s 仅缩放到 0–1），故中位数即自然尺度，
#         可直接与稿件中的 mmol/L、mg/dL 对照。
`%||%` <- function(a, b) if (is.null(a)) b else a
class_profile <- function(fit_obj, dat, var_name) {
  d <- dat %>% filter(variable == var_name)
  d$id <- d$hadm_id
  d <- as.data.frame(d)

  pp <- fit_obj$pprob
  names(pp)[1] <- "hadm_id"                       # lcmm 第一列是 id，按位置取
  d  <- merge(d, pp[, c("hadm_id", "class")], by = "hadm_id")

  ## 个体水平：峰值 / 首值 / 末值
  per <- d %>% group_by(hadm_id, class) %>%
    summarise(peak  = max(value, na.rm = TRUE),
              first = value[which.min(time_h)],
              last  = value[which.max(time_h)], .groups = "drop")

  prof <- per %>% group_by(cls = class) %>%
    summarise(n = n(), peak_med = median(peak),
              first_med = median(first), last_med = median(last), .groups = "drop")

  ## 拟合曲线起点(0h)/终点(72h)：time_s 已缩放到 [0,1]
  pr <- predictY(fit_obj, newdata = data.frame(time_s = c(0, 1)),
                 var.time = "time_s", draws = FALSE)$pred
  # ★ 矩阵用 colnames（names() 返回 NULL）。K=1 时列名不带 _class 后缀，需兜底。
  kk <- suppressWarnings(as.integer(sub(".*_class", "", colnames(pr))))
  if (all(is.na(kk))) kk <- seq_len(ncol(pr))
  pr <- pr[, order(kk), drop = FALSE]
  prof$pred_0h <- as.numeric(pr[1, ])
  prof$pred_72h <- as.numeric(pr[2, ])

  prof$variable <- var_name
  prof$model_n  <- sum(prof$n)
  prof$pct      <- round(100 * prof$n / prof$model_n, 1)
  prof$BIC      <- fit_obj$BIC
  prof$entropy  <- fit_obj$entropy %||% NA_real_
  prof[, c("variable","cls","n","pct","peak_med","first_med","last_med",
           "pred_0h","pred_72h","model_n","BIC","entropy")]
}

cls_prof <- rbind(
  class_profile(lac_fit$models[[paste0("k", k_lac)]], traj, "lactate"),
  class_profile(cr_fit$models[[paste0("k", k_cr)]],  traj, "creatinine"))
cls_prof <- cls_prof[order(cls_prof$variable, cls_prof$cls), ]
write.csv(cls_prof, "gbtm_class_summary.csv", row.names = FALSE, fileEncoding = "UTF-8")
cat("\n各类别画像（对照稿件 Methods 2.4 的类别样本量与中位数）：\n")
print(cls_prof, row.names = FALSE)
cat("已保存 → gbtm_class_summary.csv（脚本 20 将据此生成 TableS_gbtm_classes.csv）\n")


# =====================================================================================
# 3. 表型提取与命名
# =====================================================================================
# ---- 3.1 提取每个个体的类别归属 + 后验概率 ----
# ★ m$pprob 的列为: id, class, prob1, prob2, ... —— 第一列是 id 不是 hadm_id
extract_pheno <- function(fit_obj, prefix) {
  p <- fit_obj$pprob
  names(p)[1] <- "hadm_id"                 # 按位置重命名(避免列名差异)
  prob_cols <- grep("^prob", names(p), value = TRUE)
  # ★ 列名必须带 prefix：乳酸与肌酐两个表型表都有一列「分类确信度」，
  #   若都叫 max_postprob，第二次 left_join 会被改名成 max_postprob.x / .y，
  #   后续 subset(sub, max_postprob >= 0.7) 就会报 object 'max_postprob' not found。
  out <- data.frame(
    hadm_id   = p$hadm_id,
    class_raw = p$class,
    mp        = apply(as.matrix(p[, prob_cols]), 1, max)      # 分类确信度
  )
  names(out)[names(out) == "mp"] <- paste0(prefix, "_max_postprob")
  out[[paste0(prefix, "_class")]] <- out$class_raw
  out$class_raw <- NULL
  out
}
lac_ph <- extract_pheno(lac_fit$models[[paste0("k", k_lac)]], "lac")
cr_ph  <- extract_pheno(cr_fit$models[[paste0("k", k_cr)]],  "cr")

# ---- 3.2 按轨迹形态自动命名(低/中/高 + 走势) ----
#   做法:对每个类别,取其预测值曲线的起点、终点,据此命名
#   例:"持续高乳酸型"、"下降中型"、"持续低型"
name_pheno <- function(fit_obj, k) {
  if (k < 2) stop("name_pheno() 需要 K >= 2；K = 1 时无「类」可命名。", call. = FALSE)
  # 取每类的群体平均预测曲线(100 个时间点)
  pred <- predictY(fit_obj,
                   newdata = data.frame(time_s = seq(0, 1, length.out = 100)),
                   var.time = "time_s", draws = FALSE)   # ★ 参数名是 draws，写成 draw 会被 ... 吞掉
  y0  <- pred$pred[1, ]            # 起点(0h)
  y1  <- pred$pred[100, ]          # 终点(72h)
  # 分级:按 0h 水平分 低/中/高
  brks <- quantile(y0, c(0, 1/3, 2/3, 1)); brks[1] <- brks[1] - 1e-9
  lvl  <- as.character(cut(y0, breaks = brks, labels = c("低","中","高")))
  # 走势:降幅 >30% 记"下降",升幅 >30% 记"上升",否则"持续"
  trend <- ifelse(y1 < y0 * 0.7, "下降",
           ifelse(y1 > y0 * 1.3, "上升", "持续"))
  nm <- paste0(trend, lvl, "型")
  nm <- make.unique(nm)            # 防重名
  # 返回:名称 + 各类起点值(用于后续定参照类)
  list(names = nm, y0 = y0)
}
lac_nm <- name_pheno(lac_fit$models[[paste0("k", k_lac)]], k_lac)
cr_nm  <- name_pheno(cr_fit$models[[paste0("k", k_cr)]],  k_cr)
lac_names <- lac_nm$names;  y0_lac <- lac_nm$y0
cr_names  <- cr_nm$names;   y0_cr  <- cr_nm$y0
cat("\n乳酸表型命名:", paste(lac_names, collapse = " | "), "\n")
cat("肌酐表型命名:", paste(cr_names,  collapse = " | "), "\n")
# 待实测;★ 自动命名仅为初稿,最终必须人工核对轨迹图后定名

# 把类别号映射为名称
lac_ph <- lac_ph %>% mutate(lac_pheno = lac_names[lac_class])
cr_ph  <- cr_ph  %>% mutate(cr_pheno  = cr_names[cr_class])
# 以"起点最低"的类为参照(reference),便于回归解释
lac_ph$lac_pheno <- relevel(factor(lac_ph$lac_pheno), ref = lac_names[which.min(y0_lac)])
cr_ph$cr_pheno   <- relevel(factor(cr_ph$cr_pheno),  ref = cr_names[which.min(y0_cr)])


# =====================================================================================
# 4. 合并主分析数据集
# =====================================================================================
dat <- wide %>%
  left_join(lac_ph, by = "hadm_id") %>%
  left_join(cr_ph,  by = "hadm_id")

cat("\n合并后:", nrow(dat), "行;有乳酸表型:", sum(!is.na(dat$lac_pheno)),
    ";有肌酐表型:", sum(!is.na(dat$cr_pheno)), "\n")
# 待实测;期望二者都 = 3,050

# ---- 4.1 因子化关键变量 ----
dat <- dat %>%
  mutate(
    mrsa_status = factor(mrsa_status, levels = c("MSSA","MRSA","unknown")),
    gender      = factor(gender),
    death_28d   = as.numeric(death_28d),
    death_90d   = as.numeric(death_90d)
  )


# =====================================================================================
# 5. 图 F1:轨迹图(各表型 0-72h 曲线 + 95%CI)
# =====================================================================================
plot_traj <- function(fit_obj, k, var_label, pheno_names) {
  # ★ lcmm 2.x 的 predictY(draws = TRUE) 返回的是【单个矩阵】，不是 list：
  #     ng = 1  ：列名 Ypred / lower.Ypred / upper.Ypred
  #     ng >= 2 ：列名 Ypred_class1 / lower.Ypred_class1 / ... / upper.Ypred_classK
  #   必须按列名取。写成 pred$lower 不会报错（返回 NULL），一路传到 data.frame()
  #   才炸成 "arguments imply differing number of rows: 300, 900, 0"。
  tm <- seq(0, 72, length.out = 100)
  P  <- predictY(fit_obj, newdata = data.frame(time_s = tm / 72),
                 var.time = "time_s", draws = TRUE)$pred
  has_suffix <- any(grepl("_class", colnames(P)))
  pick <- function(pref, j) {
    nm <- paste0(pref, if (has_suffix) paste0("_class", j) else "")
    ix <- match(nm, colnames(P))
    if (is.na(ix)) stop(sprintf("predictY 输出中找不到列 %s；实际列为：%s",
                                nm, paste(colnames(P), collapse = ", ")), call. = FALSE)
    ix
  }
  df <- do.call(rbind, lapply(seq_len(k), function(j) {
    data.frame(time_h = tm,
               y      = P[, pick("Ypred", j)],
               lo     = P[, pick("lower.Ypred", j)],
               hi     = P[, pick("upper.Ypred", j)],
               class  = factor(pheno_names[j], levels = pheno_names))
  }))
  ggplot(df, aes(time_h, y, color = class, fill = class)) +
    geom_ribbon(aes(ymin = lo, ymax = hi), alpha = .2, color = NA) +
    geom_line(linewidth = 1) +
    labs(x = "距首次金葡菌检出时间(小时)", y = var_label, color = "表型", fill = "表型") +
    theme_bw(base_size = 13)
}
f1a <- plot_traj(lac_fit$models[[paste0("k", k_lac)]], k_lac, "乳酸 (mmol/L)", lac_names)
f1b <- plot_traj(cr_fit$models[[paste0("k", k_cr)]],  k_cr,  "肌酐 (mg/dL)",  cr_names)
f1  <- f1a / f1b
ggsave("F1_轨迹图.png", f1, width = 8, height = 9, dpi = 300)


# =====================================================================================
# 6. Table 1:按表型分层的基线特征
# =====================================================================================
vars  <- c("age","gender","mrsa_status","is_bsi","chf","hypertension","diabetes",
           "ckd","copd","malignancy","hosp_los_days","icu_los_hours",
           "wbc_max","hgb_min","plt_min","cr_max","albumin_min",
           "lactate_max","inr_max","crp_max","mech_vent","any_vasopressor","gcs_total")
catvars <- c("gender","mrsa_status","is_bsi","chf","hypertension","diabetes",
             "ckd","copd","malignancy","mech_vent","any_vasopressor")

# 仅对进入轨迹分析者做 Table 1
sub <- dat %>% filter(!is.na(lac_pheno))
t1 <- CreateTableOne(vars = vars, strata = "lac_pheno", data = sub,
                     factorVars = catvars, addOverall = TRUE)
t1_out <- print(t1, showAllLevels = TRUE, smd = TRUE, quote = FALSE)
write.csv(t1_out, "Table1_乳酸表型分层.csv")
print(t1_out)   # 待实测


# =====================================================================================
# 7. Cox 回归(F2 森林图):表型 → 28d 死亡
# =====================================================================================
#   time zero = sa_first_time,已由 SQL 保证;随访天数 followup_days_28d
sub <- sub %>% mutate(
  surv_time = ifelse(is.na(followup_days_28d), 28, followup_days_28d),
  surv_time = pmax(surv_time, 0.1)      # 避免 0 或负值
)

# 模型 1:未校正
m1 <- coxph(Surv(surv_time, death_28d) ~ lac_pheno, data = sub)
# 模型 2:校正人口学 + 合并症
m2 <- coxph(Surv(surv_time, death_28d) ~ lac_pheno + age + gender + mrsa_status +
              chf + diabetes + ckd + copd + malignancy, data = sub)
# 模型 3:再加严重度
m3 <- coxph(Surv(surv_time, death_28d) ~ lac_pheno + age + gender + mrsa_status +
              chf + diabetes + ckd + copd + malignancy +
              is_bsi + mech_vent + any_vasopressor + cr_max, data = sub)

# 肌酐表型同样三模型
mc1 <- coxph(Surv(surv_time, death_28d) ~ cr_pheno, data = sub)
mc2 <- coxph(Surv(surv_time, death_28d) ~ cr_pheno + age + gender + mrsa_status +
               chf + diabetes + ckd + copd + malignancy, data = sub)
mc3 <- coxph(Surv(surv_time, death_28d) ~ cr_pheno + age + gender + mrsa_status +
               chf + diabetes + ckd + copd + malignancy +
               is_bsi + mech_vent + any_vasopressor + cr_max, data = sub)

for (nm in c("m1","m2","m3","mc1","mc2","mc3")) {
  cat("\n=====", nm, "=====\n")
  print(summary(get(nm)))
}
# 待实测

# ---- 7.1 比例风险假定检验(Schoenfeld) ----
cat("\n===== PH 假定检验(模型 3) =====\n")
print(cox.zph(m3))
# ★ pH < 0.05 的变量 → 需在论文中说明,或改用分层/时变系数


# =====================================================================================
# 8. 交互检验:表型 × MRSA/MSSA(F4)
# =====================================================================================
sub_mm <- sub %>% filter(mrsa_status %in% c("MRSA","MSSA"))
m_int <- coxph(Surv(surv_time, death_28d) ~ lac_pheno * mrsa_status + age + gender +
                 chf + diabetes + ckd, data = sub_mm)
cat("\n===== 交互项检验 =====\n")
print(anova(m_int))
print(summary(m_int))
# ★ 交互项 P 值 < 0.05 → 表型效应在 MRSA/MSSA 间存在差异(核心卖点)
# ★ 若 P > 0.05 → 如实报告"未发现显著交互",不得强行解读


# =====================================================================================
# 9. Fine-Gray 竞争风险(F3):90d 死亡,出院为竞争事件
# =====================================================================================
#   cr_status: 0=截尾 1=死亡 2=出院(竞争)  —— 已在 SQL 端算好
sub_fg <- sub %>% filter(!is.na(cr_status))
fg <- crr(ftime   = sub_fg$cr_time_days,
          fstatus = sub_fg$cr_status,
          cov1    = model.matrix(~ lac_pheno + age + gender + mrsa_status, sub_fg)[, -1])
cat("\n===== Fine-Gray 结果 =====\n")
print(summary(fg))
# 待实测

# ---- 9.1 累积发生函数(CIF)曲线 ----
#   ★ 无模型版,直接用 cmprsk 的分组估计
pdf("F3_累积发生函数.pdf", width = 7, height = 6)
ggcmprsk <- function() {
  f <- cuminc(sub_fg$cr_time_days, sub_fg$cr_status, group = sub_fg$lac_pheno)
  plot(f, xlab = "距感染天数", ylab = "累积发生率", main = "90d 死亡累积发生率(竞争风险)")
}
ggcmprsk()
dev.off()


# =====================================================================================
# 10. 敏感性分析矩阵
# =====================================================================================
sens <- list()

# S1 排除 SA-BSI
sens$S1 <- coxph(Surv(surv_time, death_28d) ~ lac_pheno + age + gender,
                 data = subset(sub, is_bsi == 0))

# S2 排除 unknown
sens$S2 <- coxph(Surv(surv_time, death_28d) ~ lac_pheno + age + gender,
                 data = subset(sub, mrsa_status %in% c("MRSA","MSSA")))

# S3 改从中位随访时间截尾
sens$S3 <- coxph(Surv(surv_time, death_28d) ~ lac_pheno + age + gender,
                 data = sub)

# S4 用院内死亡替代 28d 死亡
sens$S4 <- coxph(Surv(surv_time, death_inhospital) ~ lac_pheno + age + gender,
                 data = sub)

# S5 剔除分类确信度低者(max_postprob < 0.7)
sens$S5 <- coxph(Surv(surv_time, death_28d) ~ lac_pheno + age + gender,
                 data = subset(sub, lac_max_postprob >= 0.7))   # ★ 用带前缀的列名

cat("\n===== 敏感性分析汇总 =====\n")
for (nm in names(sens)) {
  cat("\n---", nm, "---\n")
  print(broom::tidy(get(nm, envir = as.environment(sens)), conf.int = TRUE, exponentiate = TRUE))
}
# 待实测


# =====================================================================================
# 11. 【可选】方案 A:双变量联合轨迹建模
# =====================================================================================
# ⚠️ 风险提示:multivariate 潜类别模型在 k>=3 时常不收敛;
#    若下面报错或不收敛,放弃即可,不影响方案 B 的完整性。
#
# traj_multi <- traj %>% arrange(hadm_id, variable, time_h)
# m_joint <- try(
#   hlme(value ~ time_s + I(time_s^2) + variable,
#        mixture = ~ time_s + I(time_s^2) + variable,
#        random  = ~ time_s + variable,
#        subject = "hadm_id",
#        ng      = 2,
#        data    = as.data.frame(traj_multi),
#        nwg     = TRUE),
#   silent = TRUE)
# if (!inherits(m_joint, "try-error")) {
#   print(summary(m_joint))
#   # 后续表型提取、生存分析同 §3-§9,把 lac_pheno 换成 joint 表型即可
# } else {
#   cat("⚠️ 联合建模未收敛,改用方案 B(单变量分别建模)。这须在论文局限性中说明。\n")
# }


# =====================================================================================
# 12. 结果导出(R 端产出)
# =====================================================================================
# 生成的 CSV / 图片清单:
#   sessionInfo.txt            环境与版本(交付必附)
#   package_versions.csv       包版本清单
#   F1_轨迹图.png              Figure 1
#   F3_累积发生函数.pdf         Figure 3
#   Table1_乳酸表型分层.csv     Table 1
#   (F2 森林图 / F4 交互图 待模型结果确定后补画)
#
# ★ 交付前自检:
#   [ ] N 与 SQL 端一致(13,773 行 / 3,050 例进入轨迹)
#   [ ] 各表型最小类占比 >= 5%
#   [ ] entropy >= 0.7
#   [ ] Cox PH 假定检验已做
#   [ ] 敏感性分析 >= 3 项且方向一致
#   [ ] 所有图与正文数字逐一对齐
