## ============================================================================
##  增量 C 统计量（incremental discrimination）分析脚本
##  稿件：Joint trajectories of serum lactate and creatinine after S. aureus detection
##  数据集：MIMIC-IV v2.2 衍生表（SA_MASTER / SA_TRAJ_LONG）
## ----------------------------------------------------------------------------
##  本脚本回答一个审稿问题：
##    「轨迹表型（P1–P3）相对 临床基线 + 单点乳酸 + 单点肌酐，
##      是否提供额外的判别力？」
##  同时给出「表型 vs 耐药状态」的判别力对照（稿件的核心主张）。
## ----------------------------------------------------------------------------
##  输入（均置于 DATA_DIR）：
##    SA_MASTER.csv      一行一住院的主表（含结局、协变量）
##    SA_TRAJ_LONG.csv   轨迹长表（hadm_id, time_h, variable, value）
##    phenotype_assignment.csv（可选）已归属表型，存在时优先使用
##    package_versions.csv（可选）用于版本锁定核对
##  输出（置于 OUT_DIR）：
##    incremental_C_models.csv / _delta.csv / _univariable.csv / _sensitivity.csv
##    incremental_C_phenotype_risk.csv, Fig_incremental_C.png, sessionInfo.txt
## ----------------------------------------------------------------------------
##  复现说明：
##    · 全部随机过程设固定种子（SEED），bootstrap 可复现
##    · 轨迹模型结果缓存为 gbtm_k3_cache.rds，重复运行不需重拟合
##    · 若只需判别力分析、已有表型文件，把 PHENO_MODE 设为 "file" 可秒级完成
## ============================================================================

## ---------------------------- 0. 运行配置 ----------------------------------
## 均可用环境变量覆盖，便于换数据目录或切换模式而不改代码：
##   DATA_DIR=/path/to/csv OUT_DIR=/path/out PHENO_MODE=file GRID_REP=10 Rscript 40_...
## ★ Windows 用户请在此直接改成您存放 CSV 的文件夹，例如：
##     DATA_DIR <- "D:/meta/SA_data"
##   留空（""）则自动探测：当前工作目录 → 脚本所在目录
DATA_DIR   <- Sys.getenv("DATA_DIR",  unset = "")
OUT_DIR    <- Sys.getenv("OUT_DIR",   unset = "")        # 留空则 <当前工作目录>/incremental_C_out
PHENO_MODE <- Sys.getenv("PHENO_MODE", unset = "auto")   # "auto" | "file" | "recompute"
PHENO_FILE <- Sys.getenv("PHENO_FILE", unset = "")       # 显式指定表型文件（可选）
GRID_REP   <- as.integer(Sys.getenv("GRID_REP", unset = "30"))  # 起始值网格搜索次数
SEED       <- as.integer(Sys.getenv("SEED", unset = "20261111"))
BOOT_B     <- as.integer(Sys.getenv("BOOT_B", unset = "500"))   # bootstrap 次数

if (!nzchar(OUT_DIR)) OUT_DIR <- file.path(getwd(), "incremental_C_out")
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

set.seed(SEED)
suppressPackageStartupMessages({
  library(pROC)     # AUC / DeLong 检验
  library(lcmm)     # 潜类别混合模型（GBTM）
})

## ---------------------------- 1. 稳健读取 ----------------------------------
## 提示：Windows 中文 locale 下 UTF-8 BOM 会把首列读成 "ï..hadm_id"，此处统一剥离
read_csv_safe <- function(path) {
  x <- read.csv(path, fileEncoding = "UTF-8-BOM", stringsAsFactors = FALSE,
                check.names = FALSE, na.strings = c("", "NA", "NULL", "NaN"))
  names(x) <- sub("^\ufeff", "", names(x))      # 剥离 UTF-8 BOM
  names(x) <- sub("^ï\\.\\.", "", names(x))    # 兜底：BOM 被按 latin1 读出的情形
  x
}

## ---- 1.1 候选目录：显式 DATA_DIR → 当前工作目录 → 脚本所在目录 ----------
script_dir <- function() {
  a  <- commandArgs(trailingOnly = FALSE)
  fa <- grep("^--file=", a, value = TRUE)
  if (!length(fa)) return(NA_character_)              # 交互式 source 时无此参数
  dirname(normalizePath(sub("^--file=", "", fa[1]), winslash = "/", mustWork = FALSE))
}

cand_dirs <- function() {
  d <- c(DATA_DIR,
         getwd(),            file.path(getwd(), "data"),
         script_dir(),       file.path(script_dir(), "data"))
  d <- d[!is.na(d) & nzchar(d)]
  d <- unique(normalizePath(d, winslash = "/", mustWork = FALSE))
  d[dir.exists(d)]
}

cand_csv <- function() {
  fs <- unlist(lapply(cand_dirs(), function(d)
    list.files(d, pattern = "\\.csv$", full.names = TRUE, ignore.case = TRUE)),
    use.names = FALSE)
  unique(normalizePath(fs, winslash = "/", mustWork = FALSE))
}

## ---- 1.2 只读表头（前 3 行），比整表读入快，用于按列名识别文件 ----------
csv_head <- function(path, n = 3) {
  h <- tryCatch(
    names(read.csv(path, nrows = n, fileEncoding = "UTF-8-BOM",
                   check.names = FALSE, stringsAsFactors = FALSE)),
    error = function(e) character(0), warning = function(w) character(0))
  sub("^\ufeff|^ï\\.\\.", "", h)
}

## ---- 1.3 三级定位：名称+列名 → 仅列名 → 仅名称；多份命中取最大文件 ------
## 之所以不只按文件名找：上传/重命名后文件名可能变成 MASTER.csv、主表.csv 等
locate <- function(role, keys, need_cols) {
  fs <- cand_csv()
  if (!length(fs)) return(NA_character_)
  nm  <- tolower(basename(fs))
  hd  <- lapply(fs, csv_head)

  by_name <- vapply(nm, function(z)
    all(vapply(keys, function(k) grepl(k, z, fixed = TRUE), logical(1))), logical(1))
  by_col  <- vapply(hd, function(h)
    length(h) > 0 && all(tolower(need_cols) %in% tolower(h)), logical(1))

  pick <- function(idx) {
    if (!any(idx)) return(NA_character_)
    g <- fs[idx]
    g[which.max(file.info(g)$size)]
  }
  for (m in list(by_name & by_col, by_col, by_name)) if (any(m)) return(pick(m))
  NA_character_
}

f_master <- locate("主表",     c("master", "sa"),  c("hadm_id", "death_28d"))
f_traj   <- locate("轨迹长表", c("traj", "long"),  c("hadm_id", "time_h", "variable", "value"))
f_pheno  <- if (nzchar(PHENO_FILE)) PHENO_FILE else
            locate("表型",     c("phenotype"),     c("hadm_id", "pheno"))
f_ver    <- locate("版本清单", c("package", "version"), c("package", "version"))

## ---- 1.4 定位失败时给出可操作诊断，而不是一句 stopifnot ----------------
if (is.na(f_master) || is.na(f_traj)) {
  cat("\n[定位失败] 主表 =", f_master, " 轨迹长表 =", f_traj, "\n")
  cat("[已扫描目录]\n"); print(cand_dirs())
  cat("[目录内发现的 CSV]\n"); print(basename(cand_csv()))
  stop(paste0(
    "未找到 SA_MASTER.csv / SA_TRAJ_LONG.csv。\n",
    "处理办法（任选其一）：\n",
    "  1) 在脚本第 0 节把 DATA_DIR 改成存放 CSV 的文件夹，Windows 写法如\n",
    "       DATA_DIR <- \"D:/meta/SA_data\"          （正斜杠，或双反斜杠）\n",
    "  2) 先 setwd(\"D:/meta/SA_data\") 再运行本脚本；\n",
    "  3) 命令行指定：DATA_DIR=\"D:/meta/SA_data\" Rscript 40_incremental_C_statistic.R\n",
    "注意：R 不能识别单个反斜杠，\"D:\\meta\" 会报错；中文路径建议先改成英文。"),
    call. = FALSE)
}
cat(sprintf("[定位] 主表     : %s\n", f_master))
cat(sprintf("[定位] 轨迹长表 : %s\n", f_traj))
cat(sprintf("[定位] 表型文件 : %s\n", ifelse(is.na(f_pheno), "（无，将按 Methods 重算）", f_pheno)))
master <- read_csv_safe(f_master)
traj   <- read_csv_safe(f_traj)
cat(sprintf("[读入] 主表 %d 行 × %d 列\n", nrow(master), ncol(master)))
cat(sprintf("[读入] 轨迹长表 %d 行（%d 例住院）\n",
            nrow(traj), length(unique(traj$hadm_id))))

## ------------------- 2. 轨迹表型：读取或按 Methods 重算 --------------------
## 与稿件一致：hlme 二次固定效应 + 随机斜率 + 二次 mixture，K=3，gridsearch
derive_phenotype <- function(traj, rep_n = GRID_REP, cache = file.path(OUT_DIR, "gbtm_k3_cache.rds")) {
  if (file.exists(cache)) { cat("[轨迹] 命中缓存，跳过拟合\n"); return(readRDS(cache)) }

  traj$time_s <- traj$time_h / 72          # 以 72 h 为 1 个单位，改善数值稳定性
  traj <- traj[!is.na(traj$value) & !is.na(traj$time_s), ]
  out <- list()

  for (mk in c("lactate", "creatinine")) {
    d <- traj[traj$variable == mk, ]
    cat(sprintf("[轨迹] %s：%d 次观测 / %d 例\n", mk, nrow(d), length(unique(d$hadm_id))))

    ## 单类解作为 gridsearch 的起点锚
    m1 <- hlme(value ~ time_s + I(time_s^2), random = ~ time_s,
               subject = "hadm_id", ng = 1, data = d, verbose = FALSE)
    ## K=3 多起点搜索（离散度大，单起点易陷局部最优）
    m3 <- gridsearch(
      hlme(value ~ time_s + I(time_s^2), mixture = ~ time_s + I(time_s^2),
           random = ~ time_s, subject = "hadm_id", ng = 3, data = d, verbose = FALSE),
      rep = rep_n, maxiter = 30, minit = m1)

    pp <- m3$pprob                                    # hadm_id / class / prob1..3
    names(pp)[2] <- "class_raw"
    ## 注意：m3$N 是 lcmm 内部计数向量，不是各类例数；类规模必须由 pprob 统计
    sizes <- table(pp$class_raw)
    cat("       类规模：", paste(names(sizes), as.integer(sizes), sep = ":", collapse = "  "),
        sprintf("  BIC=%.1f\n", m3$BIC))

    ## 严重度排序：以类内观测值的临床（未变换）尺度均值排序，1=最低
    sev <- tapply(d$value, pp$class_raw[match(d$hadm_id, pp$hadm_id)], mean, na.rm = TRUE)
    ord <- order(as.numeric(sev))                     # 由低到高
    rank_map <- setNames(seq_along(ord), names(sev)[ord])
    pp[[paste0("rank_", mk)]] <- as.integer(rank_map[as.character(pp$class_raw)])

    out[[mk]] <- pp[, c("hadm_id", "class_raw", paste0("rank_", mk))]
  }

  ph <- merge(out$lactate, out$creatinine, by = "hadm_id")
  ## 联合表型：两个严重度秩相加（2–6），2→P1，3→P2，≥4→P3
  ph$score <- ph$rank_lactate + ph$rank_creatinine
  ph$pheno <- ifelse(ph$score <= 2, 1L, ifelse(ph$score == 3, 2L, 3L))

  saveRDS(ph, cache)
  ph
}

use_file <- switch(PHENO_MODE,
  file      = TRUE,
  recompute = FALSE,
  auto      = !is.na(f_pheno) && nzchar(f_pheno))
if (use_file) stopifnot(!is.na(f_pheno), file.exists(f_pheno))

if (use_file) {
  pheno <- read_csv_safe(f_pheno)[, c("hadm_id", "pheno")]
  cat(sprintf("[表型] 读取已有归属文件：%d 例（P1/P2/P3 = %s）\n", nrow(pheno),
              paste(table(pheno$pheno)[c("1","2","3")], collapse = "/")))
} else {
  pheno <- derive_phenotype(traj)
  cat(sprintf("[表型] 由轨迹重算：%d 例（P1/P2/P3 = %s）\n", nrow(pheno),
              paste(table(pheno$pheno)[c("1","2","3")], collapse = "/")))
}

## ----------------------- 3. 建模数据集与协变量 -----------------------------
## ---- 3.0 列名解析层：容忍不同 SQL 导出版本的命名差异 --------------------
## 说明：不同批次导出的主表列名常不一致（lac_0h / lactate_0h / lac_t0 …），
##       这里用「候选名列表」把实际列映射成脚本内部统一的标准名。
##       若报「缺少必需变量」，把您表里的实际列名加入对应 candidates 即可。
ensure <- function(df, target, candidates, required = TRUE) {
  if (target %in% names(df)) return(df)
  hit <- candidates[candidates %in% names(df)]
  if (length(hit)) {
    df[[target]] <- df[[hit[1]]]
    cat(sprintf("[列名] %s  <-  %s\n", target, hit[1]))
    return(df)
  }
  if (required)
    stop(sprintf(paste0("主表缺少必需变量“%s”。\n候选名：%s\n现有列（前 40 个）：\n%s\n",
                        "若您的导出表用了别的列名，请把该列名加入该变量的 candidates 后重跑。"),
                 target, paste(candidates, collapse = ", "),
                 paste(head(names(df), 40), collapse = ", ")), call. = FALSE)
  cat(sprintf("[列名] 警告：未找到 %s（候选：%s），相关分析将自动跳过\n",
              target, paste(candidates, collapse = "/")))
  df[[target]] <- NA
  df
}

## ---- 3.1 只保留进入轨迹分析集的住院，并按 hadm_id 去重 ------------------
## 关键：主表若一行多次住院/多个培养事件，直接 merge 会把样本放大数倍
n0 <- nrow(master)
if ("in_traj_set" %in% names(master)) {
  master <- master[!is.na(master$in_traj_set) & master$in_traj_set %in% 1, ]
  cat(sprintf("[筛选] in_traj_set == 1：%d → %d 行\n", n0, nrow(master)))
} else {
  cat("[筛选] 主表无 in_traj_set 列，跳过筛选（合并后将按 hadm_id 去重）\n")
}
master <- ensure(master, "hadm_id", c("hadm_id", "adm_id", "stay_id"))
n1 <- nrow(master)
master <- master[!duplicated(master$hadm_id), ]
if (nrow(master) < n1)
  cat(sprintf("[去重] 同一 hadm_id 多行，保留首行：%d → %d 行\n", n1, nrow(master)))

## 0/1 归一化工具：兼容 TRUE/FALSE、"1"/"0"、1/0 三种导出形式
to01 <- function(x) {
  if (is.logical(x)) return(as.integer(x))
  as.integer(suppressWarnings(as.numeric(as.character(x))) %in% 1)
}

## ---- 3.2 合并表型，并核对行数（防一对多放大） --------------------------
d <- merge(master, pheno[, c("hadm_id", "pheno")], by = "hadm_id")
if (nrow(d) > nrow(pheno))
  stop(sprintf("合并后 %d 行 > 表型 %d 例：主表 hadm_id 仍不唯一，请检查导出的主表粒度。",
               nrow(d), nrow(pheno)), call. = FALSE)
if (nrow(d) < nrow(pheno))
  cat(sprintf("[合并] 警告：%d 例表型在主表中无对应行（表型 %d，可合并 %d）\n",
              nrow(pheno) - nrow(d), nrow(pheno), nrow(d)))
cat(sprintf("[合并] 表型可归属 %d 例，28 天死亡 %d 例\n",
            nrow(d), sum(to01(d$death_28d) %in% 1, na.rm = TRUE)))

## ---- 3.3 结局与协变量（含名称归一化） ----------------------------------
d <- ensure(d, "death_28d",  c("death_28d", "mort_28d", "death28", "died_28d",
                               "hospital_expire_flag", "death"))
d <- ensure(d, "age",        c("age", "age_at_admission", "anchor_age"))
d <- ensure(d, "gender",     c("gender", "sex"),                          required = FALSE)
d <- ensure(d, "charlson",   c("charlson", "charlson_index", "cci"),      required = FALSE)
d <- ensure(d, "sofa_24h",   c("sofa_24h", "sofa", "sofa_score"),         required = FALSE)
d <- ensure(d, "mrsa_status",c("mrsa_status", "mrsa", "sa_susceptibility"), required = FALSE)
d <- ensure(d, "is_bsi",     c("is_bsi", "bsi", "is_bloodstream"),        required = FALSE)

d$y <- to01(d$death_28d)
if (all(is.na(d$gender))) {
  d$male <- NA_integer_
} else {
  g <- toupper(trimws(as.character(d$gender)))
  d$male <- if (all(g %in% c("0", "1", NA))) as.integer(g %in% "1") else
            as.integer(substr(g, 1, 1) == "M")
}
if (all(is.na(d$mrsa_status))) {
  d$mr <- NA
} else {
  g <- toupper(trimws(as.character(d$mrsa_status)))
  d$mr <- factor(ifelse(grepl("^MR", g), "MRSA",
                 ifelse(grepl("^MS", g), "MSSA", "unknown")),
                 levels = c("MSSA", "MRSA", "unknown"))
}
d$ph <- factor(d$pheno, levels = 1:3)

## ---- 3.4 单点标志物：主表分时列优先，缺失则由轨迹长表回填 -------------
## 说明：部分导出版本没有 lac_0h/lac_6h… 这些分时列，只有轨迹长表，
##       因此这里做成「有则用、无则算」的双来源，避免直接报“选择了未定义的列”。
first_avail <- function(df, cols) {
  if (!length(cols)) return(rep(NA_real_, nrow(df)))
  m <- sapply(df[, cols, drop = FALSE], function(z) suppressWarnings(as.numeric(z)))
  m <- matrix(m, nrow = nrow(df))
  apply(m, 1, function(x) { x <- x[!is.na(x)]; if (length(x)) x[1] else NA_real_ })
}

## 解析主表中形如 lac_0h / lactate_6h / creat_12h 的分时列，按小时排序
tp_cols <- function(df, prefix, max_h = 24) {
  nm  <- names(df)
  hit <- grep(paste0("^", prefix, "[a-z]*_?[0-9]+h$"), nm, value = TRUE, ignore.case = TRUE)
  if (!length(hit)) return(character(0))
  hr  <- suppressWarnings(as.numeric(sub("^.*_([0-9]+)h$", "\\1", hit, ignore.case = TRUE)))
  ok  <- !is.na(hr) & hr <= max_h
  hit <- hit[ok]; hr <- hr[ok]
  hit[order(hr)]
}

## 轨迹长表聚合：marker 在 0–24 h 内的首个值（mode="first"）或峰值（mode="max"）
traj_agg <- function(marker, mode = c("first", "max"), max_h = 24) {
  mode <- match.arg(mode)
  s <- traj[traj$variable == marker & !is.na(traj$value) &
            traj$time_h >= 0 & traj$time_h <= max_h, ]
  if (!nrow(s)) return(setNames(numeric(0), character(0)))
  if (mode == "first") {
    s <- s[order(s$hadm_id, s$time_h), ]
    s <- s[!duplicated(s$hadm_id), ]
    return(setNames(as.numeric(s$value), as.character(s$hadm_id)))
  }
  tapply(s$value, as.character(s$hadm_id), max, na.rm = TRUE)
}

fill_from <- function(x, ids, map_, lab) {
  if (!length(map_)) return(x)
  need <- is.na(x)
  if (!any(need)) return(x)
  v <- as.numeric(map_[as.character(ids[need])])
  x[need] <- v
  cat(sprintf("[单点] %s：轨迹长表补全 %d / %d 例\n", lab, sum(!is.na(v)), sum(need)))
  x
}

lac_cols <- tp_cols(d, "lac")
cr_cols  <- tp_cols(d, "cr")
cat(sprintf("[单点] 主表分时列：乳酸 %d 个%s；肌酐 %d 个%s\n",
            length(lac_cols), if (length(lac_cols)) paste0("（", paste(lac_cols, collapse = "/"), "）") else "",
            length(cr_cols),  if (length(cr_cols))  paste0("（", paste(cr_cols,  collapse = "/"), "）") else ""))

d$lac_first <- first_avail(d, lac_cols)
d$cr_first  <- first_avail(d, cr_cols)
d$lac_first <- fill_from(d$lac_first, d$hadm_id, traj_agg("lactate"),    "乳酸首个值")
d$cr_first  <- fill_from(d$cr_first,  d$hadm_id, traj_agg("creatinine"), "肌酐首个值")

## 峰值（敏感性分析用）：主表 lac_max/lactate_max/cr_max 优先，否则由长表算
pick_any <- function(df, cand) { hit <- cand[cand %in% names(df)]; if (length(hit)) df[[hit[1]]] else rep(NA_real_, nrow(df)) }
d$lac_peak <- pick_any(d, c("lactate_max", "lac_max", "lac_peak", "lactate_peak"))
d$cr_peak  <- pick_any(d, c("cr_max", "creat_max", "cr_peak", "creatinine_max"))
d$lac_peak <- fill_from(d$lac_peak, d$hadm_id, traj_agg("lactate", "max"),    "乳酸 24 h 峰值")
d$cr_peak  <- fill_from(d$cr_peak,  d$hadm_id, traj_agg("creatinine", "max"), "肌酐 24 h 峰值")

d$log_lac  <- log(pmax(d$lac_first, 0.1))
d$log_cr   <- log(pmax(d$cr_first,  0.1))
d$log_lacM <- log(pmax(d$lac_peak, 0.1))      # 峰值版本，用于敏感性分析
d$log_crM  <- log(pmax(d$cr_peak,  0.1))

## ---- 3.5 基线协变量集合（缺列自动降级并告警，不静默扩样） --------------
base_terms <- c("age", "male", "charlson", "sofa_24h", "mr", "is_bsi")
base_terms <- base_terms[vapply(base_terms, function(v) {
  x <- d[[v]]; !is.null(x) && any(!is.na(x))
}, logical(1))]
if (length(base_terms) < 6)
  cat(sprintf("[模型] 警告：基线协变量降级为 %s（原始 6 项中缺失项已剔除）\n",
              paste(base_terms, collapse = ", ")))
V_BASE <- c("y", base_terms)
BASE   <- paste("y ~", paste(base_terms, collapse = " + "))
cat(sprintf("[模型] M1 基线：%s\n", BASE))

## ----------------------- 4. 增量判别力（核心分析） -------------------------
## 嵌套模型：M1 临床基线 → M2 加单点标志物 → M3 加轨迹表型
## BASE 已在 3.5 节按实际可用列动态生成（BASE <- paste("y ~", ...)），此处不再覆盖
PRIMARY <- new.env(parent = emptyenv())   # 存主分析的 ROC 对象，供出图复用

core <- function(dat, extra, vars, tag) {
  cc <- dat[complete.cases(dat[, vars]), ]
  M1 <- glm(as.formula(BASE), family = binomial, data = cc)
  M2 <- glm(as.formula(paste(BASE, extra)), family = binomial, data = cc)
  M3 <- glm(as.formula(paste(BASE, extra, "+ ph")), family = binomial, data = cc)

  cc$p1 <- fitted(M1); cc$p2 <- fitted(M2); cc$p3 <- fitted(M3)
  r1 <- roc(cc$y, cc$p1, quiet = TRUE)
  r2 <- roc(cc$y, cc$p2, quiet = TRUE)
  r3 <- roc(cc$y, cc$p3, quiet = TRUE)

  ## IDI 与连续 NRI（Pencina 2008 定义）
  e <- cc$y == 1; n <- cc$y == 0
  idi <- (mean(cc$p3[e]) - mean(cc$p2[e])) - (mean(cc$p3[n]) - mean(cc$p2[n]))
  nri <- (mean(cc$p3[e] > cc$p2[e]) - mean(cc$p3[e] < cc$p2[e])) +
         (mean(cc$p3[n] < cc$p2[n]) - mean(cc$p3[n] > cc$p2[n]))

  ## 分类 NRI（<5% / 5–20% / >20%）
  g <- function(p) cut(p, c(-Inf, .05, .20, Inf), labels = FALSE)
  nri_c <- (mean(g(cc$p3)[e] > g(cc$p2)[e]) - mean(g(cc$p3)[e] < g(cc$p2)[e])) +
           (mean(g(cc$p3)[n] < g(cc$p2)[n]) - mean(g(cc$p3)[n] > g(cc$p2)[n]))

  ## bootstrap：ΔC 的 95% CI
  dC <- replicate(BOOT_B, {
    i <- sample(nrow(cc), replace = TRUE); b <- cc[i, ]
    f2 <- try(glm(as.formula(paste(BASE, extra)), family = binomial, data = b), silent = TRUE)
    f3 <- try(glm(as.formula(paste(BASE, extra, "+ ph")), family = binomial, data = b), silent = TRUE)
    if (inherits(f2, "try-error") || inherits(f3, "try-error")) return(NA_real_)
    as.numeric(auc(roc(b$y, fitted(f3), quiet = TRUE)) - auc(roc(b$y, fitted(f2), quiet = TRUE)))
  })

  brier <- function(p) mean((cc$y - p)^2)

  ## 主分析的 ROC 对象留存，供后续出图
  if (grepl("^主分析", tag)) {
    PRIMARY$r1 <- r1; PRIMARY$r2 <- r2; PRIMARY$r3 <- r3
    PRIMARY$n <- nrow(cc); PRIMARY$deaths <- sum(cc$y)
  }
  data.frame(
    情景 = tag, n = nrow(cc), 死亡 = sum(cc$y),
    AUC_M1 = round(as.numeric(auc(r1)), 4),
    AUC_M2 = round(as.numeric(auc(r2)), 4),
    AUC_M3 = round(as.numeric(auc(r3)), 4),
    dC_加表型 = round(as.numeric(auc(r3) - auc(r2)), 4),
    dC_lo = round(quantile(dC, .025, na.rm = TRUE), 4),
    dC_hi = round(quantile(dC, .975, na.rm = TRUE), 4),
    P_delong = signif(roc.test(r3, r2, method = "delong")$p.value, 3),
    LR_chisq = round(anova(M2, M3, test = "Chisq")$Deviance[2], 2),
    P_LR = signif(anova(M2, M3, test = "Chisq")$`Pr(>Chi)`[2], 3),
    IDI = round(idi, 4), NRI_连续 = round(nri, 3), NRI_分类 = round(nri_c, 3),
    Brier_M2 = round(brier(cc$p2), 4), Brier_M3 = round(brier(cc$p3), 4),
    AIC_M2 = round(AIC(M2), 1), AIC_M3 = round(AIC(M3), 1))
}

## 四个比较情景：主分析 + 三种敏感性
res <- rbind(
  core(d, "+ log_lac + log_cr",
       c(V_BASE, "log_lac", "log_cr", "ph"),
       "主分析：单点=首个值（0–24 h）"),
  core(d, "+ log_lacM + log_crM",
       c(V_BASE, "log_lacM", "log_crM", "ph"),
       "敏感性1：单点=24 h 峰值"),
  core(d, "+ log_lac",
       c(V_BASE, "log_lac", "ph"),
       "敏感性2：仅单点乳酸"),
  core(d, "",
       c(V_BASE, "ph"),
       "敏感性3：不加单点标志物（对照临床基线）"))

## ----------------------- 5. 单变量判别力（表型 vs 耐药） -------------------
uni <- function(dat, x, lab) {          # dat 与 x 必须同长度（避免 NA 过滤后错位）
  ok <- !is.na(x) & !is.na(dat$y)
  r <- roc(dat$y[ok], x[ok], quiet = TRUE)
  ci <- as.numeric(ci.auc(r, method = "delong"))
  data.frame(指标 = lab, AUC = round(as.numeric(auc(r)), 4),
             CI = sprintf("%.3f-%.3f", ci[1], ci[3]),
             n = sum(ok))
}
cc0 <- d[complete.cases(d[, c("y","pheno","lac_first","cr_first","sofa_24h","charlson","mrsa_status")]), ]
uni_tab <- rbind(
  uni(cc0, as.integer(cc0$ph),        "轨迹表型（有序 1/2/3）"),
  uni(cc0, cc0$log_lac,               "单点乳酸（首个值，log）"),
  uni(cc0, cc0$log_cr,                "单点肌酐（首个值，log）"),
  uni(cc0, cc0$sofa_24h,              "SOFA（24 h）"),
  uni(cc0, cc0$charlson,              "Charlson 指数"),
  uni(cc0, as.integer(cc0$mr == "MRSA"), "MRSA vs 其他"))

## 各表型 28 天绝对风险
risk <- aggregate(list(死亡 = d$y, n = rep(1, nrow(d))), by = list(表型 = d$pheno), sum)
risk$风险 <- sprintf("%.1f%%", 100 * risk$死亡 / risk$n)

## ---------------------------- 6. 出图 --------------------------------------
## 图形标签统一用英文，避免无中文字体环境下的乱码
make_figure <- function() {
  roc_df <- rbind(
    data.frame(fpr = 1 - PRIMARY$r1$specificities, tpr = PRIMARY$r1$sensitivities,
               Model = sprintf("M1 clinical baseline\n(AUC %.3f)", auc(PRIMARY$r1))),
    data.frame(fpr = 1 - PRIMARY$r2$specificities, tpr = PRIMARY$r2$sensitivities,
               Model = sprintf("M2 + single-point lactate/Cr\n(AUC %.3f)", auc(PRIMARY$r2))),
    data.frame(fpr = 1 - PRIMARY$r3$specificities, tpr = PRIMARY$r3$sensitivities,
               Model = sprintf("M3 + trajectory phenotype\n(AUC %.3f)", auc(PRIMARY$r3))))

  ord <- c("敏感性3：不加单点标志物（对照临床基线）", "敏感性2：仅单点乳酸",
           "敏感性1：单点=24 h 峰值", "主分析：单点=首个值（0–24 h）")
  lab <- c("Clinical baseline\n(no single-point labs)", "+ single-point\nlactate only",
           "+ single-point lactate\n+ Cr (peak 24 h)", "+ single-point lactate\n+ Cr (first value)")
  bar <- data.frame(
    comparator = factor(lab, levels = lab),
    dC = res$dC_加表型[match(ord, res$情景)],
    P  = res$P_delong[match(ord, res$情景)])

  if (!requireNamespace("ggplot2", quietly = TRUE)) {           # 无 ggplot2 时退化为 base
    png(file.path(OUT_DIR, "Fig_incremental_C.png"), 2400, 1200, res = 220)
    par(mfrow = c(1, 2), mar = c(6.5, 4.6, 3, 1.2))
    plot(PRIMARY$r1, col = "#7f8c8d", lwd = 2, legacy.axes = TRUE, main = "A  ROC curves")
    plot(PRIMARY$r2, col = "#2E86C1", lwd = 2, add = TRUE)
    plot(PRIMARY$r3, col = "#C0392B", lwd = 2.4, add = TRUE)
    barplot(bar$dC, names.arg = gsub("\n", " ", bar$comparator), las = 2, cex.names = .7,
            col = "#5DADE2", ylab = expression(Delta*"C added by phenotype"))
    dev.off(); return(invisible(NULL))
  }

  library(ggplot2)

  ## ---- 与 Figure 7 同构的版式：粗体整图标题 + 灰色副标题 + 底部灰色注释 ----
  ## Figure 7（20_manuscript_tables_figures.R 的 THEME）表头三件套：
  ##   title    = "Figure 7  <研究问题>"（bold, 11.5, 左对齐）
  ##   subtitle = "n = …; … events; <关键统计量> | exact CIs in Table x"（grey30, 9.2）
  ##   caption  = 一句方法学说明（grey40, 8.2）
  ## Figure 8 原来只有 panel A/B 的小标题、没有整图表头，n 也挤在 panel A 标题里，
  ## 因此这里把 n / 事件数 / C 统计量统一上移到整图表头，与 Fig 7 完全对齐。
  THEME_F8 <- theme_classic(base_size = 11) +
    theme(plot.title      = element_text(face = "bold", size = 11.5, hjust = 0),
          plot.subtitle   = element_text(size = 9.2, colour = "grey30", hjust = 0),
          plot.caption    = element_text(size = 8.2, colour = "grey40", hjust = 0),
          axis.text       = element_text(colour = "grey15", size = 9.2),
          axis.title      = element_text(size = 10),
          axis.line       = element_line(linewidth = 0.53),
          axis.ticks      = element_line(linewidth = 0.53),
          panel.grid.major = element_line(linewidth = 0.35, colour = "grey88"),
          plot.margin     = margin(6, 8, 6, 6))

  p1 <- ggplot(roc_df, aes(fpr, tpr, colour = Model)) +
    geom_line(linewidth = .75) +
    geom_abline(slope = 1, intercept = 0, linetype = 3, colour = "grey60") +
    scale_colour_manual(values = c("#7f8c8d", "#2E86C1", "#C0392B")) +
    scale_x_continuous("1 - Specificity", limits = c(0, 1)) +
    scale_y_continuous("Sensitivity", limits = c(0, 1)) +
    labs(title = "A  ROC curves") +
    THEME_F8 +
    theme(legend.position = c(.62, .26), legend.title = element_blank(),
          legend.text = element_text(size = 8.6, lineheight = .95),
          legend.key.width = grid::unit(1.0, "cm"),          # 加宽图例框
          legend.margin = margin(6, 20, 6, 8),               # 右侧留白：防字体度量差异致文字出框
          legend.background = element_rect(fill = "white", colour = "grey80", linewidth = .3),
          plot.title = element_text(face = "plain", size = 10.8))

  p2 <- ggplot(bar, aes(comparator, dC)) +
    geom_col(width = .62, fill = "#5DADE2") +
    geom_text(aes(label = sprintf("+%.3f\nP = %.2g", dC, P)), vjust = -.35, size = 3.1) +
    scale_y_continuous(expression(Delta*"C-statistic added by the phenotype"),
                       limits = c(0, max(bar$dC) * 2.1)) +
    labs(title = "B  Incremental discrimination by comparator", x = NULL) +
    THEME_F8 +
    theme(axis.text.x = element_text(size = 8.4, lineheight = .95),
          plot.title = element_text(face = "plain", size = 10.8))

  ## ---- 整图表头（横跨两个 panel，措辞与 Figure 7 一致）--------------------
  ttl <- "Figure 8  Incremental discrimination of the trajectory phenotype over single-point biomarkers"
  sub <- sprintf("n = %s; %d deaths; C-statistic %.3f (M1) to %.3f (M3) | exact values in Supplementary Table S6",
                 format(PRIMARY$n, big.mark = ","), PRIMARY$deaths,
                 as.numeric(auc(PRIMARY$r1)), as.numeric(auc(PRIMARY$r3)))
  cap <- paste("(A) Receiver-operating-characteristic curves for the clinical baseline model (M1),",
               "the model additionally containing single-point lactate and creatinine (M2), and the model",
               "additionally containing the three-level trajectory phenotype (M3). (B) Increment in the",
               "C-statistic attributable to the phenotype for each comparator; the pair of first values",
               "within 0-24 h is the primary comparison.")

  fp_png <- file.path(OUT_DIR, "Fig_incremental_C.png")
  fp_pdf <- file.path(OUT_DIR, "Fig_incremental_C.pdf")

  if (requireNamespace("gridExtra", quietly = TRUE)) {
    gp <- grid::gpar
    ## textGrob 不自动换行：长句须先 strwrap，否则超出画布被截断
    sub_txt <- paste(strwrap(sub, width = 150), collapse = "\n")
    cap_txt <- paste(strwrap(cap, width = 150), collapse = "\n")
    ## 布局矩阵：表头两行（标题/副标题）→ 两个 panel → 注释一行，
    ## 行高显式给定，避免 top/bottom grob 与 panel 标题重叠
    lay <- rbind(c(1, 1),      # 粗体整图标题
                 c(2, 2),      # 灰色副标题（n / 事件数 / 指向补充表）
                 c(3, 4),      # panel A | panel B
                 c(5, 5))      # 底部灰色注释
    g <- gridExtra::arrangeGrob(
      grid::textGrob(ttl,     x = 0, hjust = 0, gp = gp(fontsize = 11.5, fontface = "bold")),
      grid::textGrob(sub_txt, x = 0, hjust = 0, gp = gp(fontsize = 9.2, col = "grey30")),
      p1, p2,
      grid::textGrob(cap_txt, x = 0, hjust = 0, vjust = 0,
                     gp = gp(fontsize = 8.2, col = "grey40")),
      layout_matrix = lay,
      heights = grid::unit(c(1.0, 0.8, 12, 1.9), "null"))
  } else {
    ## 无 gridExtra：单 panel 输出，但表头三件套仍完整保留
    g <- p1 + labs(title = ttl, subtitle = sub, caption = cap) +
      theme(plot.title = element_text(face = "bold", size = 11.5, hjust = 0))
  }

  ggsave(fp_png, g, width = 11, height = 5.9, dpi = 220, bg = "white")
  ## PDF 供投稿系统使用（与 Fig 1-7 的交付格式一致）
  ok_pdf <- tryCatch({ ggsave(fp_pdf, g, width = 11, height = 5.9, device = cairo_pdf); TRUE },
                     error = function(e) FALSE)
  if (!ok_pdf) ggsave(fp_pdf, g, width = 11, height = 5.9)
  cat(sprintf("[出图] Fig_incremental_C.png / .pdf  n = %s, deaths = %d\n",
              format(PRIMARY$n, big.mark = ","), PRIMARY$deaths))
}
make_figure()

## ---------------------------- 7. 导出 --------------------------------------
write.csv(res,     file.path(OUT_DIR, "incremental_C_models.csv"), row.names = FALSE)
write.csv(uni_tab, file.path(OUT_DIR, "incremental_C_univariable.csv"), row.names = FALSE)
write.csv(risk,    file.path(OUT_DIR, "incremental_C_phenotype_risk.csv"), row.names = FALSE)

## 版本锁定：核对 package_versions.csv 中 pROC / lcmm 的记录值
lock <- data.frame(Package = c("pROC", "lcmm", "R"),
                   Version_used = c(as.character(packageVersion("pROC")),
                                    as.character(packageVersion("lcmm")),
                                    paste(R.version$major, R.version$minor, sep = ".")))
if (!is.na(f_ver)) {
  pv <- read_csv_safe(f_ver)
  lock$Version_recorded <- pv$Version[match(tolower(lock$Package), tolower(pv$Package))]
}
write.csv(lock, file.path(OUT_DIR, "incremental_C_version_lock.csv"), row.names = FALSE)
capture.output(sessionInfo(), file = file.path(OUT_DIR, "sessionInfo.txt"))

## ---------------------------- 8. 控制台摘要 --------------------------------
cat("\n===== 判别力与增量（核心结果）=====\n"); print(res, row.names = FALSE)
cat("\n===== 单变量判别力 =====\n");          print(uni_tab, row.names = FALSE)
cat("\n===== 各表型 28 天死亡风险 =====\n");   print(risk, row.names = FALSE)
cat("\n[完成] 结果已写入：", normalizePath(OUT_DIR), "\n")
