###############################################################################################
#  00_RUN_ALL.R   (v7 — 全文统一三表型)
#  -------------------------------------------------------------------------------------------
#  一键全流程：SA_MERGED.csv → GBTM 重拟合 → phenotype_assignment.csv
#              → 全部表格（Table 1 / 1b / 2 / 3 + 附表）与全部图件（Fig 1–7 + S1–S11）
#
#  ★ v7 核心变更（修复 GBTM 退化为单类）
#    ① 每个 ng 改用多起点重拟合（GBTM_NSTART 个种子），取 BIC 最低的收敛解
#    ② 类数选择改为"由大到小"向后选择（3 → 2），与"最多 3 类"的设计意图一致
#    ③ 全部拟合尝试写入 trace/gbtm_search_log.csv，供审稿核查模型选择过程
#
#  ★ v5/v6 沿用
#    · GBTM 拟合层限定每变量最多 3 类，第 4 类不再产生
#    · 联合表型 3 档：P1 / P2 / P3，全文唯一口径
#    · 两阶段初值法 B = random(m1)，替代手写初值
#
#  运行：Rscript 00_RUN_ALL.R        （约 12–20 分钟）
#        分步：Rscript 00_RUN_ALL.R --stage=gbtm   只重拟合表型
#              Rscript 00_RUN_ALL.R --stage=plot   只出表图（复用已有表型文件）
#
#  产物：merged_out/out_manuscript/{figures,tables,trace}/
###############################################################################################

rm(list = ls()); options(stringsAsFactors = FALSE, scipen = 200)

## =============================================================================================
## [0] 路径设置
##   默认【半自动】：v9 起按你的实际布局预填数据目录，直接 Rscript 即可运行。
##     数据目录 = D:/mimiciv/金黄色葡萄球菌/data/merged/total/merged_out
##     （SA_MERGED.csv 与 phenotype_assignment.csv 都在该目录，输出写到其 out_manuscript/）
##   该目录存在时优先使用；不存在（换机器/挪目录）则自动回退到常规探测：
##     ① 脚本与 SA_MERGED.csv 同目录：Rscript 00_RUN_ALL.R
##     ② 仓库布局（脚本在 total/，数据在 total/merged_out/）：Rscript 00_RUN_ALL.R
##     ③ 从任意目录调用绝对路径：Rscript D:/.../00_RUN_ALL.R
##   若日后布局再变，只改下面 USER_DATA_DIR 一行（留 "" 表示全自动探测）。
## =============================================================================================
USER_DATA_DIR <- "D:/mimiciv/金黄色葡萄球菌/data/merged/total/merged_out"

## 定位本脚本所在目录（Rscript --file= / RStudio Source / source() 三种情形）
.script_dir <- local({
  a <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", a[grep("^--file=", a)])
  if (length(f)) {
    return(dirname(normalizePath(f[1], winslash = "/", mustWork = FALSE)))
  }
  of <- tryCatch(sys.frame(1)$ofile, error = function(e) NULL)
  if (!is.null(of) && nzchar(of)) {
    return(dirname(normalizePath(of, winslash = "/", mustWork = FALSE)))
  }
  normalizePath(getwd(), winslash = "/", mustWork = FALSE)
})
SCRIPT_DIR <- .script_dir                     # 20_/21_ 与本脚本同目录

## 数据目录候选：用户指定 > 脚本目录 > 脚本目录/merged_out > 上一级/merged_out
.dirs <- unique(c(
  USER_DATA_DIR,
  SCRIPT_DIR,
  file.path(SCRIPT_DIR, "merged_out"),
  file.path(dirname(SCRIPT_DIR), "merged_out")
))
.dirs <- .dirs[nzchar(.dirs)]
DATA_DIR <- .dirs[vapply(.dirs, function(d) file.exists(file.path(d, "SA_MERGED.csv")), logical(1))]
DATA_DIR <- if (length(DATA_DIR)) DATA_DIR[1] else SCRIPT_DIR   # 找不到时先落脚本目录，下面报错

IN_PATH    <- file.path(DATA_DIR, "SA_MERGED.csv")
PHENO_OUT  <- file.path(DATA_DIR, "phenotype_assignment.csv")
OUT_ABS    <- file.path(DATA_DIR, "out_manuscript")
SCRIPT_DIR <- gsub("\\\\", "/", SCRIPT_DIR)

## ---- 运行阶段：all / gbtm / plot ----（命令行 --stage=xxx 可覆盖）
STAGE <- "all"
.a <- commandArgs(trailingOnly = TRUE)
.m <- grep("^--stage=", .a, value = TRUE)
if (length(.m)) STAGE <- sub("^--stage=", "", .m[1])
stopifnot(STAGE %in% c("all", "gbtm", "plot"))

## ---- GBTM 参数 ------------------------------------------------------------------------------
## ★ v7（三表型定稿）：每个变量最多拟合 3 类，由 3 类起"由大到小"向后选择
##   设计依据：原 4 类解中第 4 类仅个位数病例，无法支撑稳定估计；
##   与其"拟合 4 类再合并辩解"，不如从建模层直接限定 3 类，全文口径唯一。
##   注意：hlme 对随机初值敏感，同一数据不同随机状态下可落入"空类"局部极值，
##        因此每个 ng 需做 GBTM_NSTART 次多起点重拟合，取 BIC 最低的收敛解。
GBTM_NGS      <- c(3, 2)        # 候选类数（由大到小尝试：3 → 2）
GBTM_NSTART   <- 8              # 每个类数的随机起点个数
GBTM_PMAX_OK  <- 0.85           # 最大类占比 ≥ 85% 判为退化
GBTM_MIN_N    <- 50             # 最小类至少 50 例
GBTM_BIC_GAIN <- 10             # 多一类需使 BIC 绝对下降 ≥ 10（ΔBIC < 10 视为无实质改善）
GBTM_MAXITER  <- 100
GBTM_TMAX     <- 72             # 小时
GBTM_SEED     <- 2026

norm_slash <- function(p) gsub("\\\\", "/", p)
## ★ v8：路径统一为正斜杠（Windows 反斜杠在 sprintf 报错信息里更难读），不再重复赋值
IN_PATH   <- norm_slash(IN_PATH)
PHENO_OUT <- norm_slash(PHENO_OUT)
OUT_ABS   <- norm_slash(OUT_ABS)
DATA_DIR  <- norm_slash(DATA_DIR)

suppressPackageStartupMessages({
  library(dplyr); library(tidyr); library(readr); library(tibble)
})

T_START <- Sys.time()
hdr <- function(txt) cat(sprintf("\n%s\n%s\n%s\n", strrep("=", 78), txt, strrep("=", 78)))
sep <- hdr

## =============================================================================================
## [1] 阶段 1：读数据 + 校验
## =============================================================================================
hdr("阶段 1  读取 SA_MERGED.csv 并校验")

if (!file.exists(IN_PATH)) {
  stop(sprintf(paste0(
    "\n■■■ 找不到 SA_MERGED.csv ■■■\n",
    "  当前推断的数据目录：%s\n",
    "  已尝试的目录：\n    %s\n",
    "  当前脚本目录：%s\n",
    "处理（任选其一）：\n",
    "  ① 把 SA_MERGED.csv 放到脚本同目录，或放到 脚本目录/merged_out/ 下；\n",
    "  ② 打开本脚本 [0] 段，把 USER_DATA_DIR 改成数据所在目录的绝对路径，例如\n",
    "     USER_DATA_DIR <- \"D:/mimiciv/金黄色葡萄球菌/data/merged/total/merged_out\"\n",
    "  ③ 路径分隔符写 / 或 \\\\ 均可，不要写成单个 \\（R 会当作转义解释）。\n"),
    DATA_DIR, paste(.dirs, collapse = "\n    "), SCRIPT_DIR), call. = FALSE)
}
M <- readr::read_csv(IN_PATH, show_col_types = FALSE, progress = FALSE)
names(M) <- sub("^\ufeff", "", names(M))
cat(sprintf("  读取：%s\n  维度：%d 行 × %d 列\n", IN_PATH, nrow(M), ncol(M)))

NEEDED <- c("hadm_id", "in_traj_set", "rrt", "rrt_any", "rrt_strong", "rrt_type",
            "rrt_source", "mrsa_status", "death_28d", "followup_days_28d")
miss <- setdiff(NEEDED, names(M))
if (length(miss)) {
  stop(sprintf(paste0(
    "\n■■■ SA_MERGED.csv 缺少必需列 ■■■\n  缺失：%s\n",
    "  请确认使用的是 v2（208 列）版本，而非 _archive/ 中的 v1（200 列）。\n"),
    paste(miss, collapse = ", ")), call. = FALSE)
}
if (nrow(M) != 13773) {
  stop(sprintf("行数 = %d，应为 13773。请确认读的是主表而非长表。", nrow(M)), call. = FALSE)
}
n_rrt <- sum(suppressWarnings(as.numeric(M$rrt)) == 1, na.rm = TRUE)
if (n_rrt != 566) {
  stop(sprintf(paste0("rrt 计数 = %d，应为 566。\n",
                      "  可能用了旧版数据或旧 SQL（v1 = 560）。\n"), n_rrt), call. = FALSE)
}
cat(sprintf("  ✔ 校验通过：rrt = %d | rrt_any = %d | in_traj_set = %d\n",
            n_rrt, sum(suppressWarnings(as.numeric(M$rrt_any)) == 1, na.rm = TRUE),
            sum(M$in_traj_set == 1, na.rm = TRUE)))

## =============================================================================================
## [2] 阶段 2：GBTM 拟合（STAGE 含 gbtm 时执行）
## =============================================================================================
if (STAGE %in% c("all", "gbtm")) {

hdr("阶段 2  GBTM 重新拟合（最多 3 类，由大到小向后选择）")

HAS_LCMM <- requireNamespace("lcmm", quietly = TRUE)
if (!HAS_LCMM) {
  stop(paste0(
    "\n■■■ 未安装 lcmm 包 ■■■\n",
    "  请先执行：install.packages(\"lcmm\", repos = \"https://mirrors.tuna.tsinghua.edu.cn/CRAN/\")\n"), call. = FALSE)
}
suppressPackageStartupMessages(library(lcmm))
cat(sprintf("  lcmm %s\n", as.character(packageVersion("lcmm"))))

## ---- 2.1 宽表 → 长表 -------------------------------------------------------------------------
T_PTS <- c(0, 6, 12, 24, 48, 72)
LAC_COLS <- paste0("lac_", T_PTS, "h")
CR_COLS  <- paste0("cr_",  T_PTS, "h")
if (any(!c(LAC_COLS, CR_COLS) %in% names(M))) {
  stop("SA_MERGED.csv 缺少 lac_*h 或 cr_*h 列，无法重建轨迹。", call. = FALSE)
}

TRAJ <- bind_rows(
  M %>% select(hadm_id, in_traj_set, all_of(LAC_COLS)) %>%
    pivot_longer(-c(hadm_id, in_traj_set), names_to = "col", values_to = "value") %>%
    mutate(variable = "lactate",
           time_h = as.numeric(gsub("[^0-9]", "", col))) %>% select(-col),
  M %>% select(hadm_id, in_traj_set, all_of(CR_COLS)) %>%
    pivot_longer(-c(hadm_id, in_traj_set), names_to = "col", values_to = "value") %>%
    mutate(variable = "creatinine",
           time_h = as.numeric(gsub("[^0-9]", "", col))) %>% select(-col)
) %>%
  filter(in_traj_set == 1, !is.na(value), time_h >= 0, time_h <= GBTM_TMAX) %>%
  select(hadm_id, variable, time_h, value)

cat(sprintf("  长表：%d 行 | 乳酸 %d | 肌酐 %d | %d 例\n",
            nrow(TRAJ), sum(TRAJ$variable == "lactate"), sum(TRAJ$variable == "creatinine"),
            n_distinct(TRAJ$hadm_id)))

## ---- 2.2 拟合函数 ---------------------------------------------------------------------------
prep_traj <- function(v, tmax = GBTM_TMAX) {
  d <- TRAJ %>% filter(variable == v, !is.na(value), time_h >= 0, time_h <= tmax) %>%
    transmute(hadm_id, time = time_h / 24, y = log(value + 1)) %>%
    arrange(hadm_id, time)
  keep <- d %>% count(hadm_id) %>% filter(n >= 2) %>% pull(hadm_id)      # 每例 ≥2 点
  d2 <- as.data.frame(d %>% filter(hadm_id %in% keep))
  attr(d2, "tag") <- v
  d2
}

## ★ v7 关键修复（已实测验证）：多起点重拟合，B = random(minit)
##   机制（三代失败版都因此出错，务必保留本注释）：
##     ① lcmm 2.2.2【未导出】random()，不能写 lcmm::random()，也不能 find("random")；
##        但 hlme 以 B = random(minit) 形式【惰性求值】时，会在调用者的上层环境里
##        找到 globalenv() 中的 minit，并在 hlme 内部作用域解析 random —— 可用。
##        （gridsearch() 源码就是用 substitute(random(minit)) 实现这一点的）
##     ② 仅当 globalenv() 中存在名为 minit 的 ng=1 模型对象时成立；因此下面
##        fit_one 每次都 assign("minit", m1, envir = globalenv())。
##     ③ 不可用 build_B 手写/分位数初值：实测 8 个种子全部退化为空类（0/2619, conv=2），
##        ng=3 则直接报 "the leading minor of order 1 is not positive"。
##   实测同一数据（lcmm 2.2.2, R 4.3.3）：
##     乳酸  ng=2 → 2291/328 (BIC 3608.8)；ng=3 → 2237/273/109 (BIC 2646.4)
##     肌酐  ng=2 → 324/2712 (BIC -7147.2)；ng=3 → 336/2499/201 (BIC -9836.7)
##   多起点的作用：random(minit) 本身含随机成分，不同种子可达不同局部极值，
##   取 BIC 最优者，避免"跑一次就下结论"。
.fit_ng1 <- function(d) {
  lcmm::hlme(y ~ time + I(time^2), random = ~ 1, subject = "hadm_id",
             ng = 1, data = d, verbose = FALSE)
}

fit_one <- function(d, ng, seed = GBTM_SEED, maxiter = GBTM_MAXITER, verbose = TRUE,
                    m1 = NULL) {
  t0 <- Sys.time()
  if (ng == 1) {
    m <- try(.fit_ng1(d), silent = TRUE)
  } else {
    if (is.null(m1)) {
      if (verbose) cat(sprintf("       ng = %d  ✗ 缺少 ng = 1 基准模型\n", ng))
      return(NULL)
    }
    ## ★ random(minit) 必须是"裸名字 + 全局 minit"，不能加 lcmm:: 前缀
    assign("minit", m1, envir = globalenv())
    set.seed(seed)
    m <- try(lcmm::hlme(y ~ time + I(time^2), random = ~ 1, subject = "hadm_id",
                        ng = ng, data = d, mixture = ~ time + I(time^2),
                        nwg = TRUE, B = random(minit), maxiter = maxiter,
                        verbose = FALSE), silent = TRUE)
  }
  el <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
  if (inherits(m, "try-error")) {
    if (verbose) cat(sprintf("       ng = %d  ✗ %.0f s  %s\n", ng, el,
                             strsplit(conditionMessage(attr(m, "condition")), "\n")[[1]][1]))
    return(NULL)
  }
  ## 收敛码：1 = 收敛；2 = 收敛但处于参数边界；3 = 未收敛
  cv <- if (!is.null(m$conv)) as.integer(m$conv)[1] else NA_integer_
  post <- as.matrix(m$pprob[, paste0("prob", seq_len(ng)), drop = FALSE])
  post[post < 1e-12] <- 1e-12
  ent  <- if (ng == 1) 1 else 1 - (-sum(post * log(post)) / (nrow(post) * log(ng)))
  cnt  <- as.integer(table(factor(m$pprob$class, levels = seq_len(ng))))
  if (verbose) cat(sprintf("       ng = %d  ✔ %.0f s | 占比 %-24s | 熵 %.3f | BIC %9.1f | conv %s\n",
                           ng, el, paste(cnt, collapse = "/"), ent, m$BIC, cv))
  list(model = m, ng = ng, ent = ent, cnt = cnt,
       bic = m$BIC, aic = m$AIC, sec = el,
       loglik = if (!is.null(m$loglik)) as.numeric(m$loglik)[1] else NA_real_,
       conv   = cv)
}

## ★ v7 关键修复：多起点重拟合 + 向后选择
##   random(minit) 含随机成分，不同随机状态可落入不同局部极值（包括空类退化解），
##   因此不能只跑一次就下"数据只有一类"的结论。两条改动：
##   ① 每个 ng 用 GBTM_NSTART 个种子重复拟合，取 BIC 最低的非退化解；
##   ② 选择规则改为【由大到小】的向后选择：从最大的 ng 开始，
##      若该解通过全部稳定性判据则直接采用；否则降到 ng-1 再试。
##      这与"最多 3 类、退化到 2 类"的设计意图一致（原实现是从小到大递增，
##      一旦 2 类就 break，永远不会去试 3 类）。
fit_gbtm <- function(v, ngs = GBTM_NGS, nstart = GBTM_NSTART, verbose = TRUE) {
  d <- prep_traj(v)
  cat(sprintf("  · [%s] n = %d 例 / %d 点，候选 ng = %s（每个 %d 个起点）\n",
              v, n_distinct(d$hadm_id), nrow(d),
              paste(sort(unique(ngs), decreasing = TRUE), collapse = " > "), nstart))

  ## ---- 单类基准模型（random(minit) 必须依赖它）---------------------------------------------
  m1 <- try(.fit_ng1(d), silent = TRUE)
  if (inherits(m1, "try-error")) {
    cat(sprintf("  ✗ [%s] ng = 1 基准模型未收敛：%s\n", v,
                strsplit(conditionMessage(attr(m1, "condition")), "\n")[[1]][1]))
    return(NULL)
  }
  cat(sprintf("       ng = 1  ✔ 基准模型  BIC %.1f | conv %s\n",
              m1$BIC, paste(m1$conv, collapse = ",")))

  ## ---- 对每个 ng 做多起点拟合，取得 BIC 最低的非退化解 --------------------------------------
  best <- list()          # ng -> 该 ng 下最优解
  all_tries <- list()     # 全部尝试记录（写入 trace，供审稿核查）
  for (ng in sort(unique(ngs), decreasing = TRUE)) {
    seeds <- GBTM_SEED + seq_len(nstart) - 1L
    cand <- list()
    for (s in seeds) {
      f <- fit_one(d, ng, seed = s, verbose = verbose, m1 = m1)
      if (is.null(f)) {
        all_tries[[length(all_tries) + 1L]] <- data.frame(
          ng = ng, seed = s, converged = FALSE, class_n = NA_character_,
          max_class_pct = NA_real_, min_class = NA_integer_, entropy = NA_real_,
          BIC = NA_real_, degenerate = NA)
        next
      }
      f$maxp  <- max(f$cnt) / sum(f$cnt)
      f$nnon0 <- sum(f$cnt > 0)
      f$minn  <- min(f$cnt)
      f$seed  <- s
      f$degenerate <- (f$maxp >= GBTM_PMAX_OK) || (f$nnon0 < ng) || (f$minn < GBTM_MIN_N)
      f$deg_why <- paste(c(
        if (f$maxp >= GBTM_PMAX_OK) sprintf("最大类 %.1f%%", 100 * f$maxp),
        if (f$nnon0 < ng)           sprintf("空类 %d/%d", f$nnon0, ng),
        if (f$minn < GBTM_MIN_N)    sprintf("最小类仅 %d 例", f$minn)), collapse = "；")
      cand[[length(cand) + 1L]] <- f
      all_tries[[length(all_tries) + 1L]] <- data.frame(
        ng = ng, seed = s, converged = TRUE,
        class_n = paste(f$cnt, collapse = "/"),
        max_class_pct = round(100 * f$maxp, 2),
        min_class = f$minn, entropy = round(f$ent, 4),
        BIC = round(f$bic, 2), degenerate = f$degenerate)
      if (verbose) cat(sprintf("       ng = %d  seed %-5d %-24s 熵 %.3f  BIC %9.1f%s\n",
                               ng, s, paste(f$cnt, collapse = "/"), f$ent, f$bic,
                               if (f$degenerate) paste0("  ← 退化（", f$deg_why, "），弃用") else ""))
    }
    if (!length(cand)) {
      cat(sprintf("       ng = %d  ✗ 全部 %d 个起点均未收敛\n", ng, length(seeds)))
      next
    }
    ## 非退化解优先；若全部退化，仍保留 BIC 最优者以便后续兜底
    ok <- Filter(function(f) !f$degenerate, cand)
    pool <- if (length(ok)) ok else cand
    b <- pool[[which.min(vapply(pool, `[[`, numeric(1), "bic"))]]
    if (length(ok)) { b$degenerate <- FALSE; b$deg_why <- "" }
    best[[as.character(ng)]] <- b
    cat(sprintf("     → ng = %d 最优：seed %d，占比 %s，熵 %.3f，BIC %.1f%s\n",
                ng, b$seed, paste(b$cnt, collapse = "/"), b$ent, b$bic,
                if (b$degenerate) paste0("  ※全部起点均退化（", b$deg_why, "），仅作兜底") else ""))
  }

  if (!length(best)) { cat(sprintf("  ✗ [%s] 所有 ng 均未收敛\n", v)); return(NULL) }

  ## ---- 向后选择：从最大的 ng 开始，通过判据即采用 -------------------------------------------
  chosen <- NULL
  for (ng in sort(as.integer(names(best)), decreasing = TRUE)) {
    f <- best[[as.character(ng)]]
    deg <- character(0)
    ## ★ v7：degenerate 标记与逐条判据保持一致。原先只打印 maxp/空类/小类三条，
    ##   导致日志出现"占比 273/2237/109 熵 0.810 却标 ← 退化"的自相矛盾。
    if (f$maxp >= GBTM_PMAX_OK) deg <- c(deg, sprintf("最大类 %.1f%%", 100 * f$maxp))
    if (f$nnon0 < ng)           deg <- c(deg, sprintf("空类 %d/%d", f$nnon0, ng))
    if (f$minn < GBTM_MIN_N)    deg <- c(deg, sprintf("最小类仅 %d 例", f$minn))
    ## BIC 增益：多这一类带来的 BIC 绝对降幅（ΔBIC = BIC(K-1) - BIC(K)）
    ## 注意不能用 (|BIC_{K-1}| - |BIC_K|)/|BIC_{K-1}|：本数据肌酐 BIC 为负值，
    ## 取绝对值会颠倒方向，把"BIC 大幅下降"误判成"增益为负"。
    lower <- best[[as.character(ng - 1L)]]
    if (!is.null(lower)) {
      gain <- lower$bic - f$bic                  # 正 = 多一类后 BIC 更低（更好）
      f$bic_gain_abs <- gain
      if (is.na(gain) || gain < GBTM_BIC_GAIN)
        deg <- c(deg, sprintf("ΔBIC 仅 %.1f", gain))
    } else {
      f$bic_gain_abs <- NA_real_
    }
    if (!length(deg)) {
      chosen <- f
      cat(sprintf("  ✔ [%s] 采用 ng = %d（最小类 %d 例，熵 %.3f，BIC %.1f%s）\n",
                  v, ng, f$minn, f$ent, f$bic,
                  if (is.na(f$bic_gain_abs)) "" else sprintf("，ΔBIC vs %d 类 = %.1f",
                                                             ng - 1L, f$bic_gain_abs)))
      break
    }
    cat(sprintf("  ⚠ [%s] ng = %d 判为不稳定：%s → 降为 %d 类重试\n",
                v, ng, paste(deg, collapse = "；"), ng - 1L))
  }
  if (is.null(chosen)) {
    chosen <- best[[which.min(vapply(best, `[[`, numeric(1), "bic"))]]
    cat(sprintf("  ⚠ [%s] 无稳定解，退取 BIC 最优：ng = %d（最小类 %d 例）\n",
                v, chosen$ng, chosen$minn))
  }
  chosen$data <- d
  attr(chosen, "all_fits") <- best
  attr(chosen, "all_tries") <- if (length(all_tries)) do.call(rbind, all_tries) else NULL
  chosen
}

## ---- 2.3 形状命名 + 严重度序数 ---------------------------------------------------------------
## ★ v7 重写 predictY 列对齐：predictY 的内部列顺序与 class 编号**不一致**
##   实测（乳酸 ng=3，predictY 列名为 Ypred_class1/2/3）：
##     Ypred_class1  t0=1.397 t3=2.372（升）   实际 class 1 = 109 例，样本均值 1.63
##     Ypred_class2  t0=0.980 t3=0.888（平低） 实际 class 2 = 2237 例，样本均值 1.00
##     Ypred_class3  t0=1.750 t3=0.944（降）   实际 class 3 = 273 例，样本均值 1.81
##   即 predictY 的第 1 列对应 class 3，第 3 列才对应 class 1 —— 若按列名数字
##   分配 c1/c2/c3，会把"下降型（273 例）"错标成 109 例那一类，严重度序数随之错乱。
##   因此改为【数据驱动】对齐：用每条样本的后验分类算各类实测轨迹，
##   与 predictY 的各列逐一匹配（贪心最近邻），不依赖列名、不依赖位置。
pred_matrix <- function(fit, tgrid = seq(0, 3, length.out = 40)) {
  ng <- fit$ng
  nd <- data.frame(time = tgrid)
  py <- lcmm::predictY(fit$model, newdata = nd, var.time = "time", draws = FALSE)$pred
  pm <- as.data.frame(py)
  if (ncol(pm) != ng) {
    stop(sprintf("predictY 返回 %d 列，但模型 ng = %d；无法可靠识别类别列。列名：%s",
                 ncol(pm), ng, paste(names(pm), collapse = ", ")), call. = FALSE)
  }
  names(pm) <- paste0("col", seq_len(ng))
  cbind(time = tgrid, pm)
}

## 数据驱动对齐：返回 out，out[j] = predictY 第 j 列对应的 class 编号
col_to_class <- function(fit, pm) {
  ng  <- fit$ng
  ppr <- as.data.frame(fit$model$pprob)
  ppr$hadm_id <- as.integer(ppr[[1]])
  ppr$cls     <- as.integer(ppr[["class"]])
  dd  <- fit$data
  if (is.null(dd)) stop("fit$data 缺失，无法做 predictY 列对齐", call. = FALSE)
  dd  <- merge(dd, ppr[, c("hadm_id", "cls")], by = "hadm_id")
  D <- matrix(NA_real_, ng, ng)
  for (j in seq_len(ng)) {
    yj <- approx(pm$time, pm[[paste0("col", j)]], xout = dd$time, rule = 2)$y
    for (k in seq_len(ng)) {
      sel <- dd$cls == k
      D[j, k] <- if (!any(sel)) Inf else mean(abs(yj[sel] - dd$y[sel]))
    }
  }
  out <- integer(ng)
  for (step in seq_len(ng)) {
    ij <- which(D == min(D, na.rm = TRUE), arr.ind = TRUE)[1, ]
    out[ij[1]] <- ij[2]
    D[ij[1], ] <- Inf; D[, ij[2]] <- Inf
  }
  if (anyDuplicated(out) || anyNA(out) || any(out == 0L)) {
    stop(sprintf("predictY 列与 class 编号对齐失败（得到 %s）",
                 paste(out, collapse = ",")), call. = FALSE)
  }
  out
}

## 各类在栅格上的预测曲线（列名统一 c1..c<ng>，且 c1 = class 1）
pred_curves <- function(fit) {
  pm  <- pred_matrix(fit)
  ord <- col_to_class(fit, pm)                  # ord[j] = 第 j 列的 class 编号
  out <- matrix(NA_real_, nrow(pm), fit$ng)
  for (j in seq_along(ord)) out[, ord[j]] <- pm[[paste0("col", j)]]
  colnames(out) <- paste0("c", seq_len(fit$ng))
  data.frame(time = pm$time, out, check.names = FALSE)
}

## ---- 严重度序数：按各类预测均值排序，并强制校验「序数唯一且非退化」----------------
severity_map <- function(fit) {
  pc  <- pred_curves(fit)
  V   <- as.matrix(pc[, -1, drop = FALSE])
  lvl <- colMeans(V)                            # V 的第 k 列 = class k
  if (length(unique(round(lvl, 10))) != length(lvl)) {
    stop(sprintf("各类预测均值存在并列（%s），无法为类别排序严重度。",
                 paste(sprintf("%.4f", lvl), collapse = ", ")), call. = FALSE)
  }
  sev <- as.integer(rank(lvl, ties.method = "first"))   # 1 = 最轻, ng = 最重
  setNames(sev, seq_len(fit$ng))                        # 名字 = class 编号
}

get_post <- function(fit, prefix) {
  pp  <- as.data.frame(fit$model$pprob)
  pp$hadm_id <- as.integer(pp[[1]])
  cls <- as.integer(pp[["class"]])
  if (anyNA(cls)) stop(sprintf("[%s] pprob$class 含 NA", prefix), call. = FALSE)
  map <- name_by_shape(fit, prefix)
  sev <- severity_map(fit)
  ## 校验：每个 class 都能映射到形状名与严重度
  missing_cls <- setdiff(unique(cls), names(sev))
  if (length(missing_cls)) {
    stop(sprintf("[%s] class 取值 %s 不在严重度映射 %s 中",
                 prefix, paste(missing_cls, collapse = ","),
                 paste(names(sev), collapse = ",")), call. = FALSE)
  }
  pp[[paste0(tolower(prefix), "_pheno")]] <- factor(map[as.character(cls)])
  pp[[paste0(tolower(prefix), "_sev")]]   <- as.integer(sev[as.character(cls)])
  ## 校验：序数必须覆盖 1..ng 且每档都有人
  got <- sort(unique(pp[[paste0(tolower(prefix), "_sev")]]))
  if (!identical(got, seq_len(fit$ng))) {
    stop(sprintf("[%s] 严重度序数异常：得到 %s，期望 1..%d", prefix,
                 paste(got, collapse = ","), fit$ng), call. = FALSE)
  }
  pp
}

name_by_shape <- function(fit, prefix = "") {
  pc <- pred_curves(fit)                     # ★ v7：已按 class 编号对齐
  V  <- pc[, -1, drop = FALSE]
  v0 <- unlist(V[1, ]); v1 <- unlist(V[nrow(V), ])
  vm <- apply(V, 2, max); tm <- apply(V, 2, which.max)
  mu <- colMeans(V)
  shape <- character(ncol(V))
  for (j in seq_len(ncol(V))) {
    if (v1[j] > 1.5 * max(v0[j], 1e-9) && tm[j] >= nrow(V) - 3)       shape[j] <- "Rising"
    else if (v0[j] > 1.5 * max(v1[j], 1e-9) && tm[j] <= 3)            shape[j] <- "Declining"
    else if (vm[j] > 1.25 * max(v0[j], v1[j], 1e-9))                  shape[j] <- "Transient elevation"
    else shape[j] <- "flat"
  }
  fl <- which(shape == "flat")
  if (length(fl)) {
    rq <- rank(mu[fl], ties.method = "first")
    lvl <- if (length(fl) == 1) "Persistently low"
           else if (length(fl) == 2) c("Persistently low", "Persistently mid")
           else if (length(fl) == 3) c("Persistently low", "Persistently mid", "Persistently high")
           else paste0("Persistent level ", seq_along(fl))
    shape[fl] <- lvl[rq]
  }
  setNames(shape, sub("^c", "", colnames(V)))
}

## ---- 2.4 执行 -------------------------------------------------------------------------------
cat("\n  拟合乳酸轨迹 ...\n");  tL <- Sys.time(); GL <- fit_gbtm("lactate")
cat(sprintf("    用时 %.1f 分钟\n", as.numeric(difftime(Sys.time(), tL, units = "mins"))))
cat("\n  拟合肌酐轨迹 ...\n");  tC <- Sys.time(); GC <- fit_gbtm("creatinine")
cat(sprintf("    用时 %.1f 分钟\n", as.numeric(difftime(Sys.time(), tC, units = "mins"))))

if (is.null(GL) || is.null(GC)) {
  stop(paste0("\n■■■ GBTM 拟合失败 ■■■\n",
              "  若两个变量均报「全部 ng 未收敛」，请把上面的拟合日志发回排查。\n"), call. = FALSE)
}

## =============================================================================================
## [3] 阶段 3：联合表型 + 写文件 + 自检
## =============================================================================================
hdr("阶段 3  生成 phenotype_assignment.csv")

PL <- get_post(GL, "L"); PC <- get_post(GC, "C")

## ★ v5：联合表型 3 档 —— 沿用原等宽切法先得 4 档 brks，再将最高两档并为一档
##   P1 / P2 与原分析完全一致；P3 = 原分析的 P3 ∪ P4（最高严重度）
##   好处：三表型与既往全部结果连续，无需重新解释表型含义
PH0 <- PL %>% select(hadm_id, lac_lab = l_pheno, l_sev) %>%
  inner_join(PC %>% select(hadm_id, cr_lab = c_pheno, c_sev), by = "hadm_id") %>%
  mutate(score = l_sev + c_sev)
score_max <- max(PH0$score)
brks <- round(c(1/4, 2/4, 3/4) * (score_max + 1) + 0.5)     # 原 4 档等宽切点
## ★ v8：三档改为平级形容词 low / intermediate / high（原 lowest 为最高级，
##        与中间档 intermediate、高档 high 不在同一语法层级，读起来不对称）
PHENO_LAB <- c("Phenotype 1 (low)", "Phenotype 2 (intermediate)", "Phenotype 3 (high)")

PH <- PH0 %>%
  mutate(pheno = case_when(score <= brks[1] ~ "1",
                           score <= brks[2] ~ "2",
                           TRUE             ~ "3"),
         label = factor(PHENO_LAB[as.integer(pheno)], levels = PHENO_LAB)) %>%
  select(hadm_id, lac_lab, cr_lab, score, pheno, label) %>%
  arrange(hadm_id)
cat(sprintf("  联合表型分箱：score ≤ %d → P1；%d–%d → P2；≥ %d → P3（原 3、4 档合并）\n",
            brks[1], brks[1] + 1, brks[2], brks[2] + 1))
cat(sprintf("  score 取值范围：%d–%d；分箱切点：%s\n",
            min(PH0$score), max(PH0$score), paste(brks, collapse = ", ")))

## ★ v6 硬校验：分箱后三档必须都非空，且不能高度失衡。不合格则不写文件、直接停止。
.d_pre <- as.integer(table(factor(PH$pheno, 1:3)))
if (any(.d_pre == 0)) {
  stop(sprintf(paste0(
    "\n■■■ 联合表型分箱失败：某一档为 0 例 ■■■\n",
    "  乳酸严重度序数取值：%s\n  肌酐严重度序数取值：%s\n",
    "  score 取值范围：%d–%d，切点 %s\n",
    "  分箱结果：P1=%d / P2=%d / P3=%d\n",
    "  这通常意味着某个变量的类排序退化（各类预测均值过于接近）。\n",
    "  建议：调大 GBTM_MIN_N 或改用 GBTM_NGS <- c(2) 单一类数重试。\n"),
    paste(sort(unique(PL$l_sev)), collapse = ","),
    paste(sort(unique(PC$c_sev)), collapse = ","),
    min(PH0$score), max(PH0$score), paste(brks, collapse = ","),
    .d_pre[1], .d_pre[2], .d_pre[3]), call. = FALSE)
}

readr::write_excel_csv(PH, PHENO_OUT, na = "")

dist <- as.integer(table(factor(PH$pheno, 1:3)))
SUMMARY_N <- nrow(PH)
SUMMARY_DIST <- paste(sprintf("P%d=%d (%.1f%%)", 1:3, dist, 100 * dist / sum(dist)), collapse = " / ")

cat(sprintf("\n  ✔ 已写出：%s\n  行数：%d\n  分布：%s\n", PHENO_OUT, nrow(PH), SUMMARY_DIST))

n_traj <- sum(M$in_traj_set == 1, na.rm = TRUE)
cat(sprintf("  覆盖率：%d / %d 轨迹集例（%.1f%%）\n",
            nrow(PH), n_traj, 100 * nrow(PH) / n_traj))
if (nrow(PH) < 0.95 * n_traj) {
  warning(sprintf(paste0(
    "\n  ⚠ 表型覆盖率仅 %.1f%%（%d / %d），低于 95%%。\n",
    "    根因：GBTM 要求每个变量 ≥2 个观测点，部分病例乳酸/肌酐只有 1 次。\n",
    "    本队列轨迹集中有 %d 例乳酸仅 1 次、%d 例肌酐仅 1 次。\n",
    "    → 正文与 Table 3 的 n 需按实际分析集报告。\n"),
    100 * nrow(PH) / n_traj, nrow(PH), n_traj,
    sum(rowSums(!is.na(M[M$in_traj_set == 1, LAC_COLS])) == 1),
    sum(rowSums(!is.na(M[M$in_traj_set == 1, CR_COLS]))  == 1)), call. = FALSE)
}

SHAPE_SUM <- list(
  lactate    = as.data.frame(table(PL$l_pheno)),
  creatinine = as.data.frame(table(PC$c_pheno)),
  model_fit  = data.frame(
    variable = c("lactate", "creatinine"),
    ng       = c(GL$ng, GC$ng),
    class_n  = c(paste(GL$cnt, collapse = "/"), paste(GC$cnt, collapse = "/")),
    min_class= c(min(GL$cnt), min(GC$cnt)),
    entropy  = c(round(GL$ent, 3), round(GC$ent, 3)),
    BIC      = c(round(GL$bic, 1), round(GC$bic, 1)),
    AIC      = c(round(GL$aic, 1), round(GC$aic, 1)),
    conv     = c(GL$conv, GC$conv),
    selection_rule = c(
      sprintf("max_class<%.0f%%; min_class>=%d; dBIC>=%g", 100*GBTM_PMAX_OK, GBTM_MIN_N, GBTM_BIC_GAIN),
      sprintf("max_class<%.0f%%; min_class>=%d; dBIC>=%g", 100*GBTM_PMAX_OK, GBTM_MIN_N, GBTM_BIC_GAIN))
  )
)
dir.create(file.path(OUT_ABS, "trace"), recursive = TRUE, showWarnings = FALSE)
for (nm in names(SHAPE_SUM)) {
  readr::write_excel_csv(SHAPE_SUM[[nm]], file.path(OUT_ABS, "trace", paste0("gbtm_", nm, ".csv")), na = "")
}
## ★ v7：全部多起点尝试记录（审稿核查模型选择过程用）
TR <- rbind(
  if (!is.null(attr(GL, "all_tries"))) transform(attr(GL, "all_tries"), variable = "lactate") else NULL,
  if (!is.null(attr(GC, "all_tries"))) transform(attr(GC, "all_tries"), variable = "creatinine") else NULL
)
if (!is.null(TR)) {
  TR <- TR[, c("variable", "ng", "seed", "converged", "class_n",
               "max_class_pct", "min_class", "entropy", "BIC", "degenerate")]
  readr::write_excel_csv(TR, file.path(OUT_ABS, "trace", "gbtm_search_log.csv"), na = "")
  cat(sprintf("  ✔ 多起点搜索日志：%d 次尝试（%s 个退化解已标记）\n",
              nrow(TR), sum(TR$degenerate)))
}
cat("  ✔ GBTM 拟合摘要已写入 trace/\n")

}  # end STAGE gbtm

## =============================================================================================
## [4] 阶段 4：出全部表图
## =============================================================================================
if (STAGE %in% c("all", "plot")) {

hdr("阶段 4  生成全部表格与图件")

if (!file.exists(PHENO_OUT)) {
  stop(sprintf(paste0(
    "\n■■■ 找不到表型文件 ■■■\n  期望：%s\n",
    "  请先执行：Rscript 00_RUN_ALL.R --stage=gbtm\n"), PHENO_OUT), call. = FALSE)
}

S20 <- file.path(SCRIPT_DIR, "20_manuscript_tables_figures.R")
if (!file.exists(S20)) S20 <- file.path(DATA_DIR, "20_manuscript_tables_figures.R")
if (!file.exists(S20)) {
  stop(sprintf(paste0(
    "\n■■■ 找不到 20_manuscript_tables_figures.R ■■■\n",
    "  已尝试：%s\n          %s\n"), 
    file.path(SCRIPT_DIR, "20_manuscript_tables_figures.R"),
    file.path(DATA_DIR, "20_manuscript_tables_figures.R")), call. = FALSE)
}
cat(sprintf("  调用：%s\n\n", S20))

## ★ 用独立子进程：20 号脚本开头有 rm(list = ls())，同会话 source 会清空本脚本对象
RSCRIPT_BIN <- file.path(R.home("bin"), if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript")
STATUS <- tryCatch({
  system2(RSCRIPT_BIN, shQuote(S20), stdout = "", stderr = "")
}, error = function(e) { cat("  子进程启动失败：", conditionMessage(e), "\n"); 1L })

if (!identical(as.integer(STATUS), 0L)) {
  cat("\n  ⚠ 20 号脚本返回非零状态，请检查其日志。\n")
} else {
  ## 表型文件就绪后跑 RRT 口径敏感性
  S21 <- file.path(dirname(S20), "21_rrt_sensitivity.R")
  if (file.exists(S21)) {
    cat(sprintf("  调用：%s\n\n", S21))
    system2(RSCRIPT_BIN, shQuote(S21), stdout = "", stderr = "")
  }
}

}  # end STAGE plot

## =============================================================================================
## [5] 汇总
## =============================================================================================
hdr("完成")
cat(sprintf("总用时：%.1f 分钟\n", as.numeric(difftime(Sys.time(), T_START, units = "mins"))))
cat(sprintf("输出目录：%s\n", OUT_ABS))
if (dir.exists(file.path(OUT_ABS, "figures"))) {
  cat(sprintf("  figures %d 个 | tables %d 个 | trace %d 个\n",
              length(list.files(file.path(OUT_ABS, "figures"))),
              length(list.files(file.path(OUT_ABS, "tables"))),
              length(list.files(file.path(OUT_ABS, "trace")))))
}
if (exists("SUMMARY_DIST")) {
  cat(sprintf("\n表型分布：%s\n", SUMMARY_DIST))
  cat(sprintf("主分析口径：三表型（P1 = %d / P2 = %d / P3 = %d）\n",
              dist[1], dist[2], dist[3]))
}
cat(paste0(
  "\n请依次确认：\n",
  "  · figures/Fig01_cohort_flow.png  —— 表型框应显示实际分配例数与 P1–P3 分布\n",
  "  · tables/Table3_multivariable.csv —— 仅三表型口径（P1 / P2 / P3）\n",
  "  · tables/Table1_by_phenotype.csv  —— 仅 P1 / P2 / P3 三列\n",
  "  · trace/key_numbers.txt           —— PRIMARY / SENSITIVITY 两组 HR 均已记录\n"))
