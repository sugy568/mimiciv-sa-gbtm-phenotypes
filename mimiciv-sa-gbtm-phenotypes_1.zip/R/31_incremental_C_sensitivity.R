## ============================================================
## 增量 C 统计量：敏感性分析（比较基准的选择是否改变结论）
## S1 单点标志物改用 24 h 峰值；S2 仅用单点乳酸；S3 分类 NRI；S4 直接 M3 vs M1
## ============================================================
suppressPackageStartupMessages({library(pROC)})
set.seed(20261111)

d  <- read.csv("/root/uploads/1792063918821056536-SA_MASTER.csv", fileEncoding = "UTF-8-BOM")
ph <- read.csv("/workspace/phenotype_assignment.csv", fileEncoding = "UTF-8-BOM")
m  <- merge(d, ph[, c("hadm_id", "pheno")], by = "hadm_id")

first_avail <- function(df, cols) apply(df[, cols, drop = FALSE], 1,
  function(x) { x <- x[!is.na(x)]; if (length(x)) x[1] else NA })
m$lac_first <- first_avail(m, c("lac_0h", "lac_6h", "lac_12h", "lac_24h"))
m$cr_first  <- first_avail(m, c("cr_0h", "cr_6h", "cr_12h", "cr_24h"))

m$y <- as.integer(m$death_28d); m$male <- as.integer(m$gender == "M")
m$mr <- factor(m$mrsa_status, levels = c("MSSA", "MRSA", "unknown"))
m$ph <- factor(m$pheno, levels = 1:3)
m$log_lac  <- log(pmax(m$lac_first, 0.1)); m$log_cr <- log(pmax(m$cr_first, 0.1))
m$log_lacM <- log(pmax(m$lactate_max, 0.1)); m$log_crM <- log(pmax(m$cr_max, 0.1))

base_r <- "y ~ age + male + charlson + sofa_24h + mr + is_bsi"
fit <- function(f, dat) glm(as.formula(f), data = dat, family = binomial)

run <- function(dat, vars, extra, tag) {
  cc <- dat[complete.cases(dat[, vars]), ]
  M1 <- fit(base_r, cc); M2 <- fit(paste(base_r, extra), cc); M3 <- fit(paste(base_r, extra, "+ ph"), cc)
  cc$p1 <- fitted(M1); cc$p2 <- fitted(M2); cc$p3 <- fitted(M3)
  r1 <- roc(cc$y, cc$p1, quiet = TRUE); r2 <- roc(cc$y, cc$p2, quiet = TRUE); r3 <- roc(cc$y, cc$p3, quiet = TRUE)
  ## 分类 NRI（<5% / 5-20% / >20%）
  cat3 <- function(p) cut(p, c(-Inf, .05, .20, Inf), labels = FALSE)
  up_ev <- mean(cat3(cc$p3)[cc$y == 1] > cat3(cc$p2)[cc$y == 1])
  dn_ev <- mean(cat3(cc$p3)[cc$y == 1] < cat3(cc$p2)[cc$y == 1])
  up_ne <- mean(cat3(cc$p3)[cc$y == 0] > cat3(cc$p2)[cc$y == 0])
  dn_ne <- mean(cat3(cc$p3)[cc$y == 0] < cat3(cc$p2)[cc$y == 0])
  nri_cat <- (up_ev - dn_ev) + (dn_ne - up_ne)
  data.frame(情景 = tag, n = nrow(cc), 死亡 = sum(cc$y),
             AUC_M1 = round(as.numeric(auc(r1)), 4),
             AUC_M2 = round(as.numeric(auc(r2)), 4),
             AUC_M3 = round(as.numeric(auc(r3)), 4),
             dC_M3_M2 = round(as.numeric(auc(r3) - auc(r2)), 4),
             P = signif(roc.test(r3, r2, method = "delong")$p.value, 3),
             dC_M3_M1 = round(as.numeric(auc(r3) - auc(r1)), 4),
             NRI_cat = round(nri_cat, 3))
}

res <- rbind(
  run(m, c("y","age","male","charlson","sofa_24h","mr","is_bsi","log_lac","log_cr","ph"),
      "+ log_lac + log_cr", "主分析：首个值（0–24 h）"),
  run(m, c("y","age","male","charlson","sofa_24h","mr","is_bsi","log_lacM","log_crM","ph"),
      "+ log_lacM + log_crM", "S1：24 h 峰值"),
  run(m, c("y","age","male","charlson","sofa_24h","mr","is_bsi","log_lac","ph"),
      "+ log_lac", "S2：仅单点乳酸"),
  run(m, c("y","age","male","charlson","sofa_24h","mr","is_bsi","ph"),
      "", "S3：不加单点标志物（M3 vs M1）")
)
print(res, row.names = FALSE)

## 各表型的 28 天死亡绝对风险
ag <- aggregate(cbind(deaths = m$y, n = rep(1, nrow(m))), by = list(表型 = m$pheno), sum)
ag$风险 <- sprintf("%.1f%%", 100 * ag$deaths / ag$n)
print(ag)

write.csv(res, "/workspace/incremental_C_sensitivity.csv", row.names = FALSE)
saveRDS(list(sens = res, absrisk = ag), "/workspace/incremental_C_sensitivity.rds")
