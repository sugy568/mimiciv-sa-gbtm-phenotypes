# R 包安装脚本(MIMIC 金葡菌 GBTM 研究)
# 首次运行前执行一次。建议用 renv 锁定版本。
# 国内用户:使用清华 CRAN 镜像加速

options(repos = c(CRAN = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/"))

pkgs <- c(
  # 数据处理
  "data.table", "dplyr", "tidyr", "stringr", "lubridate",
  # 轨迹建模
  "lcmm",          # 潜在类别混合模型(GBTM 现代实现,主用)
  "flexmix",       # 备选
  "kml",           # 可选:纵向 k-means 轨迹
  "lme4",          # 混合模型基础
  # 生存分析
  "survival",      # Cox
  "cmprsk",        # 竞争风险
  "riskRegression",# Fine-Gray / CIF
  "survminer",     # KM 图
  # 模型评估 / 可视化
  "rms", "ggplot2", "patchwork", "viridis",
  # 表格输出(可选 Word)
  "officer", "flextable",
  # 可复现
  "renv"
)

install_if_missing <- function(p) {
  if (!requireNamespace(p, quietly = TRUE)) {
    message("Installing: ", p)
    install.packages(p)
  }
}

invisible(lapply(pkgs, install_if_missing))

# 验证
cat("\n=== 已安装包版本 ===\n")
for (p in pkgs) {
  v <- tryCatch(as.character(packageVersion(p)), error = function(e) NA)
  cat(sprintf("%-18s %s\n", p, ifelse(is.na(v), "未安装", v)))
}

cat("\n=== 完成。请运行 02_gbtm_analysis_skeleton.R ===\n")
