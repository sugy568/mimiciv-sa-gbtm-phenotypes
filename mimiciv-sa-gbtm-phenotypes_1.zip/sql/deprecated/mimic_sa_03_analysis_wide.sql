-- =====================================================================
-- MIMIC-IV：金葡菌感染 × 抗金葡菌用药 —— 分析宽表
-- 输出两个层次的表：
--   C1  hadm 级宽表（一行一次住院，含首株菌状态 + 用药汇总）
--   C2  isolate 级 × 用药明细长表（供逐株菌分析用药是否恰当）
-- =====================================================================

-- ---------------------------------------------------------------------
-- C1：hadm 级分析宽表
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS work.sa_analysis_wide CASCADE;

CREATE TABLE work.sa_analysis_wide AS
WITH iso AS (
  SELECT * FROM work.sa_isolate_first_per_hadm
),
abx AS (
  SELECT
    hadm_id,
    COUNT(*)                                             AS abx_order_cnt,
    COUNT(DISTINCT drug_name)                            AS abx_drug_cnt,
    MIN(start_time)                                      AS first_abx_time,
    MAX(end_time)                                        AS last_abx_time,
    -- 感染后（含 ±24h 经验性）用药开始时间
    MIN(CASE WHEN start_time >= iso_time - INTERVAL '24 hour'
             THEN start_time END)                        AS first_abx_after_infection,
    -- 是否用过覆盖 MRSA 的药
    MAX(CASE WHEN spectrum LIKE '%MRSA%' THEN 1 ELSE 0 END) AS any_mrsa_covering,
    -- 是否用过仅覆盖 MSSA 的 β-内酰胺
    MAX(CASE WHEN spectrum = 'MSSA' AND drug_group LIKE '%penicillin%'
             THEN 1 ELSE 0 END)                          AS any_mssa_betalactam,
    -- 具体药物是否使用（布尔）
    MAX(CASE WHEN drug_name ILIKE '%vancomycin%'  THEN 1 ELSE 0 END) AS used_vancomycin,
    MAX(CASE WHEN drug_name ILIKE '%linezolid%'   THEN 1 ELSE 0 END) AS used_linezolid,
    MAX(CASE WHEN drug_name ILIKE '%daptomycin%'  THEN 1 ELSE 0 END) AS used_daptomycin,
    MAX(CASE WHEN drug_name ILIKE '%cefazolin%'   THEN 1 ELSE 0 END) AS used_cefazolin,
    MAX(CASE WHEN drug_name ILIKE '%oxacillin%'   THEN 1 ELSE 0 END) AS used_oxacillin,
    MAX(CASE WHEN drug_name ILIKE '%nafcillin%'   THEN 1 ELSE 0 END) AS used_nafcillin,
    MAX(CASE WHEN drug_name ILIKE '%clindamycin%' THEN 1 ELSE 0 END) AS used_clindamycin,
    MAX(CASE WHEN drug_name ILIKE '%ceftaroline%' THEN 1 ELSE 0 END) AS used_ceftaroline,
    MAX(CASE WHEN drug_name ILIKE '%trimethoprim%' OR drug_name ILIKE '%sulfamethoxazole%'
             THEN 1 ELSE 0 END)                          AS used_tmp_smx,
    MAX(CASE WHEN drug_name ILIKE '%rifampin%' OR drug_name ILIKE '%rifampicin%'
             THEN 1 ELSE 0 END)                          AS used_rifampin,
    MAX(CASE WHEN drug_name ILIKE '%tigecycline%' THEN 1 ELSE 0 END) AS used_tigecycline
  FROM (
    SELECT a.*, i.sa_infection_time AS iso_time
    FROM work.sa_antibiotic_all a
    LEFT JOIN iso i ON i.hadm_id = a.hadm_id
  ) t
  GROUP BY hadm_id
)
SELECT
  i.subject_id,
  i.hadm_id,
  i.micro_specimen_id,
  i.sa_infection_time,
  i.specimen_type,                    -- 金葡菌标本类型
  i.mrsa_status,                      -- MRSA / MSSA / unknown
  i.sa_suscept_tested,
  i.oxacillin_resistant,
  i.suscept_detail,                   -- 完整药敏明细字符串
  i.isolate_cnt,                      -- 该次住院金葡菌检出次数
  i.mixed_infection,                  -- 是否 MRSA+MSSA 混合
  a.abx_order_cnt,
  a.abx_drug_cnt,
  a.first_abx_time,
  a.last_abx_time,
  a.first_abx_after_infection,
  a.any_mrsa_covering,
  a.any_mssa_betalactam,
  a.used_vancomycin, a.used_linezolid, a.used_daptomycin,
  a.used_cefazolin,  a.used_oxacillin, a.used_nafcillin,
  a.used_clindamycin, a.used_ceftaroline, a.used_tmp_smx,
  a.used_rifampin,   a.used_tigecycline,
  -- 从标本采集到首次用药的间隔（小时）
  EXTRACT(EPOCH FROM (a.first_abx_after_infection - i.sa_infection_time))/3600.0
    AS hours_to_first_abx
FROM iso i
LEFT JOIN abx a ON a.hadm_id = i.hadm_id;


-- ---------------------------------------------------------------------
-- C2：isolate 级 × 用药明细（逐株菌看用药是否覆盖）
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS work.sa_isolate_abx_detail CASCADE;

CREATE TABLE work.sa_isolate_abx_detail AS
SELECT
  iso.subject_id,
  iso.hadm_id,
  iso.micro_specimen_id,
  iso.sa_infection_time,
  iso.specimen_type,
  iso.mrsa_status,
  iso.suscept_detail,
  abx.source,
  abx.drug_name,
  abx.drug_group,
  abx.spectrum,
  abx.dose_num,
  abx.dose_unit,
  abx.route,
  abx.start_time,
  abx.end_time,
  -- 相对时间：用药开始相对于感染检出时间（负=感染前）
  EXTRACT(EPOCH FROM (abx.start_time - iso.sa_infection_time))/3600.0
    AS abx_start_hrs_from_infection,
  -- 用药是否覆盖该株菌（MRSA 株需 MRSA 覆盖药；MSSA 株覆盖药也算）
  CASE
    WHEN iso.mrsa_status = 'MRSA' AND abx.spectrum LIKE '%MRSA%' THEN 'appropriate'
    WHEN iso.mrsa_status = 'MSSA' AND abx.spectrum LIKE '%MSSA%' THEN 'appropriate'
    WHEN iso.mrsa_status = 'unknown' THEN 'unknown'
    ELSE 'not_covering'
  END AS coverage_assessment
FROM work.sa_isolate iso           -- 这里用【全部 isolate】而非首株，保留全部
LEFT JOIN work.sa_antibiotic_all abx
  ON abx.hadm_id = iso.hadm_id
 AND abx.start_time BETWEEN iso.sa_infection_time - INTERVAL '7 day'
                        AND iso.sa_infection_time + INTERVAL '30 day';

CREATE INDEX IF NOT EXISTS idx_sa_detail_hadm ON work.sa_isolate_abx_detail(hadm_id);


-- ---------------------------------------------------------------------
-- 验收查询：把结果直接看一下
-- ---------------------------------------------------------------------
-- 1) 每个 hadm 的菌状态 + 用了几种药
SELECT mrsa_status, COUNT(*) AS n_hadm,
       ROUND(AVG(abx_drug_cnt),2) AS avg_drug_types,
       SUM(any_mrsa_covering) AS n_used_mrsa_drug
FROM work.sa_analysis_wide
GROUP BY 1 ORDER BY 2 DESC;

-- 2) 药敏结果明细（前 20 条）
SELECT hadm_id, mrsa_status, specimen_type, suscept_detail, sa_infection_time
FROM work.sa_analysis_wide
WHERE mrsa_status <> 'unknown'
LIMIT 20;

-- 3) 用药明细（含剂量），前 20 条
SELECT hadm_id, mrsa_status, drug_name, dose_num, dose_unit, route,
       start_time, abx_start_hrs_from_infection, coverage_assessment
FROM work.sa_isolate_abx_detail
WHERE drug_name IS NOT NULL
ORDER BY hadm_id, start_time
LIMIT 20;
