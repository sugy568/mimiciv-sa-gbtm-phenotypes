-- =====================================================================
-- MIMIC-IV：金葡菌（S. aureus）感染事件 + 药敏 + MRSA/MSSA 判定
-- 修正说明：
--   1) 药敏按 micro_specimen_id 逐标本判定，不再跨 hadm 聚合
--   2) 药敏行通过 micro_specimen_id 关联到鉴定行的 org_name
--   3) 苯唑西林类药敏扩展匹配（Oxacillin/Cefoxitin/Nafcillin/Methicillin）
--   4) 保留每株菌（isolate）粒度，避免混合感染被压平
--   5) 区分 mrsa_status（per-isolate）与实际用药（分开两张表）
-- 依赖：work.keyan_rrsfil_mimic_subject (subject_id, hadm_id, stay_id)
-- 目标库：PostgreSQL（physionet-data BigQuery 版需把表名前缀改为
--        `physionet-data.mimiciv_hosp.microbiologyevents` 即可）
-- =====================================================================

DROP TABLE IF EXISTS work.sa_isolate CASCADE;

CREATE TABLE work.sa_isolate AS
WITH
-- ① 所有含金葡菌的微生物检验行（鉴定行，org_name 非空）
sa_rows AS (
  SELECT
    m.microevent_id,
    m.subject_id,
    m.hadm_id,
    m.micro_specimen_id,
    m.charttime                     AS event_charttime,
    m.chartdate                     AS event_chartdate,
    m.spec_type_desc,                          -- 标本类型（血/痰/尿…）
    m.org_name,
    m.ab_name,
    m.interpretation,
    m.dilution_text,
    m.dilution_comparison,
    m.dilution_value
  FROM mimiciv_hosp.microbiologyevents m
  WHERE m.(org_name ILIKE '%STAPH AUREUS%' OR org_name ILIKE '%S. AUREUS%' OR org_name ILIKE '%STAPHYLOCOCCUS AUREUS%')
),

-- ② 提取「鉴定行」：即带菌名、无药名的行，构成一株 isolate
--    以 micro_specimen_id 为 isolate 主键（MIMIC-IV 中一个标本一次培养）
isolate AS (
  SELECT
    micro_specimen_id,
    subject_id,
    hadm_id,
    MIN(event_charttime)            AS sa_first_charttime,  -- 该标本首次检出时间
    MIN(event_chartdate)            AS sa_first_chartdate,
    MODE() WITHIN GROUP (ORDER BY spec_type_desc) AS main_specimen,
    MODE() WITHIN GROUP (ORDER BY org_name)       AS org_name
  FROM sa_rows
  WHERE org_name IS NOT NULL
  GROUP BY micro_specimen_id, subject_id, hadm_id
),

-- ③ 药敏行：有 ab_name 的行，按 micro_specimen_id 归到同一株菌
--    注意：药敏行的 org_name 可能为空，因此【不能】再用 org_name 筛选
suscept AS (
  SELECT
    m.micro_specimen_id,
    -- 是否做过苯唑西林类（含 Methicillin，部分版本用此名）
    MAX(CASE WHEN m.ab_name ILIKE ANY (ARRAY[
              '%oxacillin%','%cefoxitin%','%nafcillin%','%methicillin%'])
             THEN 1 ELSE 0 END) AS tested_oxacillin_class,
    -- 耐药标志：任一类药判 R（含 'R'、'Resistant'）
    MAX(CASE WHEN m.ab_name ILIKE ANY (ARRAY[
              '%oxacillin%','%cefoxitin%','%nafcillin%','%methicillin%'])
             AND UPPER(TRIM(m.interpretation)) LIKE 'R%'
             THEN 1 ELSE 0 END) AS oxacillin_resistant,
    -- 保留该株菌所有药敏明细（供后续展开为长表）
    STRING_AGG(
      m.ab_name || ':' || COALESCE(TRIM(m.interpretation),'NA'),
      '; ' ORDER BY m.ab_name
    ) AS suscept_detail
  FROM mimiciv_hosp.microbiologyevents m
  WHERE m.ab_name IS NOT NULL
    AND m.micro_specimen_id IN (SELECT micro_specimen_id FROM isolate)
  GROUP BY m.micro_specimen_id
)

SELECT
  i.micro_specimen_id,
  i.subject_id,
  i.hadm_id,
  i.sa_first_charttime            AS sa_infection_time,   -- 确诊/检出时间
  i.sa_first_chartdate,
  i.main_specimen                                          AS specimen_type,
  i.org_name,
  COALESCE(su.tested_oxacillin_class, 0)                   AS sa_suscept_tested,
  COALESCE(su.oxacillin_resistant, 0)                      AS oxacillin_resistant,
  su.suscept_detail,
  CASE
    WHEN COALESCE(su.tested_oxacillin_class,0) = 0 THEN 'unknown'
    WHEN su.oxacillin_resistant = 1                THEN 'MRSA'
    ELSE 'MSSA'
  END                                                      AS mrsa_status
FROM isolate i
LEFT JOIN suscept su
  ON su.micro_specimen_id = i.micro_specimen_id;

CREATE INDEX IF NOT EXISTS idx_sa_isolate_hadm ON work.sa_isolate(hadm_id);
CREATE INDEX IF NOT EXISTS idx_sa_isolate_subj ON work.sa_isolate(subject_id);


-- =====================================================================
-- 视图 A：每 hadm 汇总首株菌（若一次住院多株菌，取【首次检出】那株）
-- 用途：需要 hadm 级唯一记录时用，但已标注 mixed_infection 提示
-- =====================================================================
DROP VIEW IF EXISTS work.sa_isolate_first_per_hadm CASCADE;

CREATE VIEW work.sa_isolate_first_per_hadm AS
WITH ranked AS (
  SELECT
    s.*,
    ROW_NUMBER() OVER (
      PARTITION BY s.hadm_id
      ORDER BY s.sa_infection_time NULLS LAST, s.micro_specimen_id
    ) AS rn,
    COUNT(DISTINCT s.mrsa_status) OVER (PARTITION BY s.hadm_id) AS status_variants,
    COUNT(DISTINCT s.micro_specimen_id) OVER (PARTITION BY s.hadm_id) AS isolate_cnt
  FROM work.sa_isolate s
)
SELECT
  subject_id,
  hadm_id,
  micro_specimen_id,
  sa_infection_time,
  sa_first_chartdate,
  specimen_type,
  org_name,
  sa_suscept_tested,
  oxacillin_resistant,
  suscept_detail,
  mrsa_status,
  isolate_cnt,
  (status_variants > 1) AS mixed_infection   -- TRUE=同次住院既有 MRSA 又有 MSSA
FROM ranked
WHERE rn = 1;
