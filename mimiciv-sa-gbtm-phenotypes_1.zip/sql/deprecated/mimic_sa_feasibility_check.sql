-- =====================================================================================
-- MIMIC-IV 可行性核查(Feasibility Check)—— 金葡菌脓毒症 / 感染 队列规模与轨迹建模可行性
-- 环境:PostgreSQL,MIMIC-IV (mimiciv_hosp / mimiciv_icu)
-- 目的:在动手做 GBTM 表型研究之前,先量化三件事:
--       ① 队列有多少例?MRSA/MSSA 各多少?
--       ② 0–72h 各关键变量的测量密度够不够做轨迹模型?
--       ③ 不同定义(A 感染 / B BSI / C 脓毒症)各剩多少?
--
-- ★ 建议:依次执行 CHECK 1 → 8,把每段结果记下来,对照文末的「判定阈值」表做决定。
-- =====================================================================================


-- =====================================================================================
-- CHECK 0  全库基线:金葡菌检出的总盘子(先知道最大可能队列有多大)
-- =====================================================================================
-- 判定: 这是上限。若这里都 <500,后面所有收缩都会很危险。
SELECT
  COUNT(DISTINCT micro_specimen_id)                       AS sa_specimen_cnt,
  COUNT(DISTINCT hadm_id)                                 AS sa_hadm_cnt,
  COUNT(DISTINCT subject_id)                              AS sa_subject_cnt
FROM mimiciv_hosp.microbiologyevents
WHERE org_name ILIKE '%staphylococcus aureus%';


-- 按标本类型分布(S. aureus 来自哪里)
SELECT
  spec_type_desc,
  COUNT(DISTINCT micro_specimen_id) AS n_specimen,
  COUNT(DISTINCT hadm_id)           AS n_hadm
FROM mimiciv_hosp.microbiologyevents
WHERE org_name ILIKE '%staphylococcus aureus%'
GROUP BY 1
ORDER BY 2 DESC;


-- =====================================================================================
-- CHECK 1  药敏/菌种确认:MRSA vs MSSA 能否分得开(决定你的核心分组变量是否可用)
-- =====================================================================================
-- 苯唑西林类药敏的检验项 ab_name 实际取哪些值(关键!防止漏判)
SELECT
  m.ab_name,
  m.interpretation,
  COUNT(*) AS n
FROM mimiciv_hosp.microbiologyevents m
WHERE m.micro_specimen_id IN (
        SELECT DISTINCT micro_specimen_id
        FROM mimiciv_hosp.microbiologyevents
        WHERE org_name ILIKE '%staphylococcus aureus%'
      )
  AND m.ab_name IS NOT NULL
GROUP BY 1,2
ORDER BY 3 DESC
LIMIT 60;


-- MRSA / MSSA / 未测 的分布(per isolate)
WITH sa_spec AS (
  SELECT DISTINCT micro_specimen_id, hadm_id
  FROM mimiciv_hosp.microbiologyevents
  WHERE org_name ILIKE '%staphylococcus aureus%'
),
su AS (
  SELECT
    m.micro_specimen_id,
    MAX(CASE WHEN lower(m.ab_name) ~ 'oxacillin|cefoxitin|nafcillin|methicillin'
             THEN 1 ELSE 0 END) AS tested,
    MAX(CASE WHEN lower(m.ab_name) ~ 'oxacillin|cefoxitin|nafcillin|methicillin'
              AND upper(btrim(m.interpretation)) LIKE 'R%'
             THEN 1 ELSE 0 END) AS resistant
  FROM mimiciv_hosp.microbiologyevents m
  WHERE m.ab_name IS NOT NULL
  GROUP BY 1
)
SELECT
  CASE
    WHEN COALESCE(su.tested,0) = 0 THEN 'unknown'
    WHEN su.resistant = 1          THEN 'MRSA'
    ELSE 'MSSA'
  END                       AS mrsa_status,
  COUNT(*)                  AS n_isolate,
  COUNT(DISTINCT sa_spec.hadm_id) AS n_hadm
FROM sa_spec
LEFT JOIN su ON su.micro_specimen_id = sa_spec.micro_specimen_id
GROUP BY 1
ORDER BY 2 DESC;


-- =====================================================================================
-- CHECK 2  三个队列定义的规模对比(A 感染 / B BSI / C 脓毒症)
-- =====================================================================================
-- Sepsis-3 简化实现:mimiciv_derived 若有 suspicions_of_infection/sofa 用现成的;
-- 此处用【SOFA>=2 且 疑似感染(抗生素+培养)】的通用代理实现(不依赖派生表,但偏保守)
--
-- 先看是否有官方派生表(有就优先用,更规范):
SELECT table_schema, table_name
FROM information_schema.tables
WHERE table_name IN ('sofa','suspicion_of_infection','sepsis3','first_day_sofa')
ORDER BY 1,2;


-- 队列 A:全部金葡菌感染(任意标本)
WITH sa_hadm AS (
  SELECT DISTINCT hadm_id, subject_id
  FROM mimiciv_hosp.microbiologyevents
  WHERE org_name ILIKE '%staphylococcus aureus%'
)
SELECT 'A_any_SA_infection' AS cohort, COUNT(*) AS n_hadm
FROM sa_hadm;


-- 队列 B:金葡菌血流感染(BSI)
WITH sa_bsi AS (
  SELECT DISTINCT hadm_id, subject_id
  FROM mimiciv_hosp.microbiologyevents
  WHERE org_name ILIKE '%staphylococcus aureus%'
    AND spec_type_desc ILIKE '%BLOOD%'
)
SELECT 'B_SA_BSI' AS cohort, COUNT(*) AS n_hadm FROM sa_bsi;


-- 队列 B2:金葡菌血流感染(含 BLOOD CULTURE 各种写法)
SELECT
  spec_type_desc,
  COUNT(DISTINCT hadm_id) AS n_hadm
FROM mimiciv_hosp.microbiologyevents
WHERE org_name ILIKE '%staphylococcus aureus%'
  AND spec_type_desc ILIKE '%blood%'
GROUP BY 1 ORDER BY 2 DESC;


-- =====================================================================================
-- CHECK 3  ★核心★ 0–72h 时序变量的测量密度(GBTM 能不能做,全看这一段)
-- =====================================================================================
-- GBTM 要求:每个患者在某时间窗内有【重复测量】,通常至少 2–3 个非缺失点。
-- 下面统计:队列 A 的每个患者,在【确诊感染时间(首次 SA 检出) 起 72h 内】
--           各变量的测量次数分布。
--
-- 先建临时队列(含首次 SA 时间):
DROP TABLE IF EXISTS tmp_sa_cohort CASCADE;
CREATE TABLE tmp_sa_cohort AS
SELECT
  m.subject_id,
  m.hadm_id,
  MIN(m.charttime) AS sa_first_time
FROM mimiciv_hosp.microbiologyevents m
WHERE m.org_name ILIKE '%staphylococcus aureus%'
GROUP BY m.subject_id, m.hadm_id;


-- 3.1 乳酸 Lactate(ICU: 一般 2–4h 一次)
DROP TABLE IF EXISTS tmp_density_lactate CASCADE;
CREATE TABLE tmp_density_lactate AS
SELECT
  c.hadm_id,
  COUNT(le.charttime) AS n_meas
FROM tmp_sa_cohort c
LEFT JOIN mimiciv_hosp.labevents le
  ON le.hadm_id = c.hadm_id
 AND le.itemid = 50813                                   -- Lactate
 AND le.charttime BETWEEN c.sa_first_time AND c.sa_first_time + INTERVAL '72 hour'
GROUP BY c.hadm_id;

SELECT
  CASE WHEN n_meas = 0 THEN '0'
       WHEN n_meas = 1 THEN '1'
       WHEN n_meas BETWEEN 2 AND 3 THEN '2-3'
       ELSE '>=4' END AS meas_count_bin,
  COUNT(*) AS n_hadm
FROM tmp_density_lactate GROUP BY 1 ORDER BY 1;

-- 能进轨迹模型的患者数(>=2 个点)
SELECT COUNT(*) AS n_with_ge2_lactate
FROM tmp_density_lactate WHERE n_meas >= 2;


-- 3.2 肌酐 Creatinine(Creatinine, blood: 50912)
DROP TABLE IF EXISTS tmp_density_cr CASCADE;
CREATE TABLE tmp_density_cr AS
SELECT
  c.hadm_id,
  COUNT(le.charttime) AS n_meas
FROM tmp_sa_cohort c
LEFT JOIN mimiciv_hosp.labevents le
  ON le.hadm_id = c.hadm_id
 AND le.itemid = 50912                                   -- Creatinine
 AND le.charttime BETWEEN c.sa_first_time AND c.sa_first_time + INTERVAL '72 hour'
GROUP BY c.hadm_id;

SELECT
  CASE WHEN n_meas = 0 THEN '0'
       WHEN n_meas = 1 THEN '1'
       WHEN n_meas BETWEEN 2 AND 3 THEN '2-3'
       ELSE '>=4' END AS meas_count_bin,
  COUNT(*) AS n_hadm
FROM tmp_density_cr GROUP BY 1 ORDER BY 1;

SELECT COUNT(*) AS n_with_ge2_creatinine FROM tmp_density_cr WHERE n_meas >= 2;


-- 3.3 白蛋白 Albumin(50862)—— 预期密度低,重点看
DROP TABLE IF EXISTS tmp_density_alb CASCADE;
CREATE TABLE tmp_density_alb AS
SELECT
  c.hadm_id,
  COUNT(le.charttime) AS n_meas
FROM tmp_sa_cohort c
LEFT JOIN mimiciv_hosp.labevents le
  ON le.hadm_id = c.hadm_id
 AND le.itemid = 50862                                   -- Albumin
 AND le.charttime BETWEEN c.sa_first_time AND c.sa_first_time + INTERVAL '72 hour'
GROUP BY c.hadm_id;

SELECT
  CASE WHEN n_meas = 0 THEN '0'
       WHEN n_meas = 1 THEN '1'
       WHEN n_meas BETWEEN 2 AND 3 THEN '2-3'
       ELSE '>=4' END AS meas_count_bin,
  COUNT(*) AS n_hadm
FROM tmp_density_alb GROUP BY 1 ORDER BY 1;

SELECT COUNT(*) AS n_with_ge2_albumin FROM tmp_density_alb WHERE n_meas >= 2;


-- 3.4 MAP(平均动脉压,ICU chartevents 220052 / 220181)
DROP TABLE IF EXISTS tmp_density_map CASCADE;
CREATE TABLE tmp_density_map AS
SELECT
  c.hadm_id,
  COUNT(ce.charttime) AS n_meas
FROM tmp_sa_cohort c
LEFT JOIN mimiciv_icu.chartevents ce
  ON ce.hadm_id = c.hadm_id
 AND ce.itemid IN (220052, 220181, 225312)               -- MAP 相关 itemid
 AND ce.charttime BETWEEN c.sa_first_time AND c.sa_first_time + INTERVAL '72 hour'
 AND ce.valuenum IS NOT NULL
GROUP BY c.hadm_id;

SELECT
  CASE WHEN n_meas = 0 THEN '0'
       WHEN n_meas = 1 THEN '1'
       WHEN n_meas BETWEEN 2 AND 3 THEN '2-3'
       ELSE '>=4' END AS meas_count_bin,
  COUNT(*) AS n_hadm
FROM tmp_density_map GROUP BY 1 ORDER BY 1;

SELECT COUNT(*) AS n_with_ge2_map FROM tmp_density_map WHERE n_meas >= 2;


-- 3.5 汇总:同时满足"乳酸>=2 且 肌酐>=2 且 MAP>=2"的患者数(GBTM 多变量轨迹的可分析集)
SELECT 'intersection >=2 points' AS crit, COUNT(*) AS n_hadm
FROM tmp_density_lactate l
JOIN tmp_density_cr c  ON c.hadm_id = l.hadm_id
JOIN tmp_density_map m ON m.hadm_id = l.hadm_id
WHERE l.n_meas >= 2 AND c.n_meas >= 2 AND m.n_meas >= 2;


-- =====================================================================================
-- CHECK 4  结局变量可得性(28 天死亡 / 90 天死亡 / ICU LOS)
-- =====================================================================================
-- MIMIC-IV 提供 dod(death out of database),可算到院外死亡日期
WITH c AS (
  SELECT DISTINCT hadm_id, subject_id
  FROM mimiciv_hosp.microbiologyevents
  WHERE org_name ILIKE '%staphylococcus aureus%'
),
adm AS (
  SELECT a.hadm_id, a.admittime, a.dischtime, a.deathtime, a.hospital_expire_flag
  FROM mimiciv_hosp.admissions a
)
SELECT
  COUNT(*)                                                          AS n_hadm,
  COUNT(*) FILTER (WHERE adm.hospital_expire_flag = 1)              AS n_inhospital_death,
  ROUND(100.0 * COUNT(*) FILTER (WHERE adm.hospital_expire_flag = 1) / NULLIF(COUNT(*),0), 1)
                                                                    AS pct_inhospital_death,
  COUNT(p.dod)                                                      AS n_has_dod,
  COUNT(*) FILTER (WHERE p.dod IS NOT NULL
                     AND p.dod <= adm.admittime + INTERVAL '28 day') AS n_death_28d,
  COUNT(*) FILTER (WHERE p.dod IS NOT NULL
                     AND p.dod <= adm.admittime + INTERVAL '90 day') AS n_death_90d
FROM c
JOIN adm ON adm.hadm_id = c.hadm_id
LEFT JOIN mimiciv_hosp.patients p ON p.subject_id = c.subject_id;


-- =====================================================================================
-- CHECK 5  ICU stay 归属与 LOS(GBTM 的观测窗口需要 ICU stay)
-- =====================================================================================
WITH c AS (
  SELECT DISTINCT hadm_id FROM mimiciv_hosp.microbiologyevents
  WHERE org_name ILIKE '%staphylococcus aureus%'
),
st AS (
  SELECT i.hadm_id,
         COUNT(*) AS n_icu_stay,
         MIN(i.intime) AS first_icu_in,
         MAX(i.outtime) AS last_icu_out,
         MAX(EXTRACT(EPOCH FROM (i.outtime - i.intime))/3600.0) AS max_los_hours
  FROM mimiciv_icu.icustays i
  GROUP BY i.hadm_id
)
SELECT
  COUNT(DISTINCT c.hadm_id)                                    AS sa_hadm_total,
  COUNT(DISTINCT c.hadm_id) FILTER (WHERE st.n_icu_stay > 0)   AS sa_hadm_with_icu,
  ROUND(AVG(st.max_los_hours), 1)                              AS avg_max_los_hours,
  ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY st.max_los_hours)::numeric, 1)
                                                               AS median_los_hours
FROM c LEFT JOIN st ON st.hadm_id = c.hadm_id;


-- =====================================================================================
-- 判定阈值参考(拿着 CHECK 3 的数字对照下表做决定)
-- =====================================================================================
-- | 指标                                   | 可用   | 勉强    | 不足    |
-- |----------------------------------------|--------|---------|---------|
-- | 队列 A 全部 SA 感染 hadm 数             | ≥800   | 400-800 | <400    |
-- | 队列 B SA-BSI hadm 数                   | ≥300   | 150-300 | <150    |
-- | MRSA / MSSA 各自 hadm 数                | 各≥150 | 各60-150| 任一<60 |
-- | 乳酸 ≥2 点的患者数                     | ≥400   | 200-400 | <200    |
-- | 肌酐 ≥2 点的患者数                     | ≥400   | 200-400 | <200    |
-- | MAP ≥2 点的患者数                      | ≥400   | 200-400 | <200    |
-- | 白蛋白 ≥2 点的患者数                   | ≥200   | 100-200 | <100    |
-- | 三变量交集(乳酸+肌酐+MAP 各≥2点)      | ≥300   | 150-300 | <150    |
-- | 28 天死亡事件数                        | ≥100   | 50-100  | <50     |
-- | 有 ICU stay 的 SA hadm 占比            | ≥70%   | 50-70%  | <50%    |
--
-- 结论口径:
--   · 若"交集患者数"≥300 且 28d 死亡≥100 → GBTM 主文章地基稳固
--   · 若交集 150-300 → 可做,但轨迹变量要精简到 2-3 个,且表述为"探索性"
--   · 若交集 <150    → 放弃多变量 GBTM,改为单变量轨迹或描述性研究
