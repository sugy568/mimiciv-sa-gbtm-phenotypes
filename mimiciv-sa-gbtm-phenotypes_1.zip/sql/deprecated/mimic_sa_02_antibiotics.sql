-- =====================================================================
-- MIMIC-IV：抗金葡菌药物使用（处方 + 实际给药 + ICU 输注），含剂量与时间
-- 设计：三张表分别保留原始粒度，不聚合；再建统一长表供分析
-- 依赖：work.keyan_rrsfil_mimic_subject / work.sa_isolate
-- =====================================================================

-- ---------------------------------------------------------------------
-- 药物白名单（按药理分类，覆盖 MSSA/MRSA 常用药）
-- 可在 work.anti_sa_drug_map 中按你库中实际 drug 名补充
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS work.anti_sa_drug_map CASCADE;

CREATE TABLE work.anti_sa_drug_map AS
SELECT * FROM (VALUES
  -- drug_pattern（ILIKE 模式）, drug_group, spectrum
  ('%vancomycin%',            'Glycopeptide',   'MRSA/MSSA'),
  ('%linezolid%',             'Oxazolidinone',  'MRSA/MSSA'),
  ('%daptomycin%',            'Lipopeptide',    'MRSA/MSSA'),
  ('%ceftaroline%',           'Cephalosporin',  'MRSA/MSSA'),
  ('%tedizolid%',             'Oxazolidinone',  'MRSA/MSSA'),
  ('%dalbavancin%',           'Lipoglycopeptide','MRSA/MSSA'),
  ('%oritavancin%',           'Lipoglycopeptide','MRSA/MSSA'),
  ('%telavancin%',            'Lipoglycopeptide','MRSA/MSSA'),
  ('%tigecycline%',           'Glycylcycline',  'MRSA/MSSA'),
  ('%oxacillin%',             'Antistaphylococcal penicillin', 'MSSA'),
  ('%nafcillin%',             'Antistaphylococcal penicillin', 'MSSA'),
  ('%cloxacillin%',           'Antistaphylococcal penicillin', 'MSSA'),
  ('%dicloxacillin%',         'Antistaphylococcal penicillin', 'MSSA'),
  ('%cefazolin%',             'Cephalosporin',  'MSSA'),
  ('%clindamycin%',           'Lincosamide',    'MSSA'),
  ('%trimethoprim%sulfamethoxazole%', 'Sulfonamide', 'MRSA/MSSA'),
  ('%sulfamethoxazole%trimethoprim%', 'Sulfonamide', 'MRSA/MSSA'),
  ('%rifampin%',              'Rifamycin',      'Adjuvant'),
  ('%rifampicin%',            'Rifamycin',      'Adjuvant'),
  ('%ampicillin%',            'Penicillin',     'MSSA'),
  ('%amoxicillin%',           'Penicillin',     'MSSA'),
  ('%penicillin g%',          'Penicillin',     'MSSA'),
  ('%benzylpenicillin%',      'Penicillin',     'MSSA'),
  ('%fusidic%',               'Steroid antibacterial', 'Adjuvant')
) AS t(drug_pattern, drug_group, spectrum);


-- ---------------------------------------------------------------------
-- 表 B1：prescriptions（下达处方，全院）
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS work.sa_antibiotic_orders CASCADE;

CREATE TABLE work.sa_antibiotic_orders AS
SELECT
  p.subject_id,
  p.hadm_id,
  p.pharmacy_id,
  p.drug,
  p.prod_strength,
  p.dose_val_rx,
  p.dose_unit_rx,
  p.form_val_disp          AS form,
  p.form_unit_disp         AS form_unit,
  p.route,
  p.starttime,
  p.stoptime,
  p.duration,
  p.duration_interval,
  dm.drug_group,
  dm.spectrum,
  -- 处方时长（小时）
  EXTRACT(EPOCH FROM (p.stoptime - p.starttime))/3600.0 AS order_duration_hours
FROM mimiciv_hosp.prescriptions p
JOIN work.anti_sa_drug_map dm
  ON p.drug ILIKE dm.drug_pattern
JOIN work.keyan_rrsfil_mimic_subject s
  ON s.subject_id = p.subject_id
 AND s.hadm_id    = p.hadm_id
WHERE p.starttime IS NOT NULL;


-- ---------------------------------------------------------------------
-- 表 B2：emar + emar_detail（实际给药 / 拒药，剂量最准）
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS work.sa_antibiotic_admin CASCADE;

CREATE TABLE work.sa_antibiotic_admin AS
SELECT
  e.subject_id,
  e.hadm_id,
  e.emar_id,
  e.pharmacy_id,
  e.medication,
  e.event_tbl,
  e.event_txt,                    -- 'Administered' / 'Not Given' 等
  e.charttime                     AS admin_charttime,
  ed.dose_given,
  ed.dose_given_unit,
  ed.dose_due,
  ed.product_amount_given,
  ed.product_unit_given,
  ed.route,
  ed.scheduled_time,
  ed.completion_status,
  ed.reason_not_given,
  dm.drug_group,
  dm.spectrum
FROM mimiciv_hosp.emar e
JOIN mimiciv_hosp.emar_detail ed
  ON ed.emar_id = e.emar_id
JOIN work.anti_sa_drug_map dm
  ON (e.medication ILIKE dm.drug_pattern
      OR ed.medication ILIKE dm.drug_pattern)
WHERE e.event_txt ILIKE '%administered%'      -- 只看真正给了药
  AND e.hadm_id IN (SELECT DISTINCT hadm_id FROM work.keyan_rrsfil_mimic_subject);


-- ---------------------------------------------------------------------
-- 表 B3：inputevents（ICU 内实际输注，最精确到分钟）
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS work.sa_antibiotic_input CASCADE;

CREATE TABLE work.sa_antibiotic_input AS
SELECT
  ie.subject_id,
  ie.hadm_id,
  ie.stay_id,
  ie.itemid,
  di.label                        AS item_label,
  ie.starttime,
  ie.endtime,
  ie.amount,
  ie.amountuom,
  ie.rate,
  ie.rateuom,
  ie.statusdescription,
  ie.orderid,
  dm.drug_group,
  dm.spectrum,
  EXTRACT(EPOCH FROM (ie.endtime - ie.starttime))/3600.0 AS infusion_hours
FROM mimiciv_icu.inputevents ie
JOIN mimiciv_icu.d_items di
  ON di.itemid = ie.itemid
JOIN work.anti_sa_drug_map dm
  ON di.label ILIKE dm.drug_pattern
WHERE ie.stay_id IN (SELECT DISTINCT stay_id FROM work.keyan_rrsfil_mimic_subject)
  AND ie.statusdescription <> 'Rewritten';


-- ---------------------------------------------------------------------
-- 表 B4：统一「用药长表」——把三个来源按 药物/组/剂量/单位/时间 归一
--       source 字段标明来源；如需合并分析，请先做单位标准化
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS work.sa_antibiotic_all CASCADE;

CREATE TABLE work.sa_antibiotic_all AS
SELECT
  'order'::text          AS source,
  subject_id, hadm_id,
  NULL::int              AS stay_id,
  drug                   AS drug_name,
  drug_group, spectrum,
  dose_val_rx            AS dose_num,
  dose_unit_rx           AS dose_unit,
  route,
  starttime              AS start_time,
  stoptime               AS end_time
FROM work.sa_antibiotic_orders
UNION ALL
SELECT
  'emar'::text, subject_id, hadm_id, NULL::int,
  medication, drug_group, spectrum,
  dose_given, dose_given_unit, route,
  admin_charttime, NULL::timestamp
FROM work.sa_antibiotic_admin
UNION ALL
SELECT
  'inputevents'::text, subject_id, hadm_id, stay_id,
  item_label, drug_group, spectrum,
  amount, amountuom, NULL::text,
  starttime, endtime
FROM work.sa_antibiotic_input;

CREATE INDEX IF NOT EXISTS idx_sa_abx_all_hadm ON work.sa_antibiotic_all(hadm_id);
