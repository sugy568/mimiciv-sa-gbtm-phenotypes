# sql/ — MIMIC-IV extraction scripts

PostgreSQL scripts against **MIMIC-IV v3.1** (`mimiciv_hosp`, `mimiciv_icu`,
`mimiciv_derived` schemas). Execute in numeric order; all scripts are idempotent
(materialized tables are dropped and rebuilt). Each script prints expected
intermediate row counts so partial runs can be verified.

| Script | Purpose |
|---|---|
| `01_sa_cohort_feasibility.sql` | Lightweight feasibility census of the *S. aureus* cohort; builds `TMP_SA_SPEC` reused by later scripts |
| `02_sa_specimen_resistance_medications.sql` | One-integration script: specimens, per-isolate methicillin susceptibility (MRSA/MSSA), demographics, comorbidities, outcomes, medications |
| `03_gbtm_trajectory_dataset.sql` | 0–72 h lactate/creatinine long table (`hadm_id, time_h, variable, value`) for GBTM |
| `04_gbtm_marker_intersection_fast.sql` | Fast three-variable intersection plan (chartevents pre-restricted before cohort joins) |
| `05_sa_antibiotics_gsn.sql` | Anti-staphylococcal drug exposure via GSN standardized codes; doses kept per-drug |
| `06_optional_emar_administration.sql` | Optional `emar`/`emar_detail` administration branch (MIMIC-IV ≥ 2.2 only); merge into 05 if available |

`deprecated/` contains the earlier-generation scripts kept for provenance; they are
superseded by scripts 01–05 above and need not be re-run.

Expected lineage (from script headers): source cohort ≈ 13,773 admissions after
first-detection deduplication; `WORK.SA_SPEC_MAT` ≈ 41,776 specimens; the final
0–72 h marker long table contains ~32,000 observations over ~3,050 admissions
with both markers measured.

Export the four analysis tables (cohort master, marker long table, susceptibility
long table, RRT indicators) to `data/` as UTF-8 CSVs — see the repository README.
