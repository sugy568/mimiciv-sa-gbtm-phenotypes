-- =====================================================================================
-- 【可选段】emar + emar_detail —— 实际给药记录（剂量最准确来源）
-- 前置条件：你的库中存在 mimiciv_hosp.emar 与 mimiciv_hosp.emar_detail
--          （MIMIC-IV v2.2 及以后才有；v2.0/2.1 无此表）
-- 若确认存在，请【在 PART 2 的 sa_antibiotic_all 之前】执行本段，
-- 并把下面的 UNION ALL 分支加入 sa_antibiotic_all 的构造中。
-- =====================================================================================

-- 先确认表存在：
-- SELECT table_schema, table_name FROM information_schema.tables
-- WHERE table_name IN ('emar','emar_detail');

DROP TABLE IF EXISTS work.sa_antibiotic_admin CASCADE;

CREATE TABLE work.sa_antibiotic_admin AS
SELECT
  e.subject_id,
  e.hadm_id,
  e.emar_id,
  e.pharmacy_id,
  e.medication,
  e.event_tbl,
  e.event_txt,
  e.charttime                          AS admin_charttime,
  ed.dose_given,
  ed.dose_given_unit,
  ed.dose_due,
  ed.product_amount_given,
  ed.product_unit_given,
  ed.route,
  ed.scheduled_time,
  ed.completion_status,
  ed.reason_not_given,
  dm.drug_group,
  dm.spectrum
FROM mimiciv_hosp.emar e
JOIN mimiciv_hosp.emar_detail ed ON ed.emar_id = e.emar_id
JOIN work.anti_sa_drug_map dm
  ON (e.medication ILIKE dm.drug_pattern OR ed.medication ILIKE dm.drug_pattern)
WHERE e.event_txt ILIKE '%administered%'
  AND e.hadm_id IN (SELECT DISTINCT hadm_id FROM work.keyan_rrsfil_mimic_subject);


-- ---------------------------------------------------------------------------------
-- 把 emar 并入统一长表：在 PART 2 执行完 sa_antibiotic_all 之后追加执行：
-- ---------------------------------------------------------------------------------
-- INSERT INTO work.sa_antibiotic_all
--   (source, subject_id, hadm_id, stay_id, drug_name, drug_group, spectrum,
--    dose_num, dose_unit, route, start_time, end_time)
-- SELECT
--   'emar', subject_id, hadm_id, NULL,
--   medication, drug_group, spectrum,
--   dose_given, dose_given_unit, route,
--   admin_charttime, NULL
-- FROM work.sa_antibiotic_admin;
--
-- 然后【重建】PART 3 的两张宽表（直接重跑 PART 3 即可覆盖）。
