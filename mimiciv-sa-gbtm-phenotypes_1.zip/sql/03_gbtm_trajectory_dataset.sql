-- =====================================================================================
-- 金葡菌(SA)感染 —— GBTM 轨迹分析数据集构建
-- 前置表(均已跑通):
--   WORK.SA_SPEC_MAT   41,776 标本 / 13,772 hadm
--   WORK.SA_COHORT     13,772 hadm,mrsa_status = MRSA/MSSA/unknown,sa_first_time
--
-- 产出:WORK.SA_TRAJ_LONG —— 长表(time × hadm × variable × value),供 R 端 GBTM 使用
--
-- 【性能须知(这台库的规律)】
--   · microbiologyevents 1.1GB   → 全表扫约 10-18 秒
--   · labevents          29GB    → 必须走 idx_labevents_value(hadm_id, charttime, itemid...)
--   · chartevents        59GB    → 只用 stay_id 前缀索引,慎用(本脚本不使用)
--   · 禁用相关子查询(会变成 N 次大表扫描)
-- =====================================================================================

SET work_mem = '512MB';
SET max_parallel_workers_per_gather = 4;


-- =====================================================================================
-- STEP 1  轨迹分析可用样本集(乳酸≥2 且 肌酐≥2)—— 目标约 3,050 hadm
-- =====================================================================================
DROP TABLE IF EXISTS WORK.SA_TRAJ_SET CASCADE;

CREATE TABLE WORK.SA_TRAJ_SET AS
SELECT hadm_id
FROM (
  SELECT c.hadm_id,
         COUNT(*) FILTER (WHERE le.itemid = 50813) AS n_lac,
         COUNT(*) FILTER (WHERE le.itemid = 50912) AS n_cr
  FROM WORK.SA_COHORT c
  JOIN MIMICIV_HOSP.LABEVENTS le
    ON le.hadm_id = c.hadm_id
   AND le.itemid IN (50813, 50912)
   AND le.charttime >= c.sa_first_time
   AND le.charttime <= c.sa_first_time + INTERVAL '72 hour'
  GROUP BY c.hadm_id
) t
WHERE n_lac >= 2 AND n_cr >= 2;

CREATE INDEX idx_traj_set ON WORK.SA_TRAJ_SET(hadm_id);
ANALYZE WORK.SA_TRAJ_SET;

SELECT COUNT(*) AS n_traj_set FROM WORK.SA_TRAJ_SET;   -- 期望 ~3,050


-- =====================================================================================
-- STEP 2  长表:0-72h 内每个时间点的乳酸 / 肌酐值
--   time_h  = 相对感染检出时间的小时数(0-72)
--   var     = 'lactate' | 'creatinine'
-- =====================================================================================
DROP TABLE IF EXISTS WORK.SA_TRAJ_LONG CASCADE;

CREATE TABLE WORK.SA_TRAJ_LONG AS
SELECT
  c.hadm_id,
  c.mrsa_status,
  EXTRACT(EPOCH FROM (le.charttime - c.sa_first_time)) / 3600.0 AS time_h,
  CASE le.itemid WHEN 50813 THEN 'lactate' WHEN 50912 THEN 'creatinine' END AS var,
  le.valuenum AS value
FROM WORK.SA_COHORT c
JOIN WORK.SA_TRAJ_SET ts ON ts.hadm_id = c.hadm_id
JOIN MIMICIV_HOSP.LABEVENTS le
  ON le.hadm_id = c.hadm_id
 AND le.itemid IN (50813, 50912)
 AND le.charttime >= c.sa_first_time
 AND le.charttime <= c.sa_first_time + INTERVAL '72 hour'
WHERE le.valuenum IS NOT NULL
  AND le.valuenum > 0
  AND (
      (le.itemid = 50813 AND le.valuenum BETWEEN 0.1 AND 30)      -- 乳酸合理范围
   OR (le.itemid = 50912 AND le.valuenum BETWEEN 0.1 AND 30)      -- 肌酐 mg/dL
  );

CREATE INDEX idx_traj_long ON WORK.SA_TRAJ_LONG(hadm_id, var);
ANALYZE WORK.SA_TRAJ_LONG;

SELECT var, COUNT(*) AS n_obs, COUNT(DISTINCT hadm_id) AS n_hadm,
       ROUND(AVG(value)::numeric, 2) AS mean_val,
       ROUND(MIN(value)::numeric, 2) AS min_val,
       ROUND(MAX(value)::numeric, 2) AS max_val
FROM WORK.SA_TRAJ_LONG GROUP BY var;


-- =====================================================================================
-- STEP 3  基线协变量(用于 Cox 调整)
-- =====================================================================================
DROP TABLE IF EXISTS WORK.SA_BASELINE CASCADE;

CREATE TABLE WORK.SA_BASELINE AS
SELECT
  c.hadm_id,
  c.subject_id,
  c.sa_first_time,
  c.mrsa_status,
  -- 人口学
  p.gender,
  p.anchor_age                                    AS age,
  -- 入院信息
  a.admission_type,
  a.insurance,
  a.race,
  a.marital_status,
  -- 结局
  a.hospital_expire_flag                          AS death_inhospital,
  a.admittime,
  a.dischtime,
  EXTRACT(EPOCH FROM (a.dischtime - a.admittime)) / 86400.0 AS hosp_los_days,
  p.dod,
  CASE WHEN p.dod IS NOT NULL AND p.dod <= a.admittime + INTERVAL '28 day'
       THEN 1 ELSE 0 END                          AS death_28d,
  CASE WHEN p.dod IS NOT NULL AND p.dod <= a.admittime + INTERVAL '90 day'
       THEN 1 ELSE 0 END                          AS death_90d,
  -- ICU
  icu.stay_id,
  icu.first_icu_in,
  icu.icu_los_hours,
  -- 首个轨迹值(基线值,供描述与调整)
  lac.lac_first,
  cr.cr_first
FROM WORK.SA_COHORT c
LEFT JOIN MIMICIV_HOSP.PATIENTS p       ON p.subject_id = c.subject_id
LEFT JOIN MIMICIV_HOSP.ADMISSIONS a     ON a.hadm_id = c.hadm_id
LEFT JOIN (
  SELECT hadm_id,
         MIN(intime) AS first_icu_in,
         MIN(stay_id) AS stay_id,
         MAX(EXTRACT(EPOCH FROM (outtime - intime)) / 3600.0) AS icu_los_hours
  FROM MIMICIV_ICU.ICUSTAYS GROUP BY hadm_id
) icu ON icu.hadm_id = c.hadm_id
LEFT JOIN (
  SELECT hadm_id,
         (ARRAY_AGG(value ORDER BY time_h))[1] AS lac_first
  FROM WORK.SA_TRAJ_LONG WHERE var = 'lactate' GROUP BY hadm_id
) lac ON lac.hadm_id = c.hadm_id
LEFT JOIN (
  SELECT hadm_id,
         (ARRAY_AGG(value ORDER BY time_h))[1] AS cr_first
  FROM WORK.SA_TRAJ_LONG WHERE var = 'creatinine' GROUP BY hadm_id
) cr ON cr.hadm_id = c.hadm_id;

CREATE INDEX idx_sa_baseline ON WORK.SA_BASELINE(hadm_id);
ANALYZE WORK.SA_BASELINE;

SELECT COUNT(*) AS n_rows,
       COUNT(*) FILTER (WHERE death_28d = 1) AS n_death28,
       COUNT(*) FILTER (WHERE death_90d = 1) AS n_death90,
       COUNT(stay_id) AS n_with_icu
FROM WORK.SA_BASELINE;


-- =====================================================================================
-- STEP 4  导出三个 CSV(供 R 使用)
--   ★ 用 \copy(客户端命令)导出到你本机
--   若 pgAdmin 不支持 \copy,改用结果网格的 "Download as CSV"
-- =====================================================================================
-- \copy (SELECT * FROM WORK.SA_TRAJ_LONG)     TO 'D:/mimic/sa_traj_long.csv'     WITH CSV HEADER
-- \copy (SELECT * FROM WORK.SA_BASELINE)      TO 'D:/mimic/sa_baseline.csv'      WITH CSV HEADER
-- \copy (SELECT * FROM WORK.SA_TRAJ_SET)      TO 'D:/mimic/sa_traj_set.csv'      WITH CSV HEADER
-- \copy (SELECT * FROM WORK.SA_COHORT)        TO 'D:/mimic/sa_cohort.csv'        WITH CSV HEADER
