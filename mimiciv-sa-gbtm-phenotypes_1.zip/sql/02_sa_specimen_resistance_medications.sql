-- =====================================================================================
-- MIMIC-IV on PostgreSQL —— 金葡菌（S. aureus）感染 + 药敏 + 抗金葡菌用药 一体化脚本
-- 作者视角：以「可复现、可追溯、不硬凑」为原则编写
-- 执行顺序：本文件自上而下顺序执行即可（幂等，可重复跑）
--
-- 【前置检查】先确认以下对象存在，缺哪个告诉我即可裁剪对应段落：
--   mimiciv_hosp.microbiologyevents / prescriptions / emar / emar_detail
--   mimiciv_icu.inputevents / d_items
--   work.keyan_rrsfil_mimic_subject (subject_id, hadm_id, stay_id)
--
-- 【本脚本产出的四张表】
--   work.sa_isolate            —— 逐标本（isolate）金葡菌 + 药敏 + MRSA/MSSA
--   work.sa_antibiotic_all     —— 抗金葡菌用药长表（order / emar / inputevents 三源）
--   work.sa_analysis_wide      —— hadm 级分析宽表（菌株状态 + 用药汇总）
--   work.sa_isolate_abx_detail —— isolate 级 × 用药明细（含覆盖是否恰当）
-- =====================================================================================


-- =====================================================================================
-- PART 1  感染事件与药敏（修正原版聚合塌陷问题）
-- =====================================================================================
DROP TABLE IF EXISTS work.sa_isolate CASCADE;

CREATE TABLE work.sa_isolate AS
WITH sa_rows AS (
  SELECT
    m.microevent_id,
    m.subject_id,
    m.hadm_id,
    m.micro_specimen_id,
    m.charttime,
    m.chartdate,
    m.spec_type_desc,
    m.org_name,
    m.ab_name,
    m.interpretation,
    m.dilution_text
  FROM mimiciv_hosp.microbiologyevents m
  WHERE (m.org_name ILIKE '%STAPH AUREUS%'
      OR m.org_name ILIKE '%S. AUREUS%'
      OR m.org_name ILIKE '%STAPHYLOCOCCUS AUREUS%')
),
-- 鉴定行：构成一株 isolate（以 micro_specimen_id 为主键）
isolate AS (
  SELECT
    micro_specimen_id,
    subject_id,
    hadm_id,
    MIN(charttime)                                   AS sa_first_charttime,
    MIN(chartdate)                                   AS sa_first_chartdate,
    MODE() WITHIN GROUP (ORDER BY spec_type_desc)    AS main_specimen,
    MODE() WITHIN GROUP (ORDER BY org_name)          AS org_name
  FROM sa_rows
  WHERE org_name IS NOT NULL
  GROUP BY micro_specimen_id, subject_id, hadm_id
),
-- 药敏行：按 micro_specimen_id 归株；不再依赖药敏行的 org_name
-- 苯唑西林类：Oxacillin / Cefoxitin / Nafcillin / Methicillin
suscept AS (
  SELECT
    m.micro_specimen_id,
    MAX(CASE WHEN lower(m.ab_name) ~ 'oxacillin|cefoxitin|nafcillin|methicillin'
             THEN 1 ELSE 0 END) AS tested_oxacillin_class,
    MAX(CASE WHEN lower(m.ab_name) ~ 'oxacillin|cefoxitin|nafcillin|methicillin'
              AND upper(btrim(m.interpretation)) LIKE 'R%'
             THEN 1 ELSE 0 END) AS oxacillin_resistant,
    string_agg(
      m.ab_name || ':' || COALESCE(btrim(m.interpretation),'NA'),
      '; ' ORDER BY m.ab_name
    ) AS suscept_detail
  FROM mimiciv_hosp.microbiologyevents m
  WHERE m.ab_name IS NOT NULL
    AND m.micro_specimen_id IN (SELECT micro_specimen_id FROM isolate)
  GROUP BY m.micro_specimen_id
)
SELECT
  i.micro_specimen_id,
  i.subject_id,
  i.hadm_id,
  i.sa_first_charttime                                   AS sa_infection_time,
  i.sa_first_chartdate,
  i.main_specimen                                        AS specimen_type,
  i.org_name,
  COALESCE(su.tested_oxacillin_class, 0)                 AS sa_suscept_tested,
  COALESCE(su.oxacillin_resistant, 0)                    AS oxacillin_resistant,
  su.suscept_detail,
  CASE
    WHEN COALESCE(su.tested_oxacillin_class,0) = 0 THEN 'unknown'
    WHEN su.oxacillin_resistant = 1                THEN 'MRSA'
    ELSE 'MSSA'
  END                                                    AS mrsa_status
FROM isolate i
LEFT JOIN suscept su ON su.micro_specimen_id = i.micro_specimen_id;

CREATE INDEX IF NOT EXISTS idx_sa_isolate_hadm ON work.sa_isolate(hadm_id);
CREATE INDEX IF NOT EXISTS idx_sa_isolate_subj ON work.sa_isolate(subject_id);


-- 每 hadm 首株菌（保留混合感染标记）
DROP VIEW IF EXISTS work.sa_isolate_first_per_hadm CASCADE;
CREATE VIEW work.sa_isolate_first_per_hadm AS
WITH ranked AS (
  SELECT
    s.*,
    ROW_NUMBER() OVER (
      PARTITION BY s.hadm_id
      ORDER BY s.sa_infection_time NULLS LAST, s.micro_specimen_id
    ) AS rn,
    COUNT(DISTINCT s.mrsa_status) OVER (PARTITION BY s.hadm_id) AS status_variants,
    COUNT(DISTINCT s.micro_specimen_id) OVER (PARTITION BY s.hadm_id) AS isolate_cnt
  FROM work.sa_isolate s
)
SELECT
  subject_id, hadm_id, micro_specimen_id, sa_infection_time, sa_first_chartdate,
  specimen_type, org_name, sa_suscept_tested, oxacillin_resistant, suscept_detail,
  mrsa_status, isolate_cnt,
  (status_variants > 1) AS mixed_infection
FROM ranked
WHERE rn = 1;


-- =====================================================================================
-- PART 2  抗金葡菌药物
-- =====================================================================================
DROP TABLE IF EXISTS work.anti_sa_drug_map CASCADE;
CREATE TABLE work.anti_sa_drug_map (
  drug_pattern text,
  drug_group   text,
  spectrum     text
);

INSERT INTO work.anti_sa_drug_map (drug_pattern, drug_group, spectrum) VALUES
  ('%vancomycin%',            'Glycopeptide',                    'MRSA/MSSA'),
  ('%linezolid%',             'Oxazolidinone',                   'MRSA/MSSA'),
  ('%daptomycin%',            'Lipopeptide',                     'MRSA/MSSA'),
  ('%ceftaroline%',           'Cephalosporin',                   'MRSA/MSSA'),
  ('%tedizolid%',             'Oxazolidinone',                   'MRSA/MSSA'),
  ('%dalbavancin%',           'Lipoglycopeptide',                'MRSA/MSSA'),
  ('%oritavancin%',           'Lipoglycopeptide',                'MRSA/MSSA'),
  ('%telavancin%',            'Lipoglycopeptide',                'MRSA/MSSA'),
  ('%tigecycline%',           'Glycylcycline',                   'MRSA/MSSA'),
  ('%oxacillin%',             'Antistaphylococcal penicillin',   'MSSA'),
  ('%nafcillin%',             'Antistaphylococcal penicillin',   'MSSA'),
  ('%cloxacillin%',           'Antistaphylococcal penicillin',   'MSSA'),
  ('%dicloxacillin%',         'Antistaphylococcal penicillin',   'MSSA'),
  ('%cefazolin%',             'Cephalosporin',                   'MSSA'),
  ('%clindamycin%',           'Lincosamide',                     'MSSA'),
  ('%trimethoprim%',          'Sulfonamide',                     'MRSA/MSSA'),
  ('%sulfamethoxazole%',      'Sulfonamide',                     'MRSA/MSSA'),
  ('%rifampin%',              'Rifamycin',                       'Adjuvant'),
  ('%rifampicin%',            'Rifamycin',                       'Adjuvant'),
  ('%ampicillin%',            'Penicillin',                      'MSSA'),
  ('%amoxicillin%',           'Penicillin',                      'MSSA'),
  ('%penicillin%',            'Penicillin',                      'MSSA'),
  ('%fusidic%',               'Steroid antibacterial',           'Adjuvant');


-- B1 处方（全院，含剂量与起止时间）
DROP TABLE IF EXISTS work.sa_antibiotic_orders CASCADE;
CREATE TABLE work.sa_antibiotic_orders AS
SELECT
  p.subject_id, p.hadm_id, p.pharmacy_id,
  p.drug, p.prod_strength,
  p.dose_val_rx, p.dose_unit_rx,
  p.form_val_disp AS form, p.form_unit_disp AS form_unit,
  p.route, p.starttime, p.stoptime, p.duration,
  dm.drug_group, dm.spectrum,
  EXTRACT(EPOCH FROM (p.stoptime - p.starttime))/3600.0 AS order_duration_hours
FROM mimiciv_hosp.prescriptions p
JOIN work.anti_sa_drug_map dm ON p.drug ILIKE dm.drug_pattern
JOIN work.keyan_rrsfil_mimic_subject s
  ON s.subject_id = p.subject_id AND s.hadm_id = p.hadm_id
WHERE p.starttime IS NOT NULL;


-- B3 ICU 实际输注（最精确）
DROP TABLE IF EXISTS work.sa_antibiotic_input CASCADE;
CREATE TABLE work.sa_antibiotic_input AS
SELECT
  ie.subject_id, ie.hadm_id, ie.stay_id, ie.itemid,
  di.label AS item_label,
  ie.starttime, ie.endtime, ie.amount, ie.amountuom,
  ie.rate, ie.rateuom, ie.orderid,
  dm.drug_group, dm.spectrum,
  EXTRACT(EPOCH FROM (ie.endtime - ie.starttime))/3600.0 AS infusion_hours
FROM mimiciv_icu.inputevents ie
JOIN mimiciv_icu.d_items di ON di.itemid = ie.itemid
JOIN work.anti_sa_drug_map dm ON di.label ILIKE dm.drug_pattern
WHERE ie.stay_id IN (SELECT DISTINCT stay_id FROM work.keyan_rrsfil_mimic_subject)
  AND ie.statusdescription <> 'Rewritten';


-- 统一长表（order + inputevents）
-- 注：emar 段见文末「可选段」，仅在确认存在 emar 表时执行
DROP TABLE IF EXISTS work.sa_antibiotic_all CASCADE;
CREATE TABLE work.sa_antibiotic_all AS
SELECT 'order'::text AS source, subject_id, hadm_id, NULL::int AS stay_id,
       drug AS drug_name, drug_group, spectrum,
       dose_val_rx AS dose_num, dose_unit_rx AS dose_unit,
       route, starttime AS start_time, stoptime AS end_time
FROM work.sa_antibiotic_orders
UNION ALL
SELECT 'inputevents'::text, subject_id, hadm_id, stay_id,
       item_label, drug_group, spectrum,
       amount, amountuom, NULL::text,
       starttime, endtime
FROM work.sa_antibiotic_input;

CREATE INDEX IF NOT EXISTS idx_sa_abx_all_hadm ON work.sa_antibiotic_all(hadm_id);


-- =====================================================================================
-- PART 3  分析宽表
-- =====================================================================================
DROP TABLE IF EXISTS work.sa_analysis_wide CASCADE;
CREATE TABLE work.sa_analysis_wide AS
WITH iso AS (SELECT * FROM work.sa_isolate_first_per_hadm),
j AS (
  SELECT a.*, i.sa_infection_time AS iso_time
  FROM work.sa_antibiotic_all a
  LEFT JOIN iso i ON i.hadm_id = a.hadm_id
),
abx AS (
  SELECT
    hadm_id,
    COUNT(*)                                                          AS abx_order_cnt,
    COUNT(DISTINCT drug_name)                                         AS abx_drug_cnt,
    MIN(start_time)                                                   AS first_abx_time,
    MAX(end_time)                                                     AS last_abx_time,
    MIN(CASE WHEN start_time >= iso_time - INTERVAL '24 hour'
             THEN start_time END)                                     AS first_abx_after_infection,
    MAX(CASE WHEN spectrum LIKE '%MRSA%' THEN 1 ELSE 0 END)           AS any_mrsa_covering,
    MAX(CASE WHEN spectrum = 'MSSA' AND drug_group ILIKE '%penicillin%'
             THEN 1 ELSE 0 END)                                       AS any_mssa_betalactam,
    MAX(CASE WHEN drug_name ILIKE '%vancomycin%'  THEN 1 ELSE 0 END)  AS used_vancomycin,
    MAX(CASE WHEN drug_name ILIKE '%linezolid%'   THEN 1 ELSE 0 END)  AS used_linezolid,
    MAX(CASE WHEN drug_name ILIKE '%daptomycin%'  THEN 1 ELSE 0 END)  AS used_daptomycin,
    MAX(CASE WHEN drug_name ILIKE '%cefazolin%'   THEN 1 ELSE 0 END)  AS used_cefazolin,
    MAX(CASE WHEN drug_name ILIKE '%oxacillin%'   THEN 1 ELSE 0 END)  AS used_oxacillin,
    MAX(CASE WHEN drug_name ILIKE '%nafcillin%'   THEN 1 ELSE 0 END)  AS used_nafcillin,
    MAX(CASE WHEN drug_name ILIKE '%clindamycin%' THEN 1 ELSE 0 END)  AS used_clindamycin,
    MAX(CASE WHEN drug_name ILIKE '%ceftaroline%' THEN 1 ELSE 0 END)  AS used_ceftaroline,
    MAX(CASE WHEN drug_name ILIKE '%trimethoprim%' OR drug_name ILIKE '%sulfamethoxazole%'
             THEN 1 ELSE 0 END)                                       AS used_tmp_smx,
    MAX(CASE WHEN drug_name ILIKE '%rifampin%' OR drug_name ILIKE '%rifampicin%'
             THEN 1 ELSE 0 END)                                       AS used_rifampin,
    MAX(CASE WHEN drug_name ILIKE '%tigecycline%' THEN 1 ELSE 0 END)  AS used_tigecycline
  FROM j
  GROUP BY hadm_id
)
SELECT
  i.subject_id, i.hadm_id, i.micro_specimen_id,
  i.sa_infection_time, i.specimen_type, i.mrsa_status,
  i.sa_suscept_tested, i.oxacillin_resistant, i.suscept_detail,
  i.isolate_cnt, i.mixed_infection,
  a.abx_order_cnt, a.abx_drug_cnt,
  a.first_abx_time, a.last_abx_time, a.first_abx_after_infection,
  a.any_mrsa_covering, a.any_mssa_betalactam,
  a.used_vancomycin, a.used_linezolid, a.used_daptomycin,
  a.used_cefazolin, a.used_oxacillin, a.used_nafcillin,
  a.used_clindamycin, a.used_ceftaroline, a.used_tmp_smx,
  a.used_rifampin, a.used_tigecycline,
  EXTRACT(EPOCH FROM (a.first_abx_after_infection - i.sa_infection_time))/3600.0
    AS hours_to_first_abx
FROM iso i
LEFT JOIN abx a ON a.hadm_id = i.hadm_id;


-- isolate 级 × 用药明细
DROP TABLE IF EXISTS work.sa_isolate_abx_detail CASCADE;
CREATE TABLE work.sa_isolate_abx_detail AS
SELECT
  iso.subject_id, iso.hadm_id, iso.micro_specimen_id,
  iso.sa_infection_time, iso.specimen_type, iso.mrsa_status, iso.suscept_detail,
  abx.source, abx.drug_name, abx.drug_group, abx.spectrum,
  abx.dose_num, abx.dose_unit, abx.route,
  abx.start_time, abx.end_time,
  EXTRACT(EPOCH FROM (abx.start_time - iso.sa_infection_time))/3600.0
    AS abx_start_hrs_from_infection,
  CASE
    WHEN iso.mrsa_status = 'MRSA' AND abx.spectrum LIKE '%MRSA%' THEN 'appropriate'
    WHEN iso.mrsa_status = 'MSSA' AND abx.spectrum LIKE '%MSSA%' THEN 'appropriate'
    WHEN iso.mrsa_status = 'unknown' THEN 'unknown'
    ELSE 'not_covering'
  END AS coverage_assessment
FROM work.sa_isolate iso
LEFT JOIN work.sa_antibiotic_all abx
  ON abx.hadm_id = iso.hadm_id
 AND abx.start_time BETWEEN iso.sa_infection_time - INTERVAL '7 day'
                        AND iso.sa_infection_time + INTERVAL '30 day';

CREATE INDEX IF NOT EXISTS idx_sa_detail_hadm ON work.sa_isolate_abx_detail(hadm_id);
