-- =====================================================================================
-- GBTM 可行性:三变量交集(快版)
-- 优化思路:
--   ① chartevents 是超大表,禁止在它上面做"队列 join"
--   ② 先按 itemid + 时间截面把 chartevents 缩到最小,再聚合
--   ③ 乳酸/肌酐从 labevents 直接按 hadm 聚合,一次扫描完成
--   ④ 全部用临时表分步,可单独看到每步耗时
-- =====================================================================================

-- -------------------------------------------------------------------------------------
-- STEP 0  重建干净的队列表(确保 hadm 唯一,减少后续行数)
-- -------------------------------------------------------------------------------------
DROP TABLE IF EXISTS WORK.TMP_SA_COHORT2 CASCADE;
CREATE TABLE WORK.TMP_SA_COHORT2 AS
SELECT DISTINCT
  hadm_id,
  MIN(sa_first_time) AS sa_first_time
FROM WORK.TMP_SA_COHORT
GROUP BY hadm_id;

SELECT COUNT(*) AS n_clean_cohort FROM WORK.TMP_SA_COHORT2;
-- 期望:13772

CREATE INDEX IF NOT EXISTS idx_tmp_cohort2_hadm ON WORK.TMP_SA_COHORT2(hadm_id);


-- -------------------------------------------------------------------------------------
-- STEP 1  乳酸 + 肌酐:一次扫描 labevents,直接出"各变量测量次数"
--         (labevents 相对小,且有 itemid 索引,快)
-- -------------------------------------------------------------------------------------
DROP TABLE IF EXISTS WORK.TMP_LAC_CR CASCADE;
CREATE TABLE WORK.TMP_LAC_CR AS
SELECT
  c.hadm_id,
  COUNT(*) FILTER (WHERE le.itemid = 50813) AS n_lac,
  COUNT(*) FILTER (WHERE le.itemid = 50912) AS n_cr
FROM WORK.TMP_SA_COHORT2 c
JOIN MIMICIV_HOSP.LABEVENTS le
  ON le.hadm_id = c.hadm_id
 AND le.itemid IN (50813, 50912)
 AND le.charttime >= c.sa_first_time
 AND le.charttime <= c.sa_first_time + INTERVAL '72 hour'
GROUP BY c.hadm_id;

SELECT COUNT(*) AS n_total,
       COUNT(*) FILTER (WHERE n_lac >= 2) AS n_lac_ge2,
       COUNT(*) FILTER (WHERE n_cr  >= 2) AS n_cr_ge2,
       COUNT(*) FILTER (WHERE n_lac >= 2 AND n_cr >= 2) AS n_lac_cr_ge2
FROM WORK.TMP_LAC_CR;


-- -------------------------------------------------------------------------------------
-- STEP 2  MAP:★关键优化★
--         先用 itemid 把 chartevents 过滤成一个"小表"(只有 MAP 行),
--         再做后续处理。这样避免对大表做队列 join。
-- -------------------------------------------------------------------------------------
DROP TABLE IF EXISTS WORK.TMP_MAP_RAW CASCADE;

CREATE TABLE WORK.TMP_MAP_RAW AS
SELECT
  ce.hadm_id,
  ce.charttime
FROM MIMICIV_ICU.CHARTEVENTS ce
WHERE ce.itemid IN (220052, 220181)      -- 先按 itemid 过滤(利用 itemid 索引)
  AND ce.valuenum IS NOT NULL
  AND ce.valuenum BETWEEN 20 AND 200;    -- MAP 合理范围,进一步缩小 + 排除脏值

-- 给结果表建索引,后续 join 才快
CREATE INDEX IF NOT EXISTS idx_tmp_map_raw_hadm ON WORK.TMP_MAP_RAW(hadm_id);

SELECT COUNT(*) AS n_map_rows FROM WORK.TMP_MAP_RAW;


-- -------------------------------------------------------------------------------------
-- STEP 3  把 MAP 行限定到队列的 72h 时间窗内,得到每 hadm 的 MAP 测量次数
-- -------------------------------------------------------------------------------------
DROP TABLE IF EXISTS WORK.TMP_MAP_CNT CASCADE;
CREATE TABLE WORK.TMP_MAP_CNT AS
SELECT
  c.hadm_id,
  COUNT(*) AS n_map
FROM WORK.TMP_SA_COHORT2 c
JOIN WORK.TMP_MAP_RAW m
  ON m.hadm_id = c.hadm_id
 AND m.charttime >= c.sa_first_time
 AND m.charttime <= c.sa_first_time + INTERVAL '72 hour'
GROUP BY c.hadm_id;

SELECT
  COUNT(*)                          AS n_total,
  COUNT(*) FILTER (WHERE n_map >= 2) AS n_map_ge2
FROM WORK.TMP_MAP_CNT;


-- -------------------------------------------------------------------------------------
-- STEP 4  三变量交集(全部走小表,秒级)
-- -------------------------------------------------------------------------------------
SELECT
  COUNT(*) FILTER (WHERE lc.n_lac >= 2 AND lc.n_cr >= 2)                     AS n_lac_cr,
  COUNT(*) FILTER (WHERE lc.n_lac >= 2 AND lc.n_cr >= 2 AND mm.n_map >= 2)   AS n_lac_cr_map,
  COUNT(*) FILTER (WHERE (lc.n_lac >= 2 OR lc.n_cr >= 2) AND mm.n_map >= 2)  AS n_any2_map
FROM WORK.TMP_LAC_CR lc
FULL OUTER JOIN WORK.TMP_MAP_CNT mm ON mm.hadm_id = lc.hadm_id;
