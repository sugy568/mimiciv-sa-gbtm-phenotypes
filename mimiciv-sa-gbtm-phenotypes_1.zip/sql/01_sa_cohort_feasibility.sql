-- =====================================================================================
-- 阶段 1(轻量版)—— 金葡菌队列可行性核查
-- 优化说明(相比旧版):
--   ① 删除全部 chartevents 全表扫描(CHECK 3 整段移出,改用阶段 2 快版)
--   ② 建立一次物化表 TMP_SA_SPEC,后续所有查询复用它,避免重复扫 microbiologyevents
--   ③ 每段标注【预期耗时】与【只看哪个数】
--   ④ 分段执行友好:每段是独立语句,可单独选中运行
--
-- 环境:PostgreSQL / MIMICIV_HOSP / MIMICIV_ICU / WORK
-- 菌名条件(你的库真实写法,已验证):
--   STAPH AUREUS COAG +  /  POSITIVE FOR METHICILLIN RESISTANT STAPH AUREUS
--   S. AUREUS POSITIVE; MRSA NEGATIVE / MRSA POSITIVE
-- =====================================================================================


-- =====================================================================================
-- STEP 0 ★前置★ 建物化表(所有后续查询共用)—— 预期 10-60 秒
-- 只看:三个数(sa_specimen_cnt / sa_hadm_cnt / sa_subject_cnt)
-- =====================================================================================
DROP TABLE IF EXISTS WORK.TMP_SA_SPEC CASCADE;

CREATE TABLE WORK.TMP_SA_SPEC AS
SELECT DISTINCT
  micro_specimen_id,
  hadm_id,
  subject_id
FROM MIMICIV_HOSP.MICROBIOLOGYEVENTS
WHERE (org_name ILIKE '%STAPH AUREUS%'
    OR org_name ILIKE '%S. AUREUS%'
    OR org_name ILIKE '%STAPHYLOCOCCUS AUREUS%');

CREATE INDEX IF NOT EXISTS idx_tmp_sa_spec_spec ON WORK.TMP_SA_SPEC(micro_specimen_id);
CREATE INDEX IF NOT EXISTS idx_tmp_sa_spec_hadm ON WORK.TMP_SA_SPEC(hadm_id);

SELECT
  COUNT(*)                     AS sa_specimen_cnt,   -- 期望 ~41,776
  COUNT(DISTINCT hadm_id)      AS sa_hadm_cnt,       -- 期望 ~13,772
  COUNT(DISTINCT subject_id)   AS sa_subject_cnt     -- 期望 ~18,146
FROM WORK.TMP_SA_SPEC;


-- =====================================================================================
-- CHECK 1  MRSA / MSSA 分布 —— 预期 30-120 秒
-- 只看:三类各多少(isolate 数与 hadm 数)
-- 注意:MRSA/MSSA 用【药敏数据】判定,不用 org_name 报告文字(82% 未写耐药结论)
-- =====================================================================================
WITH iso_flag AS (
  SELECT
    s.micro_specimen_id,
    s.hadm_id,
    MAX(CASE WHEN lower(m.ab_name) ~ 'oxacillin|cefoxitin|nafcillin|methicillin'
             THEN 1 ELSE 0 END)               AS max_tested,
    MAX(CASE WHEN lower(m.ab_name) ~ 'oxacillin|cefoxitin|nafcillin|methicillin'
              AND upper(btrim(m.interpretation)) LIKE 'R%'
             THEN 1 ELSE 0 END)               AS max_resist
  FROM WORK.TMP_SA_SPEC s
  JOIN MIMICIV_HOSP.MICROBIOLOGYEVENTS m
    ON m.micro_specimen_id = s.micro_specimen_id
   AND m.ab_name IS NOT NULL
  GROUP BY s.micro_specimen_id, s.hadm_id
)
SELECT
  CASE WHEN COALESCE(max_tested, 0) = 0 THEN 'unknown'
       WHEN max_resist = 1             THEN 'MRSA'
       ELSE 'MSSA' END                        AS mrsa_status,
  COUNT(*)                                    AS n_isolate,
  COUNT(DISTINCT hadm_id)                     AS n_hadm
FROM iso_flag
GROUP BY 1
ORDER BY 2 DESC;

-- 【补充】未做药敏的标本量(判断 unknown 占比)
SELECT COUNT(*) AS n_specimen_no_oxa_test
FROM WORK.TMP_SA_SPEC
WHERE micro_specimen_id NOT IN (
  SELECT DISTINCT micro_specimen_id
  FROM MIMICIV_HOSP.MICROBIOLOGYEVENTS
  WHERE ab_name IS NOT NULL
    AND lower(ab_name) ~ 'oxacillin|cefoxitin|nafcillin|methicillin'
);


-- =====================================================================================
-- CHECK 2  三种队列定义规模 —— 预期 5-30 秒
-- 只看:A / B / C 各多少
-- =====================================================================================
SELECT 'A_any_SA_infection' AS cohort, COUNT(DISTINCT hadm_id) AS n_hadm
FROM WORK.TMP_SA_SPEC
UNION ALL
SELECT 'B_SA_BSI', COUNT(DISTINCT s.hadm_id)
FROM WORK.TMP_SA_SPEC s
JOIN MIMICIV_HOSP.MICROBIOLOGYEVENTS m
  ON m.micro_specimen_id = s.micro_specimen_id
WHERE m.spec_type_desc ILIKE '%blood%'
UNION ALL
SELECT 'C_SA_with_ICU', COUNT(DISTINCT s.hadm_id)
FROM WORK.TMP_SA_SPEC s
JOIN MIMICIV_ICU.ICUSTAYS i ON i.hadm_id = s.hadm_id;


-- =====================================================================================
-- CHECK 2b  BSI 标本名写法确认 —— 预期 5 秒
-- =====================================================================================
SELECT m.spec_type_desc, COUNT(DISTINCT m.hadm_id) AS n_hadm
FROM WORK.TMP_SA_SPEC s
JOIN MIMICIV_HOSP.MICROBIOLOGYEVENTS m
  ON m.micro_specimen_id = s.micro_specimen_id
WHERE m.spec_type_desc ILIKE '%blood%'
GROUP BY 1 ORDER BY 2 DESC;


-- =====================================================================================
-- CHECK 3  死亡结局 —— 预期 10-40 秒  ★本脚本最重要的输出★
-- 只看:院内死亡 / 28d / 90d 死亡事件数
-- =====================================================================================
SELECT
  COUNT(*)                                                            AS n_hadm,
  COUNT(*) FILTER (WHERE a.hospital_expire_flag = 1)                  AS n_inhospital_death,
  ROUND(100.0 * COUNT(*) FILTER (WHERE a.hospital_expire_flag = 1)
        / NULLIF(COUNT(*), 0), 1)                                     AS pct_inhospital,
  COUNT(p.dod)                                                        AS n_has_dod,
  COUNT(*) FILTER (WHERE p.dod IS NOT NULL
                     AND p.dod <= a.admittime + INTERVAL '28 day')     AS n_death_28d,
  COUNT(*) FILTER (WHERE p.dod IS NOT NULL
                     AND p.dod <= a.admittime + INTERVAL '90 day')     AS n_death_90d
FROM (SELECT DISTINCT hadm_id, subject_id FROM WORK.TMP_SA_SPEC) c
JOIN MIMICIV_HOSP.ADMISSIONS a ON a.hadm_id = c.hadm_id
LEFT JOIN MIMICIV_HOSP.PATIENTS p ON p.subject_id = c.subject_id;


-- =====================================================================================
-- CHECK 3b  MRSA 与 MSSA 各自的死亡事件数(分组的结局够不够)—— 预期 20-60 秒
-- 只看:n_death_28d 在两组的分布
-- =====================================================================================
WITH iso_flag AS (
  SELECT
    s.hadm_id,
    MAX(CASE WHEN lower(m.ab_name) ~ 'oxacillin|cefoxitin|nafcillin|methicillin'
             THEN 1 ELSE 0 END) AS max_tested,
    MAX(CASE WHEN lower(m.ab_name) ~ 'oxacillin|cefoxitin|nafcillin|methicillin'
              AND upper(btrim(m.interpretation)) LIKE 'R%'
             THEN 1 ELSE 0 END) AS max_resist
  FROM WORK.TMP_SA_SPEC s
  JOIN MIMICIV_HOSP.MICROBIOLOGYEVENTS m
    ON m.micro_specimen_id = s.micro_specimen_id
   AND m.ab_name IS NOT NULL
  GROUP BY s.hadm_id
),
grp AS (
  SELECT hadm_id,
         CASE WHEN COALESCE(max_tested,0)=0 THEN 'unknown'
              WHEN max_resist=1 THEN 'MRSA' ELSE 'MSSA' END AS mrsa_status
  FROM iso_flag
)
SELECT
  g.mrsa_status,
  COUNT(DISTINCT g.hadm_id)                                        AS n_hadm,
  COUNT(DISTINCT g.hadm_id) FILTER (WHERE a.hospital_expire_flag = 1) AS n_inhospital_death,
  COUNT(DISTINCT g.hadm_id) FILTER (WHERE p.dod IS NOT NULL
                     AND p.dod <= a.admittime + INTERVAL '28 day')  AS n_death_28d
FROM grp g
JOIN MIMICIV_HOSP.ADMISSIONS a ON a.hadm_id = g.hadm_id
LEFT JOIN MIMICIV_HOSP.PATIENTS p ON p.subject_id = a.subject_id
GROUP BY 1 ORDER BY 2 DESC;


-- =====================================================================================
-- CHECK 4  ICU stay 与 LOS —— 预期 10-30 秒
-- =====================================================================================
WITH st AS (
  SELECT i.hadm_id,
         COUNT(*) AS n_icu_stay,
         MAX(EXTRACT(EPOCH FROM (i.outtime - i.intime)) / 3600.0) AS max_los_hours
  FROM MIMICIV_ICU.ICUSTAYS i
  WHERE i.hadm_id IN (SELECT hadm_id FROM WORK.TMP_SA_SPEC)
  GROUP BY i.hadm_id
)
SELECT
  (SELECT COUNT(DISTINCT hadm_id) FROM WORK.TMP_SA_SPEC)      AS sa_hadm_total,
  COUNT(*)                                                    AS sa_hadm_with_icu,
  ROUND(100.0 * COUNT(*) / NULLIF((SELECT COUNT(DISTINCT hadm_id) FROM WORK.TMP_SA_SPEC),0), 1)
                                                              AS pct_with_icu,
  ROUND(AVG(max_los_hours), 1)                                AS avg_max_los_hours,
  ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY max_los_hours)::numeric, 1)
                                                              AS median_los_hours
FROM st;


-- =====================================================================================
-- CHECK 5  首次 SA 检出时间表(供阶段 2 复用)—— 预期 30-90 秒
-- =====================================================================================
DROP TABLE IF EXISTS WORK.TMP_SA_FIRST CASCADE;
CREATE TABLE WORK.TMP_SA_FIRST AS
SELECT s.hadm_id, MIN(m.charttime) AS sa_first_time
FROM WORK.TMP_SA_SPEC s
JOIN MIMICIV_HOSP.MICROBIOLOGYEVENTS m
  ON m.micro_specimen_id = s.micro_specimen_id
GROUP BY s.hadm_id;

CREATE INDEX IF NOT EXISTS idx_tmp_sa_first ON WORK.TMP_SA_FIRST(hadm_id);

SELECT COUNT(*) AS n_hadm FROM WORK.TMP_SA_FIRST;


-- =====================================================================================
-- 核查结论对照表
-- =====================================================================================
-- | 指标                          | 可用    | 勉强     | 不足     |
-- |-------------------------------|---------|----------|----------|
-- | SA 感染 hadm                  | >=800   | 400-800  | <400     |
-- | SA-BSI hadm                   | >=300   | 150-300  | <150     |
-- | MRSA / MSSA 各自 hadm          | 各>=150 | 各60-150 | 任一<60  |
-- | 28d 死亡事件数                | >=100   | 50-100   | <50      |
-- | 有 ICU stay 的 SA hadm 占比    | >=70%   | 50-70%   | <50%     |
--
-- 已确认(此前跑出):
--   SA 感染 hadm = 13,772            ✅ 稳
--   SA-BSI hadm  = 1,492             ✅ 可做
--   药敏可判定标本 = 27,505 (65.8%)  ✅ 分组成立
--   MAP >=2 点 = 5,982;乳酸 >=2 点 = 3,099
--
-- 待补(本脚本 CHECK 3 / 3b):
--   28d / 90d 死亡事件数(总体 + MRSA/MSSA 分组) —— 决定结局分析是否可行
--
-- ★ GBTM 的三变量交集请走阶段 2(mimic_gbtm_intersection_fast.sql)
--  本脚本已完全移除 chartevents 全表扫描,不会再出现长时间卡顿。
