-- =====================================================================================
-- MIMIC-IV 抗金葡菌用药提取(PostgreSQL / 适配大写 schema / 沿用 GSN 路线)
-- 设计原则:
--   ① 沿用你的 GSN 标准化药码匹配(比药名 ILIKE 严谨)
--   ② 剂量【按药物分别保留】,不做跨药 SUM(跨药求和无药理含义)
--   ③ 剂量解析用安全正则 + NULLIF 兜底,不因脏数据中断
--   ④ 输出两个粒度:hadm 级用药标志表 + 逐条用药明细表
-- =====================================================================================


-- =====================================================================================
-- STEP 1  建立抗金葡菌药物字典(GSN)
-- =====================================================================================
-- 说明:下面先用【药名】把候选药捞出来,确认它们在你库里的 GSN 与 drug 写法。
--      确认后,把 GSN 列表写死到 STEP 2,后续全部走 GSN。
DROP TABLE IF EXISTS WORK.TMP_ANTI_SA_GSNS CASCADE;

CREATE TABLE WORK.TMP_ANTI_SA_GSNS AS
SELECT DISTINCT
  p.gsn,
  p.drug,
  p.prod_strength,
  COUNT(*) AS n_prescription
FROM MIMICIV_HOSP.PRESCRIPTIONS p
JOIN WORK.keyan_rrsfil_mimic_subject s
  ON s.hadm_id = p.hadm_id
WHERE lower(p.drug) LIKE ANY (ARRAY[
        '%vancomycin%','%daptomycin%','%teicoplanin%','%telavancin%',
        '%nafcillin%','%oxacillin%','%cloxacillin%','%dicloxacillin%',
        '%methicillin%','%cefazolin%','%cefoxitin%',
        '%linezolid%','%clindamycin%','%rifampin%','%rifampicin%',
        '%gentamicin%','%tobramycin%',
        '%trimethoprim%','%sulfamethoxazole%','%sulfa%',
        '%ceptaroline%','%ceftaroline%',
        '%tigecycline%','%quinupristin%','%dalfopristin%',
        '%fosfomycin%','%erythromycin%',
        '%levofloxacin%','%ciprofloxacin%','%moxifloxacin%'
      ])
GROUP BY p.gsn, p.drug, p.prod_strength
ORDER BY p.gsn, p.drug;

-- 【请先跑这一段并查看结果】,确认 gsn → drug 的对应关系。
-- 尤其是 GSN='006817' 这类,你要人工确认它到底是哪个药、属于哪一类。


-- =====================================================================================
-- STEP 2  逐条用药明细(GSN 路线,保留剂量/单位/途径/时间)
-- =====================================================================================
DROP TABLE IF EXISTS WORK.SA_ABX_DETAIL CASCADE;

CREATE TABLE WORK.SA_ABX_DETAIL AS
SELECT
  s.subject_id,
  s.stay_id,
  s.hadm_id,
  p.pharmacy_id,
  p.gsn,
  p.drug,
  p.prod_strength,
  p.route,
  -- 安全剂量解析:'1' / '1.5' / ' 1.5 ' 均可解析;区间/文本 → NULL
  CASE
    WHEN btrim(p.dose_val_rx) ~ '^[0-9]+(\.[0-9]+)?$'
      THEN CAST(btrim(p.dose_val_rx) AS NUMERIC)
    WHEN btrim(p.dose_val_rx) ~ '^[0-9]+(\.[0-9]+)?-[0-9]+(\.[0-9]+)?$'
      THEN CAST(split_part(btrim(p.dose_val_rx), '-', 1) AS NUMERIC)  -- 区间取下限
    ELSE NULL
  END                                   AS dose_val_num,
  p.dose_val_rx                         AS dose_val_raw,
  p.dose_unit_rx,
  p.starttime,
  p.stoptime,
  EXTRACT(EPOCH FROM (p.stoptime - p.starttime)) / 3600.0 AS duration_hours,
  -- 药物分类(按药名人工/规则归类,便于后续分组)
  CASE
    WHEN lower(p.drug) LIKE ANY (ARRAY['%vancomycin%','%teicoplanin%','%telavancin%','%dalbavancin%','%oritavancin%'])
      THEN 'glycopeptide_lipoglycopeptide'
    WHEN lower(p.drug) LIKE ANY (ARRAY['%daptomycin%'])                      THEN 'lipopeptide'
    WHEN lower(p.drug) LIKE ANY (ARRAY['%linezolid%','%tedizolid%'])         THEN 'oxazolidinone'
    WHEN lower(p.drug) LIKE ANY (ARRAY['%nafcillin%','%oxacillin%','%cloxacillin%','%dicloxacillin%','%methicillin%'])
      THEN 'anti_staph_penicillin'
    WHEN lower(p.drug) LIKE ANY (ARRAY['%cefazolin%','%cefoxitin%','%ceftaroline%','%ceptaroline%'])
      THEN 'cephalosporin'
    WHEN lower(p.drug) LIKE ANY (ARRAY['%clindamycin%'])                     THEN 'lincosamide'
    WHEN lower(p.drug) LIKE ANY (ARRAY['%trimethoprim%','%sulfamethoxazole%','%sulfa%'])
      THEN 'sulfonamide'
    WHEN lower(p.drug) LIKE ANY (ARRAY['%rifampin%','%rifampicin%'])         THEN 'rifamycin'
    WHEN lower(p.drug) LIKE ANY (ARRAY['%gentamicin%','%tobramycin%'])       THEN 'aminoglycoside'
    WHEN lower(p.drug) LIKE ANY (ARRAY['%tigecycline%'])                     THEN 'glycylcycline'
    WHEN lower(p.drug) LIKE ANY (ARRAY['%levofloxacin%','%ciprofloxacin%','%moxifloxacin%'])
      THEN 'fluoroquinolone'
    ELSE 'other'
  END                                   AS drug_class,
  -- 是否覆盖 MRSA
  CASE WHEN lower(p.drug) LIKE ANY (ARRAY[
         '%vancomycin%','%daptomycin%','%teicoplanin%','%telavancin%',
         '%linezolid%','%ceftaroline%','%ceptaroline%','%tigecycline%',
         '%quinupristin%','%dalfopristin%','%trimethoprim%','%sulfamethoxazole%'
       ]) THEN 1 ELSE 0 END             AS covers_mrsa,
  -- 是否覆盖 MSSA(β-内酰胺 + 其他有抗葡萄球菌活性者)
  CASE WHEN lower(p.drug) LIKE ANY (ARRAY[
         '%nafcillin%','%oxacillin%','%cloxacillin%','%dicloxacillin%','%methicillin%',
         '%cefazolin%','%cefoxitin%','%clindamycin%','%vancomycin%','%daptomycin%',
         '%linezolid%','%ceftaroline%','%ceptaroline%'
       ]) THEN 1 ELSE 0 END             AS covers_mssa
FROM MIMICIV_HOSP.PRESCRIPTIONS p
JOIN WORK.keyan_rrsfil_mimic_subject s
  ON s.hadm_id = p.hadm_id
WHERE lower(p.drug) LIKE ANY (ARRAY[
        '%vancomycin%','%daptomycin%','%teicoplanin%','%telavancin%',
        '%nafcillin%','%oxacillin%','%cloxacillin%','%dicloxacillin%',
        '%methicillin%','%cefazolin%','%cefoxitin%',
        '%linezolid%','%clindamycin%','%rifampin%','%rifampicin%',
        '%gentamicin%','%tobramycin%',
        '%trimethoprim%','%sulfamethoxazole%','%sulfa%',
        '%ceptaroline%','%ceftaroline%',
        '%tigecycline%','%quinupristin%','%dalfopristin%',
        '%fosfomycin%','%erythromycin%',
        '%levofloxacin%','%ciprofloxacin%','%moxifloxacin%'
      ])
  AND p.starttime IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_sa_abx_detail_hadm ON WORK.SA_ABX_DETAIL(hadm_id);
CREATE INDEX IF NOT EXISTS idx_sa_abx_detail_gsn  ON WORK.SA_ABX_DETAIL(gsn);


-- =====================================================================================
-- STEP 3  hadm 级用药汇总(标志 + 分类覆盖,不做跨药剂量求和)
-- =====================================================================================
DROP TABLE IF EXISTS WORK.SA_ABX_HADM CASCADE;

CREATE TABLE WORK.SA_ABX_HADM AS
SELECT
  hadm_id,
  COUNT(*)                                            AS n_abx_records,
  COUNT(DISTINCT gsn)                                 AS n_distinct_drug,
  MIN(starttime)                                      AS first_abx_time,
  MAX(stoptime)                                       AS last_abx_time,
  -- 各类药是否使用
  MAX(CASE WHEN drug_class = 'glycopeptide_lipoglycopeptide' THEN 1 ELSE 0 END) AS used_glycopeptide,
  MAX(CASE WHEN drug_class = 'lipopeptide'        THEN 1 ELSE 0 END) AS used_daptomycin,
  MAX(CASE WHEN drug_class = 'oxazolidinone'      THEN 1 ELSE 0 END) AS used_linezolid,
  MAX(CASE WHEN drug_class = 'anti_staph_penicillin' THEN 1 ELSE 0 END) AS used_antistaph_penicillin,
  MAX(CASE WHEN drug_class = 'cephalosporin'      THEN 1 ELSE 0 END) AS used_cephalosporin,
  MAX(CASE WHEN drug_class = 'lincosamide'        THEN 1 ELSE 0 END) AS used_clindamycin,
  MAX(CASE WHEN drug_class = 'sulfonamide'        THEN 1 ELSE 0 END) AS used_sulfonamide,
  MAX(CASE WHEN drug_class = 'rifamycin'          THEN 1 ELSE 0 END) AS used_rifamycin,
  MAX(CASE WHEN drug_class = 'aminoglycoside'     THEN 1 ELSE 0 END) AS used_aminoglycoside,
  MAX(CASE WHEN drug_class = 'glycylcycline'      THEN 1 ELSE 0 END) AS used_tigecycline,
  MAX(CASE WHEN drug_class = 'fluoroquinolone'    THEN 1 ELSE 0 END) AS used_fluoroquinolone,
  -- 覆盖谱
  MAX(covers_mrsa)                                    AS covers_mrsa,
  MAX(covers_mssa)                                    AS covers_mssa,
  -- 药物种类数(去重)
  COUNT(DISTINCT drug_class)                          AS n_drug_class
FROM WORK.SA_ABX_DETAIL
GROUP BY hadm_id;


-- =====================================================================================
-- 验收查询
-- =====================================================================================
-- V1  先看 GSN 字典(STEP 1 结果)
SELECT * FROM WORK.TMP_ANTI_SA_GSNS ORDER BY n_prescription DESC LIMIT 50;

-- V2  用药明细抽样(含剂量、单位)
SELECT hadm_id, drug, drug_class, dose_val_num, dose_unit_rx, route,
       starttime, duration_hours, covers_mrsa, covers_mssa
FROM WORK.SA_ABX_DETAIL
ORDER BY hadm_id, starttime
LIMIT 40;

-- V3  剂量解析失败率(看你的脏数据有多严重)
SELECT
  COUNT(*)                                                        AS total,
  COUNT(*) FILTER (WHERE dose_val_num IS NULL)                    AS n_unparsed,
  ROUND(100.0 * COUNT(*) FILTER (WHERE dose_val_num IS NULL) / NULLIF(COUNT(*),0), 1) AS pct_unparsed
FROM WORK.SA_ABX_DETAIL;

-- V4  未解析剂量的原始写法(看看是什么格式漏了)
SELECT dose_val_raw, dose_unit_rx, COUNT(*) AS n
FROM WORK.SA_ABX_DETAIL
WHERE dose_val_num IS NULL
GROUP BY 1, 2 ORDER BY 3 DESC LIMIT 30;

-- V5  hadm 级汇总抽样
SELECT * FROM WORK.SA_ABX_HADM ORDER BY n_abx_records DESC LIMIT 20;
