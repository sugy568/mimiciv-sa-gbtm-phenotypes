# mimiciv-sa-gbtm-phenotypes

Code accompanying:

> **Joint lactate–creatinine trajectories identify three phenotypes with markedly different mortality in *Staphylococcus aureus* infection: a retrospective cohort study using MIMIC-IV**

Retrospective cohort study based on MIMIC-IV v3.1 (2008–2022). Adult admissions with a first
microbiological detection of *S. aureus* (n = 13,773) were phenotyped by group-based trajectory
modelling (GBTM, `lcmm::hlme`) of serial lactate and creatinine values within 0–72 h of the first
detection. A joint three-level phenotype (P1 low → P3 high) was derived by summing the
severity ranks of the two per-marker class assignments. Outcomes: 28-day mortality (Cox models),
competing-risk cumulative incidence (Aalen–Johansen), and incremental discrimination of the
phenotype over clinical baselines and single-point biomarkers (ΔC with DeLong tests, IDI, NRI).

---

## Data availability and DUA compliance

The source data are from **MIMIC-IV version 3.1**, publicly available to credentialed users
through PhysioNet: <https://physionet.org/content/mimiciv/3.1/> (dataset DOI
[10.13026/kpb9-mt58](https://doi.org/10.13026/kpb9-mt58)). Access requires registration,
signature of a data use agreement (DUA), and completion of training in the responsible conduct
of research (CITI Program).

> **No patient-level data are included in this repository.** The PhysioNet DUA prohibits
> redistribution of patient-level data. Users must obtain their own credentialed access and
> regenerate the four analysis tables with the SQL scripts in [`sql/`](sql/). Only aggregate
> summary tables, trace files and figures (identical to the published Additional files) are
> committed here.

## Environment

| Component | Version used |
|---|---|
| R | 4.3.3 (2024-02-29) |
| lcmm (GBTM fitting) | 2.2.2 |
| pROC (ROC / DeLong) | 1.19.1 |
| survival (Cox, Schoenfeld) | 3.5-8 |
| cmprsk (competing risks) | 2.2-12 |
| ggplot2 / gridExtra | 4.0.3 / 2.3.1 |
| PostgreSQL + MIMIC-IV | 12+ with `mimiciv_hosp` / `mimiciv_icu` / `mimiciv_derived` loaded |

Full dependency lockfile: [`package_versions.csv`](package_versions.csv) (130 packages) and
[`sessionInfo.txt`](sessionInfo.txt). Install missing packages with
`Rscript R/00_install_packages.R` (uses the Tsinghua CRAN mirror; edit to taste).

## Repository structure

```
mimiciv-sa-gbtm-phenotypes/
├── README.md                  # this file
├── LICENSE                    # MIT (code only; data are NOT included)
├── .gitignore                 # excludes all patient-level files
├── sessionInfo.txt            # R session of the manuscript run
├── package_versions.csv       # full package version lockfile
├── sql/                       # MIMIC-IV extraction (PostgreSQL), run in this order
│   ├── 01_sa_cohort_feasibility.sql              # cohort feasibility census (lightweight)
│   ├── 02_sa_specimen_resistance_medications.sql # specimens, MRSA/MSSA判定, demographics, meds
│   ├── 03_gbtm_trajectory_dataset.sql            # 0–72 h lactate/creatinine long table
│   ├── 04_gbtm_marker_intersection_fast.sql      # three-variable intersection (fast plan)
│   ├── 05_sa_antibiotics_gsn.sql                 # anti-staphylococcal drugs (GSN route)
│   ├── 06_optional_emar_administration.sql       # optional emar administration branch
│   └── deprecated/                               # earlier-generation scripts, kept for provenance
├── R/                         # analysis pipeline (run from this folder)
│   ├── 00_install_packages.R  # dependency installation
│   ├── 00_自检.R               # 30-s self-check: packages, files, columns, missingness
│   ├── 01_load_data.R         # semantic file locator (filename-agnostic loading)
│   ├── 00_RUN_ALL.R           # ★ one-key master: GBTM refit → all tables & figures
│   ├── 10_R_分析全流程.R       # annotated full interactive pipeline (reference copy)
│   ├── 20_manuscript_tables_figures.R  # all manuscript tables/figures from SA_MERGED.csv
│   ├── 21_rrt_sensitivity.R   # RRT-definition sensitivity analysis
│   ├── 30_make_phenotype_file.R / 40_rebuild_pheno_from_models.R  # phenotype assignment utilities
│   ├── 40_incremental_C_statistic.R   # ★ self-contained incremental discrimination (ΔC, IDI, NRI)
│   ├── 31_incremental_C_sensitivity.R # scenario sensitivity for the ΔC analysis
│   └── 32_fig_incremental_C.R         # Figure 8 rendering
├── data/                      # ← place the four exported CSVs here (git-ignored)
├── figures/                   # manuscript figures Fig01–08 + FigS01–S11 (PNG/PDF/SVG)
├── tables/                    # manuscript table outputs (aggregate only) + incremental_C/
└── trace/                     # model-selection trace, input fingerprints, key numbers
```

## Reproduction

### Step 1 — SQL extraction (PostgreSQL)

Execute [`sql/`](sql/) scripts **in numeric order** against a PostgreSQL instance with
MIMIC-IV v3.1 loaded (BigQuery users need minor schema adjustments). Scripts are idempotent.
The main lineage is: feasibility census (01) → specimen/isolation, resistance and demographic
tables (02) → 0–72 h lactate–creatinine long table (03) → fast three-variable intersection
(04) → anti-staphylococcal drug exposure (05, optional 06). Each script prints expected
intermediate counts so that partial runs can be verified.

### Step 2 — Export the four analysis tables

Export the final tables to `data/` as UTF-8 CSVs. The loader (`R/01_load_data.R`) locates
files by semantic keywords + required columns, so exact filenames may vary:

| File | Content |
|---|---|
| `SA_MASTER.csv` | one row per admission, ~13,773 × 157–208 cols (cohort, outcomes, covariates) |
| `SA_TRAJ_LONG.csv` | marker long table: `hadm_id, time_h, variable, value` (0–72 h lactate/creatinine) |
| `SA_SUSCEPT_LONG.csv` | antimicrobial susceptibility results |
| `SA_CRRT_SCI.csv` | renal replacement therapy indicators (`rrt_strong` / `rrt_any`) |

⚠️ Do **not** commit these files (see `.gitignore`), and avoid non-ASCII paths.

### Step 3 — Main pipeline

```bash
Rscript R/00_自检.R          # ~30 s sanity check first
Rscript R/00_RUN_ALL.R       # one-key run, ~12–20 min (excl. GBTM grid search)
Rscript R/00_RUN_ALL.R --stage=gbtm   # refit phenotypes only
Rscript R/00_RUN_ALL.R --stage=plot   # tables/figures only (reuse phenotype file)
```

GBTM specification: `hlme(value ~ time_s + I(time_s^2), random = ~time_s,
mixture = ~time_s + I(time_s^2), subject = "hadm_id", ng = K)` with `time_s = time_h / 72`;
K = 1–4 screened by BIC with a 30-start grid search (`gridsearch(rep = 30)`); every fitting
attempt is logged to `trace/gbtm_search_log.csv`. On a typical laptop the full K = 1–4
grid search for both markers takes 2–3 h (`GRID_REP` can be lowered for a dry run).

### Step 4 — Incremental discrimination analysis

```bash
Rscript R/40_incremental_C_statistic.R
```

Self-contained script; all settings are environment-variable overridable (`DATA_DIR`,
`OUT_DIR`, `PHENO_MODE = auto|file|recompute`, `GRID_REP`, `SEED`, `BOOT_B`). Outputs the
nested-model C-statistic comparison (ΔC + bootstrap CI + DeLong test + LR χ² + IDI/NRI +
Brier + AIC) for four pre-specified comparator scenarios, with figures and a version-lock CSV.

Outputs of both steps are written to `out_manuscript/{figures,tables,trace}`.

## Notes for reviewers

- `trace/gbtm_search_log.csv` — every GBTM fitting attempt (K, seeds, BIC, convergence),
  for transparency of model selection.
- `trace/run_manifest.txt` — MD5 and dimensions of the exact input file used for the
  manuscript run; `trace/key_numbers.txt` — key result numbers cross-checked against the text.
- Committed outputs under `figures/`, `tables/` and `trace/` correspond to the manuscript run.

## License

Code is released under the MIT License (see [LICENSE](LICENSE)).
MIMIC-IV data are **not** included and are not redistributable; access them via PhysioNet
under your own data use agreement. Figures and aggregate tables are provided for review of
the accompanying manuscript.
